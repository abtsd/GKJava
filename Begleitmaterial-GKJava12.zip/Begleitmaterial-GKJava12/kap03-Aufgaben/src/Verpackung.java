public class Verpackung {
	public static void main(String[] args) {
		int x = 47;
		int n = 5;
		
		System.out.println("Anzahl Kartons: " + (x / n));
		System.out.println("Rest: " + (x % n));
	}
}
