public class Sekunden {
	public static void main(String[] args) {
		long sek = 31 * 24 * 60 * 60;
		System.out.println("Der Monat Januar hat " + sek + " Sekunden.");
	}
}
