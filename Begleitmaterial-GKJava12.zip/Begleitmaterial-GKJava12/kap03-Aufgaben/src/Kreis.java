public class Kreis {
	public static void main(String[] args) {
		double PI = 3.14159;
		double r = 1.5;

		System.out.println("Durchmesser: " + 2 * r);
		System.out.println("Umfang: " + 2 * PI * r);
		System.out.println("Fläche: " + PI * r * r);
	}
}
