public class Uhrzeit {
	public static void main(String[] args) {
		int x = 20;
		int n = 8;
		
		System.out.println((x + n) % 24);
	}
}
