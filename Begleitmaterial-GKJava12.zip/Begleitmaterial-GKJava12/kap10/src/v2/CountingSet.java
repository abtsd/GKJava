package v2;

import set.IntegerSet;

public class CountingSet {
	private final IntegerSet delegate = new IntegerSet();
	private long count;

	public void add(int n) {
		count++;
		delegate.add(n);
	}

	public void addAll(int[] integers) {
		count += integers.length;
		delegate.addAll(integers);
	}

	public long getCount() {
		return count;
	}

	public int[] getIntegers() {
		return delegate.getIntegers();
	}

	public static void main(String[] args) {
		CountingSet set = new CountingSet();
		set.addAll(new int[] {1, 2, 3});
		System.out.println("count: " + set.getCount());
		int[] integers = set.getIntegers();
		for (int i : integers) {
			System.out.println(i);
		}
	}
}
