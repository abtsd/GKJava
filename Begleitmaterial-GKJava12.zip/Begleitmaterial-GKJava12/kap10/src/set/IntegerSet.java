package set;

public class IntegerSet {
	private final int[] set = new int[1000];
	private int size;

	public int[] getIntegers() {
		int[] result = new int[size];
		for (int i = 0; i < size; i++) {
			result[i] = set[i];
		}
		return result;
	}

	public void add(int n) {
		boolean found = false;
		for (int value : set) {
			if (value == n) {
				found = true;
				break;
			}
		}
		if (!found) {
			set[size++] = n;
		}
	}

	public void addAll(int[] integers) {
		for (int i : integers) {
			add(i);
		}
	}

	public static void main(String[] args) {
		IntegerSet integerSet = new IntegerSet();
		integerSet.add(1);
		integerSet.add(2);
		integerSet.add(1);
		integerSet.addAll(new int[] {1, 2, 3, 4});

		int[] integers = integerSet.getIntegers();
		for (int i : integers) {
			System.out.println(i);
		}
	}
}
