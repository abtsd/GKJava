package async;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Test1 extends Application {
	private Button start;
	private Button stop;
	private Label lbMessage;
	private Label lbResult;
	private ProgressBar pgb;
	private Thread thread;
	private final int MAX = 100_000_000;
	private final int INTERVAL = 1_000;

	@Override
	public void start(Stage stage) {
		start = new Button();
		start.setText("Start");
		start.setOnAction(e -> doWork());

		stop = new Button();
		stop.setText("Stop");
		stop.setOnAction(e -> stopWork());
		stop.setDisable(true);

		lbMessage = new Label();
		lbResult = new Label();
		pgb = new ProgressBar(0);
		pgb.setPrefWidth(200);

		HBox hbox = new HBox();
		hbox.setSpacing(20);
		hbox.getChildren().addAll(start, stop);

		VBox vbox = new VBox();
		vbox.setSpacing(20);
		vbox.getChildren().addAll(hbox, lbMessage, pgb, lbResult);

		AnchorPane anchorPane = new AnchorPane();
		anchorPane.getChildren().add(vbox);
		AnchorPane.setLeftAnchor(vbox, 30.);
		AnchorPane.setTopAnchor(vbox, 30.);

		stage.setScene(new Scene(anchorPane, 300, 200));
		stage.setTitle("Test1");
		stage.show();
	}

	private void doWork() {
		start.setDisable(true);
		stop.setDisable(false);

		thread = new Thread() {
			double value;

			public void run() {
				Platform.runLater(() -> lbMessage.setText("Gestartet"));
				Platform.runLater(() -> lbResult.setText(""));

				double z = 0;
				long begin = System.currentTimeMillis();
				for (int i = 0; i < MAX; i++) {
					if (isInterrupted())
						break;

					z += Math.sin(i) + Math.cos(i);

					if (i % INTERVAL == 0) {
						value = (double) i / MAX;
						Platform.runLater(() -> pgb.setProgress(value));
					}
				}

				if (isInterrupted()) {
					Platform.runLater(() -> lbMessage.setText("Gestoppt"));
				} else {
					Platform.runLater(() -> pgb.setProgress(1));
					long end = System.currentTimeMillis();
					String result = z + " " + (end - begin) + " ms";
					Platform.runLater(() -> lbMessage.setText("Beendet"));
					Platform.runLater(() -> lbResult.setText(result));
				}

				Platform.runLater(() -> start.setDisable(false));
				Platform.runLater(() -> stop.setDisable(true));
			}
		};

		thread.setDaemon(true);
		thread.start();
	}

	private void stopWork() {
		if (thread != null) {
			thread.interrupt();
			thread = null;
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
