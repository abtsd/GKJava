package async;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Test2 extends Application {
	private Button start;
	private Button stop;
	private Label lbMessage;
	private Label lbResult;
	private ProgressBar pgb;
	private Task<String> task;
	private final int MAX = 100_000_000;
	private final int INTERVAL = 1_000;

	@Override
	public void start(Stage stage) {
		start = new Button();
		start.setText("Start");
		start.setOnAction(e -> doWork());

		stop = new Button();
		stop.setText("Stop");
		stop.setOnAction(e -> stopWork());
		stop.setDisable(true);

		lbMessage = new Label();
		lbResult = new Label();
		pgb = new ProgressBar(0);
		pgb.setPrefWidth(200);

		HBox hbox = new HBox();
		hbox.setSpacing(20);
		hbox.getChildren().addAll(start, stop);

		VBox vbox = new VBox();
		vbox.setSpacing(20);
		vbox.getChildren().addAll(hbox, lbMessage, pgb, lbResult);

		AnchorPane anchorPane = new AnchorPane();
		anchorPane.getChildren().add(vbox);
		AnchorPane.setLeftAnchor(vbox, 30.);
		AnchorPane.setTopAnchor(vbox, 30.);

		stage.setScene(new Scene(anchorPane, 300, 200));
		stage.setTitle("Test2");
		stage.show();
	}

	private void doWork() {
		task = new Task<>() {
			@Override
			protected String call() throws Exception {
				updateMessage("Gestartet");

				double z = 0;
				long begin = System.currentTimeMillis();
				for (int i = 0; i < MAX; i++) {
					if (isCancelled())
						break;

					z += Math.sin(i) + Math.cos(i);

					if (i % INTERVAL == 0)
						updateProgress(i, MAX);
				}

				String result = "";
				if (!isCancelled()) {
					updateProgress(MAX, MAX);
					long end = System.currentTimeMillis();
					long duration = end - begin;

					result = z + " " + duration + " ms";
				}
				return result;
			}

			@Override
			protected void succeeded() {
				super.succeeded();
				updateMessage("Beendet");
			}

			@Override
			protected void cancelled() {
				super.cancelled();
				updateMessage("Gestoppt");
			}
		};

		lbMessage.textProperty().bind(task.messageProperty());
		lbResult.textProperty().bind(task.valueProperty());
		pgb.progressProperty().bind(task.progressProperty());
		start.disableProperty().bind(task.runningProperty());
		stop.disableProperty().bind(task.runningProperty().not());

		Thread t = new Thread(task);
		t.setDaemon(true);
		t.start();
	}

	private void stopWork() {
		task.cancel();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
