package first;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Demo extends Application {
	@Override
	public void init() {
		System.out.println("init");
	}

	@Override
	public void start(Stage stage) {
		System.out.println("start");
		StackPane pane = new StackPane();

		Button button = new Button();
		button.setText("Hier klicken");
		button.setOnAction(e -> Platform.exit());
		pane.getChildren().add(button);

		stage.setScene(new Scene(pane, 400, 100));
		stage.setOnCloseRequest(Event::consume);
		stage.setTitle("Demo");
		stage.setResizable(false);
		stage.show();
	}

	@Override
	public void stop() {
		System.out.println("stop");
	}

	public static void main(String[] args) {
		launch(args);
	}
}
