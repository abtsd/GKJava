package properties;

import javafx.beans.property.SimpleIntegerProperty;

public class PropertiesTest {
	public static void main(String[] args) {
		SimpleIntegerProperty prop1 = new SimpleIntegerProperty();
		prop1.addListener((observable, oldValue, newValue) ->
				System.out.println("prop1 geändert von " + oldValue + " nach " + newValue));
		prop1.set(1);
		prop1.set(2);

		SimpleIntegerProperty prop2 = new SimpleIntegerProperty();

		// prop2 wird an prop1 gebunden
		prop2.bind(prop1);

		System.out.println("prop2: " + prop2.get());
		prop1.set(3);
		System.out.println("prop2: " + prop2.get());
	}
}
