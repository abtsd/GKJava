package table;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ArticleTable extends Application {
	@Override
	public void start(Stage stage) {
		AnchorPane root = new AnchorPane();

		TableView<Article> tableView = new TableView<>();

		TableColumn<Article, Integer> colId = new TableColumn<>("Artikelnummer");
		TableColumn<Article, String> colName = new TableColumn<>("Artikelbezeichnung");
		TableColumn<Article, Double> colPrice = new TableColumn<>("Artikelpreis");

		colId.setId("id");
		colName.setId("name");
		colPrice.setId("price");

		tableView.getColumns().addAll(colId, colName, colPrice);
		tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
		colName.setMinWidth(400);

		colId.setCellValueFactory(new PropertyValueFactory<>("id"));
		colName.setCellValueFactory(new PropertyValueFactory<>("name"));
		colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

		colPrice.setCellFactory(column -> new TableCell<>() {
			protected void updateItem(Double item, boolean empty) {
				super.updateItem(item, empty);
				if (empty || item == null) {
					setText(null);
				} else {
					setText(String.format("%8.2f", item));
					setAlignment(Pos.CENTER_RIGHT);
				}
			}
		});

		tableView.setItems(getList());

		root.getChildren().addAll(tableView);
		root.setPrefWidth(800);
		root.setPrefHeight(500);

		AnchorPane.setTopAnchor(tableView, 12.);
		AnchorPane.setLeftAnchor(tableView, 12.);
		AnchorPane.setRightAnchor(tableView, 12.);
		AnchorPane.setBottomAnchor(tableView, 12.);

		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass()
				.getResource("ArticleTable.css").toExternalForm());

		stage.setTitle("Artikel");
		stage.setScene(scene);
		stage.show();
	}

	private ObservableList<Article> getList() {
		ObservableList<Article> list = FXCollections.observableArrayList();
		for (int i = 1; i <= 100; i++) {
			list.add(new Article(i + 1000, "Bezeichnung für Artikel " + (i + 1000), i));
		}
		return list;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
