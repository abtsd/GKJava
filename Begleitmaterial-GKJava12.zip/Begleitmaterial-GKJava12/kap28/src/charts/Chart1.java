package charts;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Chart1 extends Application {
	private ObservableList<PieChart.Data> dataList;

	@Override
	public void start(Stage stage) {
		dataList = FXCollections.observableArrayList();
		initialize();

		AnchorPane pane = new AnchorPane();
		PieChart chart = new PieChart();
		chart.setData(dataList);
		chart.setTitle("Anzahl Einkäufe");
		chart.setPrefWidth(1200);
		chart.setPrefHeight(800);

		Label label = new Label();
		label.setLayoutX(50);
		label.setLayoutY(50);
		label.setId("value");

		for (PieChart.Data data : dataList) {
			Node node = data.getNode();
			String text = String.format("%8.0f %8.2f %%",
					data.getPieValue(), data.getPieValue() * 100. / sum());
			node.setOnMouseEntered(e -> label.setText(text));
			node.setOnMouseExited(e -> label.setText(""));
		}

		pane.getChildren().addAll(chart, label);

		Scene scene = new Scene(pane);
		scene.getStylesheets().add(getClass().getResource("chart1.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("Chart1");
		stage.show();
	}

	private void initialize() {
		dataList.add(new PieChart.Data("Damenbekleidung", 211));
		dataList.add(new PieChart.Data("Elektrogeräte", 166));
		dataList.add(new PieChart.Data("Herrenbekleidung", 142));
		dataList.add(new PieChart.Data("Kinderbekleidung", 158));
		dataList.add(new PieChart.Data("Lebensmittel", 192));
		dataList.add(new PieChart.Data("Spielwaren", 131));
	}

	private double sum() {
		double sum = 0;
		for (PieChart.Data data : dataList) {
			sum += data.getPieValue();
		}
		return sum;
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
