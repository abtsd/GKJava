package charts;

import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Chart2 extends Application {
	private XYChart.Series<String, Number> seriesA;
	private XYChart.Series<String, Number> seriesB;
	private XYChart.Series<String, Number> seriesC;

	@Override
	public void start(Stage stage) {
		seriesA = new XYChart.Series<>();
		seriesB = new XYChart.Series<>();
		seriesC = new XYChart.Series<>();

		AnchorPane pane = new AnchorPane();

		CategoryAxis xAxis = new CategoryAxis();
		xAxis.setLabel("Quartal");

		NumberAxis yAxis = new NumberAxis();
		yAxis.setLabel("Umsatz");

		BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
		chart.setTitle("Umsatz im Jahr 2020 in Tsd.");
		chart.setPrefWidth(1200);
		chart.setPrefHeight(800);

		initialize();
		chart.getData().addAll(seriesA, seriesB, seriesC);

		Label label = new Label();
		label.setLayoutX(150);
		label.setLayoutY(100);
		label.setId("value");

		for (XYChart.Series<String, Number> series : chart.getData()) {
			for (XYChart.Data<String, Number> data : series.getData()) {
				Node node = data.getNode();
				String text = data.getXValue() + "   " + series.getName() +
						"\nUmsatz: " + data.getYValue();
				node.setOnMouseEntered(e -> label.setText(text));
				node.setOnMouseExited(e -> label.setText(""));
			}
		}

		pane.getChildren().addAll(chart, label);

		Scene scene = new Scene(pane);
		scene.getStylesheets().add(getClass().getResource("chart2.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("Chart2");
		stage.show();
	}

	private void initialize() {
		seriesA.setName("Warenhaus A");
		seriesA.getData().add(new XYChart.Data<>("1. Q", 30));
		seriesA.getData().add(new XYChart.Data<>("2. Q", 25));
		seriesA.getData().add(new XYChart.Data<>("3. Q", 20));
		seriesA.getData().add(new XYChart.Data<>("4. Q", 60));

		seriesB.setName("Warenhaus B");
		seriesB.getData().add(new XYChart.Data<>("1. Q", 20));
		seriesB.getData().add(new XYChart.Data<>("2. Q", 35));
		seriesB.getData().add(new XYChart.Data<>("3. Q", 25));
		seriesB.getData().add(new XYChart.Data<>("4. Q", 70));

		seriesC.setName("Warenhaus C");
		seriesC.getData().add(new XYChart.Data<>("1. Q", 25));
		seriesC.getData().add(new XYChart.Data<>("2. Q", 30));
		seriesC.getData().add(new XYChart.Data<>("3. Q", 35));
		seriesC.getData().add(new XYChart.Data<>("4. Q", 65));
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
