package kontakte5;

import java.sql.*;
import java.util.Scanner;

public class Query {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:kontakte.db";

		try (Connection con = DriverManager.getConnection(url);
			 Statement stmt = con.createStatement();
			 Scanner scanner = new Scanner(System.in)) {

			while (true) {
				System.out.print("> ");
				String line = scanner.nextLine();
				if (line == null || line.isEmpty())
					break;

				try {
					ResultSet rs = stmt.executeQuery(line);

					ResultSetMetaData rsmd = rs.getMetaData();
					int count = rsmd.getColumnCount();
					String[] names = new String[count];
					for (int i = 0; i < count; i++) {
						names[i] = rsmd.getColumnName(i + 1);
					}

					int z = 0;
					while (rs.next()) {
						z++;
						System.out.println("#" + z);
						for (int i = 0; i < count; i++) {
							System.out.printf("%-12s: %s%n", names[i], rs.getObject(i + 1));
						}
						System.out.println();
					}
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
