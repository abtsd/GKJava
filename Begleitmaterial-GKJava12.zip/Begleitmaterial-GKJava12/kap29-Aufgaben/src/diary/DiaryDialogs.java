package diary;

import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.time.LocalDate;
import java.util.Optional;

public class DiaryDialogs {
	// Information
	public static void info(String text) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("Mein Tagebuch");
		alert.setHeaderText("");
		alert.setContentText(text);
		alert.showAndWait();
	}

	// Bestätigung
	public static Optional<ButtonType> confirm(String text) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION, text, ButtonType.YES, ButtonType.NO);
		Button yesButton = (Button) alert.getDialogPane().lookupButton(ButtonType.YES);
		yesButton.setDefaultButton(false);
		Button noButton = (Button) alert.getDialogPane().lookupButton(ButtonType.NO);
		noButton.setDefaultButton(true);
		alert.setTitle("Mein Tagebuch");
		alert.setHeaderText("");
		return alert.showAndWait();
	}

	// Auswahl von Beginn- und Ende-Datum
	public static Optional<String[]> datePickerDialog() {
		Dialog<String[]> dialog = new Dialog<>();
		dialog.setTitle("Mein Tagebuch");
		dialog.setHeaderText("");
		ButtonType okButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
		dialog.getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

		DatePicker startDatePicker = new DatePicker(LocalDate.now());
		DatePicker endDatePicker = new DatePicker(LocalDate.now());

		GridPane grid = new GridPane();
		grid.setVgap(10);
		grid.setHgap(10);
		grid.add(new Label("Datum Beginn:"), 0, 0);
		grid.add(startDatePicker, 1, 0);
		grid.add(new Label("Datum Ende:"), 0, 1);
		grid.add(endDatePicker, 1, 1);

		dialog.getDialogPane().setContent(grid);

		dialog.setResultConverter(dialogButton -> {
			if (dialogButton == okButtonType) {
				return new String[]{startDatePicker.getValue().toString(),
						endDatePicker.getValue().toString()};
			}
			return null;
		});

		return dialog.showAndWait();
	}
}
