package diary;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiaryBackend {
	private final String dbPath;
	private Connection con;

	record Note(String date, String note) {}

	public DiaryBackend(String dbPath) {
		this.dbPath = dbPath;
	}

	public void open() {
		try {
			con = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
			Statement s = con.createStatement();
			String sql = "create table if not exists notes (date text primary key, note text)";
			s.executeUpdate(sql);
			s.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}

	public void close() {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				System.err.println(e.getMessage());
			}
		}
	}

	public String getNoteByDate(String date) {
		String note = null;
		try {
			String sql = "select note from notes where date = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, date);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				note = rs.getString(1);
			}
			ps.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return note;
	}

	public List<Note> getNotes(String begin, String end) {
		List<Note> notes = new ArrayList<>();
		try {
			String sql = "select date, note from notes where date between ? and ? order by date";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, begin);
			ps.setString(2, end);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				notes.add(new Note(rs.getString(1), rs.getString(2)));
			}
			ps.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		return notes;
	}

	public void saveNote(Note note) {
		try {
			//  insert or replace the existing row in a table
			String sql = "replace into notes values (?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, note.date);
			ps.setString(2, note.note);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}

	public void deleteNote(String date) {
		try {
			String sql = "delete from notes where date = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, date);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
