package diary;

import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.skin.DatePickerSkin;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class Diary extends Application {
	private static final String DB_PATH = "diary.db";
	private static final String HTML_PATH = "diary.html";

	private DiaryBackend diaryBackend;
	private DatePicker datePicker;
	private TextArea editor;
	private Button bHtml;
	private Button bEdit;
	private Button bCancel;
	private Button bSave;
	private Button bDelete;
	private boolean noteExists;

	@Override
	public void init() {
		diaryBackend = new DiaryBackend(DB_PATH);
		diaryBackend.open();
	}

	@Override
	public void start(Stage stage) {
		// Button-Beschriftungen beginnen mit dem Zeichen "_".
		// Durch Betätigung der Tastenkombination Alt + [erster Buchstabe] kann die
		// entsprechende Funktion ausgeführt werden
		bHtml = new Button("_HTML");
		bEdit = new Button("_Ändern");
		bCancel = new Button("_Zurück");
		bSave = new Button("_Speichern");
		bDelete = new Button("_Löschen");

		bHtml.setPrefWidth(100.);
		bEdit.setPrefWidth(100.);
		bCancel.setPrefWidth(100.);
		bSave.setPrefWidth(100.);
		bDelete.setPrefWidth(100.);

		datePicker = new DatePicker();
		DatePickerSkin datePickerSkin = new DatePickerSkin(datePicker);
		Node popupContent = datePickerSkin.getPopupContent();

		editor = new TextArea();
		editor.setWrapText(true);
		editor.setPrefColumnCount(50);
		editor.setPrefRowCount(12);
		editor.setStyle("-fx-font-size: 18.0;");

		bHtml.setOnAction(e -> generateHtml());
		bEdit.setOnAction(e -> editNote());
		bCancel.setOnAction(e -> display());
		bSave.setOnAction(e -> save());
		bDelete.setOnAction(e -> delete());
		datePicker.setOnAction(e -> display());

		VBox vBox1 = new VBox();
		vBox1.getChildren().add(popupContent);
		vBox1.setPrefWidth(380.);

		VBox vBox2 = new VBox();
		vBox2.getChildren().addAll(bHtml, bEdit, bCancel, bSave, bDelete);
		vBox2.setSpacing(5.);

		AnchorPane root = new AnchorPane();
		root.getChildren().addAll(vBox1, vBox2, editor);
		AnchorPane.setTopAnchor(vBox1, 10.);
		AnchorPane.setLeftAnchor(vBox1, 10.);
		AnchorPane.setTopAnchor(vBox2, 10.);
		AnchorPane.setRightAnchor(vBox2, 10.);
		AnchorPane.setBottomAnchor(editor, 10.);
		AnchorPane.setLeftAnchor(editor, 10.);
		AnchorPane.setRightAnchor(editor, 10.);

		datePicker.setValue(LocalDate.now());
		display();

		Scene scene = new Scene(root, 550, 580);
		stage.setScene(scene);
		stage.setTitle("Mein Tagebuch");
		stage.show();
	}

	@Override
	public void stop() {
		diaryBackend.close();
	}

	private void generateHtml() {
		Optional<String[]> result = DiaryDialogs.datePickerDialog();
		if (result.isEmpty()) {
			return;
		}

		String begin = result.get()[0];
		String end = result.get()[1];
		if (end.compareTo(begin) < 0) {
			String temp = end;
			end = begin;
			begin = temp;
		}

		List<DiaryBackend.Note> notes = diaryBackend.getNotes(begin, end);
		if (notes.isEmpty()) {
			DiaryDialogs.info("Keine Einträge");
			return;
		}

		String question = "Gewählte Einträge: " + begin + " - " + end + "\nWeiter?";
		Optional<ButtonType> opt = DiaryDialogs.confirm(question);
		String finalBegin = begin;
		String finalEnd = end;
		opt.ifPresent(btnType -> {
			if (btnType == ButtonType.YES) {
				try {
					writeFile(finalBegin, finalEnd, notes);
					// Aufruf der HTML-Seite im Browser
					getHostServices().showDocument(HTML_PATH);
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
			}
		});
	}

	private void editNote() {
		bHtml.setDisable(true);
		bEdit.setDisable(true);
		bCancel.setDisable(false);
		bSave.setDisable(false);
		if (noteExists) {
			bDelete.setDisable(false);
		}
		editor.setEditable(true);
	}

	private void display() {
		bHtml.setDisable(false);
		bHtml.setDisable(false);
		bEdit.setDisable(false);
		bCancel.setDisable(true);
		bSave.setDisable(true);
		bDelete.setDisable(true);

		String date = datePicker.getValue().toString();
		String note = diaryBackend.getNoteByDate(date);
		if (note != null) {
			editor.setText(note);
			noteExists = true;
		} else {
			editor.setText("");
			noteExists = false;
		}

		editor.setEditable(false);
	}

	private void save() {
		String date = datePicker.getValue().toString();
		String note = editor.getText();
		diaryBackend.saveNote(new DiaryBackend.Note(date, note));
		DiaryDialogs.info("Notiz gespeichert");
		display();
	}

	private void delete() {
		Optional<ButtonType> opt = DiaryDialogs.confirm("Soll diese Notiz gelöscht werden?");
		opt.ifPresent(btnType -> {
			if (btnType == ButtonType.YES) {
				String date = datePicker.getValue().toString();
				diaryBackend.deleteNote(date);
			}
		});
		display();
	}

	private void writeFile(String begin, String end, List<DiaryBackend.Note> notes) throws IOException {
		String HTML_HEADER = """
				<!DOCTYPE html><html lang='de'>
				<head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>
				<title>Mein Tagebuch</title></head>
				<body style="font-family:'Verdana'; font-size: 18px; margin-left: 5%%; margin-right: 5%%;">
				<h2>Tagebuch: %s - %s</h2>
				""";
		String HTML_NOTE = "<p><strong>%s %s</strong><br>%s</p>";
		String HTML_FOOTER = "</body></html>";

		try (OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(HTML_PATH),
				StandardCharsets.UTF_8)) {
			out.write(String.format(HTML_HEADER, begin, end));
			for (DiaryBackend.Note note : notes) {
				LocalDate date = LocalDate.parse(note.date(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				String day = DateTimeFormatter.ofPattern("EEEE").format(date);
				String n = note.note().replace("\n", "<br>");
				out.write(String.format(HTML_NOTE, note.date(), day, n));
			}
			out.write(HTML_FOOTER);
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
