package kontakte2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Insert {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:kontakte.db";
		String sql = "insert into kontakte (vorname, nachname, email) values (?, ?, ?)";
		try (Connection con = DriverManager.getConnection(url);
			 PreparedStatement stmt = con.prepareStatement(sql)) {

			Scanner scanner = new Scanner(System.in);
			String weiter;
			do {
				System.out.print("Vorname: ");
				String vorname = scanner.nextLine();
				System.out.print("Nachname: ");
				String nachname = scanner.nextLine();
				System.out.print("eMail: ");
				String email = scanner.nextLine();
				System.out.print("Weiter (j/n)? ");

				stmt.setString(1, vorname);
				stmt.setString(2, nachname);
				stmt.setString(3, email);
				stmt.executeUpdate();

				weiter = scanner.nextLine();
			} while (weiter.equals("j"));
			scanner.close();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
