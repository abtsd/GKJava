package erfassung;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Erfassung extends Application {
	private static final String DB_URL = "jdbc:sqlite:../kap29/mydb.db";
	private TextField tfNummer;
	private TextField tfBezeichnung;
	private TextField tfPreis;
	private Label lbMessage;
	private Connection con;
	private PreparedStatement ps;
	private String errorMessage;

	@Override
	public void init() {
		try {
			con = DriverManager.getConnection(DB_URL);
			String sql = "insert into artikel (id, name, preis) values(?, ?, ?)";
			ps = con.prepareStatement(sql);
		} catch (Exception e) {
			errorMessage = e.getMessage();
		}
	}

	@Override
	public void start(Stage stage) {
		AnchorPane anchorPane = new AnchorPane();
		GridPane gridPane = new GridPane();

		tfNummer = new TextField();
		tfNummer.setMaxWidth(100);
		tfBezeichnung = new TextField();
		tfBezeichnung.setPrefWidth(400);
		tfPreis = new TextField();
		tfPreis.setMaxWidth(100);
		lbMessage = new Label();
		lbMessage.setId("message");

		Button button = new Button();
		button.setText("Speichern");
		button.setOnAction(e -> save());

		gridPane.setHgap(20);
		gridPane.setVgap(20);
		gridPane.add(new Label("Artikelnummer"), 0, 0);
		gridPane.add(new Label("Bezeichnung"), 0, 1);
		gridPane.add(new Label("Preis"), 0, 2);
		gridPane.add(tfNummer, 1, 0);
		gridPane.add(tfBezeichnung, 1, 1);
		gridPane.add(tfPreis, 1, 2);
		gridPane.add(lbMessage, 1, 3);
		gridPane.add(button, 1, 4);

		anchorPane.getChildren().add(gridPane);
		anchorPane.setPrefWidth(600);
		anchorPane.setPrefHeight(300);
		AnchorPane.setLeftAnchor(gridPane, 30.);
		AnchorPane.setTopAnchor(gridPane, 30.);

		Scene scene = new Scene(anchorPane);
		scene.getStylesheets().add(getClass().getResource("Erfassung.css").toExternalForm());
		stage.setScene(scene);
		stage.setTitle("Artikel erfassen");
		stage.show();

		if (errorMessage != null) {
			showDialog(errorMessage);
		}
	}
	
	@Override
	public void stop() {
		if (con != null) {
			try {
				ps.close();
				con.close();
			} catch (Exception e) {
				showDialog(e.getMessage());
			}
		}
	}

	private void save() {
		lbMessage.setText("");

		int nummer;
		try {
			nummer = Integer.parseInt(tfNummer.getText().trim());
		} catch (NumberFormatException e) {
			lbMessage.setText("Artikelnummer muss eine ganze Zahl sein.");
			tfNummer.requestFocus();
			return;
		}

		String bezeichnung = tfBezeichnung.getText().trim();
		if (bezeichnung.isEmpty()) {
			lbMessage.setText("Bezeichnung darf nicht leer sein.");
			tfBezeichnung.requestFocus();
			return;
		}

		double preis;
		try {
			preis = Double.parseDouble(tfPreis.getText().trim());
		} catch (NumberFormatException e) {
			lbMessage.setText("Preis muss eine Zahl sein.");
			tfPreis.requestFocus();
			return;
		}

		try {
			ps.setInt(1, nummer);
			ps.setString(2, bezeichnung);
			ps.setDouble(3, preis);

			ps.executeUpdate();

			tfNummer.setText("");
			tfBezeichnung.setText("");
			tfPreis.setText("");
		} catch (Exception e) {
			showDialog(e.getMessage());
		}
	}

	private void showDialog(String text) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("Fehler");
		alert.setHeaderText("Exception");
		alert.setContentText(text);
		alert.showAndWait();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
