package kontakte3;

import java.sql.*;

public class Select {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:kontakte.db";
		try (Connection con = DriverManager.getConnection(url);
			 Statement stmt = con.createStatement()) {
			String sql = "select id, nachname, vorname, email from kontakte order by nachname, vorname";
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				System.out.printf("%4d %-15s %-15s %-15s%n",
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4));
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
