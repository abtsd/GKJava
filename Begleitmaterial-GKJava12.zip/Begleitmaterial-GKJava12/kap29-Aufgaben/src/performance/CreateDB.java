package performance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:test.db";
		try (Connection con = DriverManager.getConnection(url);
			 Statement stmt = con.createStatement()) {

			String sql1 = """
				create table test1 (
					id integer primary key,
					name text,
					description text)
				""";

			String sql2 = """
				create table test2 (
					id integer primary key,
					name text,
					description text)
				""";

			stmt.executeUpdate(sql1);
			stmt.executeUpdate(sql2);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
