package performance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Test1 {
	public static void main(String[] args) throws Exception {
		String url = "jdbc:sqlite:test.db";

		int insertCount = 10_000_000;

		try (Connection con = DriverManager.getConnection(url)) {
			Statement stmt = con.createStatement();

			long begin = System.currentTimeMillis();
			con.setAutoCommit(false);
			for (int i = 1; i <= insertCount; i++) {
				stmt.executeUpdate(String.format("""
					insert into test1 (id, name, description)
						values (%d, 'Name #%d', 'Description #%d')
					""", i, i, i));
			}
			con.commit();
			long end = System.currentTimeMillis();
			System.out.println(end - begin);
		}
	}
}
