package kontakte4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Delete {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:kontakte.db";
		String sql = "delete from kontakte where vorname = ? and nachname = ?";

		try (Connection con = DriverManager.getConnection(url);
			 PreparedStatement stmt = con.prepareStatement(sql)) {

			Scanner scanner = new Scanner(System.in);
			System.out.print("Vorname: ");
			String vorname = scanner.nextLine();
			System.out.print("Nachname: ");
			String nachname = scanner.nextLine();
			scanner.close();

			stmt.setString(1, vorname);
			stmt.setString(2, nachname);
			int n = stmt.executeUpdate();
			System.out.println(n + " Kontakt(e) gelöscht");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
