package kontakte1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:kontakte.db";
		try (Connection con = DriverManager.getConnection(url);
			 Statement stmt = con.createStatement()) {
			String sql = """
				create table if not exists kontakte (
					id integer primary key,
					vorname text,
					nachname text,
					email text)
				""";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
