package products;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Backend {
	public static final Backend INSTANCE = new Backend();

	private static final String DB_URL = "jdbc:sqlite:products.db";
	private Connection connection;

	private Backend() {
	}

	public void connect() throws BackendException {
		if (connection == null) {
			try {
				connection = DriverManager.getConnection(DB_URL);
				createTable();
			} catch (SQLException e) {
				throw new BackendException(e.getMessage(), e.getErrorCode());
			}
		}
	}

	public void close() {
		try {
			if (connection != null) {
				connection.close();
				connection = null;
			}
		} catch (SQLException ignored) {
		}
	}

	public List<Product> select(String text) throws BackendException {
		List<Product> list = new ArrayList<>();
		String sql = """
				select id, name, price, quantity from product
					where name like ? order by id
				""";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, "%" + text + "%");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				list.add(new Product(rs.getInt(1), rs.getString(2),
						rs.getDouble(3), rs.getInt(4)));
			}
			return list;
		} catch (SQLException e) {
			throw new BackendException(e.getMessage(), e.getErrorCode());
		}
	}

	public void insert(Product product) throws BackendException {
		String sql = "insert into product (id, name, price, quantity) values(?, ?, ?, ?)";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setInt(1, product.getId());
			ps.setString(2, product.getName());
			ps.setDouble(3, product.getPrice());
			ps.setInt(4, product.getQuantity());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new BackendException(e.getMessage(), e.getErrorCode());
		}
	}

	public void update(Product product) throws BackendException {
		String sql = "update product set name = ?, price = ?, quantity = ? where id = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, product.getName());
			ps.setDouble(2, product.getPrice());
			ps.setInt(3, product.getQuantity());
			ps.setInt(4, product.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new BackendException(e.getMessage(), e.getErrorCode());
		}
	}

	public void delete(int id) throws BackendException {
		try (Statement stmt = connection.createStatement()) {
			String sql = "delete from product where id = " + id;
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			throw new BackendException(e.getMessage(), e.getErrorCode());
		}
	}

	private void createTable() throws SQLException {
		try (Statement stmt = connection.createStatement()) {
			String sql = """
					create table if not exists product (
						id integer primary key,
						name text,
						price real,
						quantity integer)
					""";
			stmt.executeUpdate(sql);
		}
	}
}
