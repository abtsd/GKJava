package products;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Form {
	private final Main main;
	private final Stage stage;
	private final TextField tfId;
	private final TextField tfName;
	private final TextField tfPrice;
	private final TextField tfQuantity;
	private final TextField tfAdd;
	private final Label lbMessage;

	private int id;
	private String name;
	private double price;
	private int quantity;
	private int add;

	private boolean isNew;
	private final Backend backend;

	public Form(Main main, Product product) {
		this.main = main;
		backend = Backend.INSTANCE;

		if (product == null) {
			isNew = true;
		}

		stage = new Stage();
		AnchorPane anchorPane = new AnchorPane();
		GridPane gridPane = new GridPane();

		tfId = new TextField();
		tfId.setMaxWidth(100);
		tfName = new TextField();
		tfName.setPrefWidth(400);
		tfPrice = new TextField();
		tfPrice.setMaxWidth(100);
		tfQuantity = new TextField();
		tfQuantity.setMaxWidth(100);
		tfAdd = new TextField();
		tfAdd.setText("0");
		tfAdd.setMaxWidth(100);

		if (isNew) {
			tfPrice.setText("0");
			tfQuantity.setText("0");
		} else {
			tfId.setText(String.valueOf(product.getId()));
			tfName.setText(product.getName());
			tfPrice.setText(String.valueOf(product.getPrice()));
			tfQuantity.setText(String.valueOf(product.getQuantity()));
			tfId.setEditable(false);
			Platform.runLater(tfName::requestFocus);
		}

		lbMessage = new Label();
		lbMessage.setId("message");

		Button btnSave = new Button();
		btnSave.setText("Speichern");

		Button btnBack = new Button();
		btnBack.setText("Zurück");

		HBox box1 = new HBox();
		box1.setSpacing(10);
		Label lbAdd = new Label("   +/-");
		lbAdd.setId("add");
		box1.getChildren().addAll(tfQuantity, lbAdd, tfAdd);

		HBox box2 = new HBox();
		box2.setSpacing(10);
		box2.getChildren().addAll(btnSave, btnBack);

		gridPane.setHgap(20);
		gridPane.setVgap(20);
		gridPane.add(new Label("Id"), 0, 0);
		gridPane.add(new Label("Name"), 0, 1);
		gridPane.add(new Label("Preis"), 0, 2);
		gridPane.add(new Label("Menge"), 0, 3);
		gridPane.add(tfId, 1, 0);
		gridPane.add(tfName, 1, 1);
		gridPane.add(tfPrice, 1, 2);
		gridPane.add(box1, 1, 3);
		gridPane.add(lbMessage, 1, 4);
		gridPane.add(box2, 1, 5);

		anchorPane.getChildren().add(gridPane);
		anchorPane.setPrefWidth(600);
		anchorPane.setPrefHeight(400);
		AnchorPane.setLeftAnchor(gridPane, 30.);
		AnchorPane.setTopAnchor(gridPane, 30.);

		btnSave.setOnAction(e -> save());
		btnBack.setOnAction(e -> stage.close());

		tfId.textProperty().addListener((observableValue, oldValue, newValue) -> checkId());
		tfName.textProperty().addListener((observableValue, oldValue, newValue) -> checkName());
		tfPrice.textProperty().addListener((observableValue, oldValue, newValue) -> checkPrice());
		tfQuantity.textProperty().addListener((observableValue, oldValue, newValue) -> checkQuantity());
		tfAdd.textProperty().addListener((observableValue, oldValue, newValue) -> checkAdd());

		Scene scene = new Scene(anchorPane);
		scene.getStylesheets().add(getClass().getResource("Form.css").toExternalForm());

		stage.setOnCloseRequest(Event::consume);
		stage.setScene(scene);
		stage.setTitle("Produkt");
		stage.setX(main.getStage().getX() + 50);
		stage.setY(main.getStage().getY() + 50);

		stage.initOwner(main.getStage());
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	private boolean checkId() {
		lbMessage.setText("");
		try {
			id = Integer.parseInt(tfId.getText());
		} catch (NumberFormatException e) {
			lbMessage.setText("Id muss eine ganze Zahl sein");
			tfId.requestFocus();
			return false;
		}
		return true;
	}

	private boolean checkName() {
		lbMessage.setText("");
		name = tfName.getText().trim();
		if (name.isEmpty()) {
			lbMessage.setText("Name fehlt");
			tfName.requestFocus();
			return false;
		}
		return true;
	}

	private boolean checkPrice() {
		lbMessage.setText("");
		try {
			price = Double.parseDouble(tfPrice.getText());
			if (price < 0) {
				lbMessage.setText("Preis ist negativ");
				tfPrice.requestFocus();
				return false;
			}
		} catch (NumberFormatException e) {
			lbMessage.setText("Preis ist keine Zahl");
			tfPrice.requestFocus();
			return false;
		}
		return true;
	}

	private boolean checkQuantity() {
		lbMessage.setText("");
		try {
			quantity = Integer.parseInt(tfQuantity.getText());
			if (quantity < 0) {
				lbMessage.setText("Menge ist < 0");
				return false;
			}
		} catch (NumberFormatException e) {
			lbMessage.setText("Menge ist keine ganze Zahl");
			tfQuantity.requestFocus();
			return false;
		}
		return true;
	}

	private boolean checkAdd() {
		lbMessage.setText("");
		try {
			add = Integer.parseInt(tfAdd.getText());
		} catch (NumberFormatException e) {
			lbMessage.setText("Zugang/Abgang ist keine ganze Zahl");
			tfAdd.requestFocus();
			return false;
		}
		return true;
	}

	private void save() {
		if (!checkId()) return;
		if (!checkName()) return;
		if (!checkPrice()) return;
		if (!checkQuantity()) return;
		if (!checkAdd()) return;

		quantity += add;
		if (quantity < 0) {
			lbMessage.setText("Neue Menge: " + quantity);
			tfAdd.requestFocus();
			return;
		}

		try {
			Product product = new Product(id, name, price, quantity);
			if (isNew) backend.insert(product);
			else backend.update(product);
			main.search();
			stage.close();
		} catch (BackendException e) {
			if (e.getCode() == 19) { // vendor-specific exception code
				Alert alert = new Alert(Alert.AlertType.ERROR);
				alert.setHeaderText("Id ist bereits vorhanden");
				alert.showAndWait();
			} else {
				Main.showError(e.getMessage());
				stage.close();
			}
		}
	}
}
