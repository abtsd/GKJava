package products;

public class BackendException extends Exception {
	private final int code;

	public BackendException(String message, int code) {
		super(message);
		this.code = code;
	}

	public int getCode() {
		return code;
	}
}
