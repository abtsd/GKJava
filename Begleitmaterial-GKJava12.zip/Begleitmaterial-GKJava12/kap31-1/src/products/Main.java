package products;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;

public class Main extends Application {
	private Stage stage;
	private TextField tfSearch;
	private TableView<Product> tableView;
	private Label lbMessage;

	private Backend backend;
	private String errorMessage;
	private String currentSearchText = "";

	@Override
	public void init() {
		try {
			backend = Backend.INSTANCE;
			backend.connect();
		} catch (BackendException e) {
			errorMessage = e.getMessage();
		}
	}

	@Override
	public void start(Stage stage) {
		if (errorMessage != null) {
			showError(errorMessage);
			return;
		}

		this.stage = stage;
		AnchorPane root = new AnchorPane();

		tfSearch = new TextField();
		tfSearch.setPromptText("Nach Namen suchen");
		tfSearch.setPrefWidth(300);

		Button btnSearch = new Button("Suchen");
		Platform.runLater(btnSearch::requestFocus);
		Button btnNew = new Button("Neu");
		Button btnUpdate = new Button("Ändern");
		Button btnDelete = new Button("Löschen");
		Button btnExit = new Button("Beenden");

		tableView = new TableView<>();

		TableColumn<Product, Integer> id = new TableColumn<>("Id");
		TableColumn<Product, String> name = new TableColumn<>("Name");
		TableColumn<Product, Double> price = new TableColumn<>("Preis");
		TableColumn<Product, Integer> quantity = new TableColumn<>("Menge");

		id.setId("id");
		name.setId("name");
		price.setId("price");
		quantity.setId("quantity");

		tableView.getColumns().addAll(id, name, price, quantity);
		tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
		name.setMinWidth(200);

		id.setCellValueFactory(new PropertyValueFactory<>("id"));
		name.setCellValueFactory(new PropertyValueFactory<>("name"));
		price.setCellValueFactory(new PropertyValueFactory<>("price"));
		quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

		price.setCellFactory(column -> new TableCell<>() {
			protected void updateItem(Double item, boolean empty) {
				super.updateItem(item, empty);

				if (empty || item == null) {
					setText(null);
				} else {
					setText(String.format("%8.2f", item));
					setAlignment(Pos.CENTER_RIGHT);
				}
			}
		});

		quantity.setCellFactory(column -> new TableCell<>() {
			protected void updateItem(Integer item, boolean empty) {
				super.updateItem(item, empty);

				if (empty || item == null) {
					setText(null);
				} else {
					setText(String.valueOf(item));
					setAlignment(Pos.CENTER_RIGHT);
				}
			}
		});

		lbMessage = new Label();

		HBox box1 = new HBox();
		box1.setSpacing(10);
		box1.getChildren().addAll(tfSearch, btnSearch);

		HBox box2 = new HBox();
		box2.setSpacing(10);
		box2.getChildren().addAll(btnNew, btnUpdate, btnDelete, btnExit);

		root.getChildren().addAll(box1, box2, tableView, lbMessage);

		root.setPrefWidth(700);
		root.setPrefHeight(500);

		AnchorPane.setTopAnchor(box1, 12.);
		AnchorPane.setLeftAnchor(box1, 12.);

		AnchorPane.setTopAnchor(box2, 12.);
		AnchorPane.setRightAnchor(box2, 12.);

		AnchorPane.setTopAnchor(tableView, 60.);
		AnchorPane.setLeftAnchor(tableView, 12.);
		AnchorPane.setRightAnchor(tableView, 12.);
		AnchorPane.setBottomAnchor(tableView, 50.);

		AnchorPane.setBottomAnchor(lbMessage, 12.);
		AnchorPane.setLeftAnchor(lbMessage, 12.);

		btnSearch.setOnAction(e -> {
			currentSearchText = tfSearch.getText();
			search();
		});

		btnNew.setOnAction(e -> new Form(this, null));

		btnUpdate.setOnAction(e -> {
			Product product = tableView.getSelectionModel().getSelectedItem();
			if (product != null)
				new Form(this, product);
		});

		btnDelete.setOnAction(e -> {
			Product product = tableView.getSelectionModel().getSelectedItem();
			try {
				if (product != null && confirmed()) {
					backend.delete(product.getId());
					search();
				}
			} catch (BackendException ex) {
				showError(ex.getMessage());
			}
		});

		btnExit.setOnAction(e -> stage.close());

		search();

		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("Main.css").toExternalForm());

		stage.setOnCloseRequest(Event::consume);
		stage.setTitle("Sortiment");
		stage.setScene(scene);
		stage.show();
	}

	@Override
	public void stop() {
		backend.close();
	}

	public Stage getStage() {
		return stage;
	}

	public void search() {
		try {
			List<Product> products = backend.select(currentSearchText);
			ObservableList<Product> list = FXCollections.observableArrayList(products);
			tableView.setItems(list);
			lbMessage.setText("Anzahl: " + list.size());
		} catch (BackendException e) {
			showError(e.getMessage());
		}
	}

	public static void showError(String text) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setContentText(text);
		alert.showAndWait();
	}

	private boolean confirmed() {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setContentText("Soll das Produkt wirklich gelöscht werden?");
		Optional<ButtonType> option = alert.showAndWait();
		return option.get() == ButtonType.OK;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
