public class Pruefen {
	public static void main(String[] args) {
		int[] x = {1, 7, 4, 5, 7, 8};
		boolean hasDuplicates = false;

		loop:
		for (int i = 0; i < x.length - 1; i++) {
			for (int j = i + 1; j < x.length; j++) {
				if (x[i] == x[j]) {
					hasDuplicates = true;
					break loop;
				}
			}
		}

		System.out.println("Duplikate? " + hasDuplicates);
	}
}
