public class Statistik {
	public static void main(String[] args) {
		int[] x = {5, 5, 2, 3, 8, 9, 5, 10, 7};

		int min = x[0];
		int max = x[0];
		long sum = x[0];

		for (int i = 1; i < x.length; i++) {
			if (x[i] < min)
				min = x[i];
			if (x[i] > max)
				max = x[i];
			sum += x[i];
		}

		System.out.println("Minimum: " + min);
		System.out.println("Maximum: " + max);
		System.out.println("Mittelwert: " + (double) sum / x.length);
	}
}
