public class Matrix {
	public static void main(String[] args) {
		int[][] x = new int[20][20];

		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < x[i].length; j++) {
				x[i][j] = i * j;
				System.out.print(x[i][j] + " ");
			}
			System.out.println();
		}
	}
}
