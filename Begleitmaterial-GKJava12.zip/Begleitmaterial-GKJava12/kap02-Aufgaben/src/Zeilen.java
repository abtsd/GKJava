public class Zeilen {
	public static void main(String[] args) {
		System.out.print("Text1\nText2\nText3");
	}
}
