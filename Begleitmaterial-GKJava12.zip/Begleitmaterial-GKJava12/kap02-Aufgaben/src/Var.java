public class Var {
	public static void main(String[] args) {
		var x = 0xAA00;
		var y = 0b10101010;

		System.out.println(x);
		System.out.println(y);
	}
}
