public class Zahlen {
	public static void main(String[] args) {
		int x = 0xAA00;
		int y = 0b10101010;

		System.out.println(x);
		System.out.println(y);
	}
}
