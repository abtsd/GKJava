public class Fehler {
	public static void main(String[] args) {
		int x = 0;
		long y = 1000;

		// Inkompatible Typen: Möglicher Verlust bei Konvertierung von long in int
		// x = y;
		System.out.println(x);
	}
}

