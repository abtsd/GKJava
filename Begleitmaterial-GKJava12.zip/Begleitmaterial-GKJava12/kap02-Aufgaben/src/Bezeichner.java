public class Bezeichner {
	public static void main(String[] args) {
		int Hallo_Welt;
		int $Test;
		int _abc;
//		int 2test;
//		int #hallo;
//		int te?st;
		int Girokonto;
//		int const;
	}
}
