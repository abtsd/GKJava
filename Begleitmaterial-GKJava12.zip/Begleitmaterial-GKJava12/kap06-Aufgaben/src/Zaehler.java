public class Zaehler {
	private int wert;

	public void hochzaehlen() {
		wert += 1;
	}

	public void zuruecksetzen() {
		wert = 0;
	}

	public int getWert() {
		return wert;
	}

	public static void main(String[] args) {
		Zaehler z = new Zaehler();
		System.out.println(z.getWert());
		z.hochzaehlen();
		z.hochzaehlen();
		System.out.println(z.getWert());
		z.zuruecksetzen();
		System.out.println(z.getWert());
	}
}
