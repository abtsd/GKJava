record MinMaxValues(double min, double max) {}

public class MinMax {
	public static MinMaxValues minMax(double a, double... args) {
		double min = a;
		double max = a;

		for (double n : args) {
			if (n > a) {
				max = n;
			} else {
				min = n;
			}
		}

		return new MinMaxValues(min, max);
	}

	public static void main(String[] args) {
		MinMaxValues values = minMax(3.5, 1.2, 3.55, 0.8, 6.5);
		System.out.println("Minimum: " + values.min() + ", Maximun: " + values.max());
	}
}
