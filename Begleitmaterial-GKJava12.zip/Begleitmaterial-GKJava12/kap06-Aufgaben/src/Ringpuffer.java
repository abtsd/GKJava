public class Ringpuffer {
	private final int[] inhalt;
	private int idx;
	private boolean voll;

	public Ringpuffer(int length) {
		inhalt = new int[length];
		idx = 0;
		voll = false;
	}

	public void schreibe(int v) {
		if (idx >= inhalt.length)
			return;

		inhalt[idx] = v;
		if (idx == inhalt.length - 1)
			voll = true;
		idx = (idx + 1) % inhalt.length;
	}

	public void lies() {
		if (!voll) {
			for (int i = 0; i < idx; i++) {
				System.out.print(inhalt[i] + " ");
			}
		} else {
			for (int j : inhalt) {
				System.out.print(j + " ");
			}
		}
		
		System.out.println();
	}

	public static void main(String[] args) {
		Ringpuffer puffer = new Ringpuffer(5);

		for (int i = 1; i <= 11; i++) {
			puffer.schreibe(100 + i);
		}

		puffer.lies();
	}
}
