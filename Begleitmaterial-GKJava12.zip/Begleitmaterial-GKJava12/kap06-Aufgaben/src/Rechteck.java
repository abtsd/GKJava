public class Rechteck {
	private final double breite;
	private final double hoehe;

	public Rechteck(double breite, double hoehe) {
		this.breite = breite;
		this.hoehe = hoehe;
	}

	public Rechteck(double laenge) {
		this(laenge, laenge);
	}

	public double flaeche() {
		return breite * hoehe;
	}

	public double umfang() {
		return (breite + hoehe) * 2;
	}

	public static void main(String[] args) {
		Rechteck rechteck = new Rechteck(3.5, 2);
		System.out.println(rechteck.flaeche());
		System.out.println(rechteck.umfang());

		Rechteck quadrat = new Rechteck(5);
		System.out.println(quadrat.flaeche());
		System.out.println(quadrat.umfang());
	}
}
