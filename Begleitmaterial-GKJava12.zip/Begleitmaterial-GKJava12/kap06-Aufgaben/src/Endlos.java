public class Endlos {
	public static void test() {
		test();
	}

	public static void main(String[] args) {
		test();
	}
}
