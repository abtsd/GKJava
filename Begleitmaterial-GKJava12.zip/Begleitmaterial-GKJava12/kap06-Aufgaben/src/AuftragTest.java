public class AuftragTest {
	public static void main(String[] args) {
		Artikel artikel1 = new Artikel(4711, 1.99);
		Artikel artikel2 = new Artikel(5000, 10.);

		Auftrag auftrag1 = new Auftrag(artikel1, 100);
		Auftrag auftrag2 = new Auftrag(artikel2, 50);

		double gesamtwert = Auftrag.getGesamtwert(auftrag1, auftrag2);
		System.out.println(gesamtwert);
	}
}
