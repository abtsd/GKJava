public class Verzinsung {
	public static double zinsen1(double kapital, double zinssatz, int jahre) {
		for (int i = 0; i < jahre; i++) {
			kapital *= (1 + zinssatz);
		}
		return kapital;
	}

	public static double zinsen2(double kapital, double zinssatz, int jahre) {
		if (jahre == 0)
			return kapital;
		return zinsen2(kapital, zinssatz, jahre - 1) * (1 + zinssatz);
	}

	public static void main(String[] args) {
		System.out.println(zinsen1(1000, 0.015, 10));
		System.out.println(zinsen2(1000, 0.015, 10));
	}
}
