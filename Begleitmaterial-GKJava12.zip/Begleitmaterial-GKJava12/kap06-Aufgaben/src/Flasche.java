public class Flasche {
    private static final int MAX_DEFAULT = 500;
    private final int id;
    private int inhalt;
    private final int fassungsVermoegen;

    public Flasche(int id, int inhalt, int fassungsVermoegen) {
        this.id = id;
        this.inhalt = inhalt;
        this.fassungsVermoegen = fassungsVermoegen;
    }

    public Flasche(int id, int inhalt) {
        this(id, inhalt, MAX_DEFAULT);
    }

    public Flasche(int id, double prozent, int fassungsVermoegen) {
        this(id, (int) (prozent * fassungsVermoegen), fassungsVermoegen);
    }

    public int getId() {
        return id;
    }

    public int getInhalt() {
        return inhalt;
    }

    public void setInhalt(int inhalt) {
        if (inhalt < 0) this.inhalt = 0;
        else this.inhalt = min(inhalt, fassungsVermoegen);
    }

    public int getFassungsVermoegen() {
        return fassungsVermoegen;
    }

    public int verbleibendeKapazitaet() {
        return fassungsVermoegen - inhalt;
    }

    public void fuellen(int value) {
        if (value < 0) return;
        setInhalt(inhalt + value);
    }

    public void verschuetten(int value) {
        if (value < 0) return;
        setInhalt(inhalt - value);
    }

    public void umfuellenIn(Flasche other) {
        int amount = min(inhalt, other.verbleibendeKapazitaet());
        inhalt -= amount;
        other.inhalt += amount;
    }

    public boolean istLeer() {
        return inhalt == 0;
    }

    public boolean istVoll() {
        return inhalt == fassungsVermoegen;
    }

    public double getFuellGrad() {
        return 100. * inhalt / fassungsVermoegen;
    }

    public Flasche groessereFlasche(Flasche andereFlasche) {
        if (fassungsVermoegen > andereFlasche.fassungsVermoegen)
            return this;
        else return andereFlasche;
    }

    public void info() {
        System.out.println("Flasche: " + id);
        System.out.println("Füllstand in ml: " + inhalt);
        System.out.println("Füllstand in %: " + getFuellGrad());
        System.out.println("Max. Füllmenge in ml: " + fassungsVermoegen);
    }

    private int min(int a, int b) {
        return a < b ? a : b;
    }

    @Override
    public String toString() {
        return "Flasche{" +
                "id=" + id +
                ", inhalt=" + inhalt +
                ", fassungsVermoegen=" + fassungsVermoegen +
                '}';
    }

    public static void main(String[] args) {
        Flasche fl1 = new Flasche(1, 150);
        Flasche fl2 = new Flasche(2, 300, 600);

        fl1.fuellen(200);
        fl1.verschuetten(20);
        fl1.info();

        fl1.umfuellenIn(fl2);
        fl1.info();
        fl2.info();

        System.out.println("Inhalt: " + fl2.getInhalt());
        System.out.println("Fassungsvermögen: " + fl2.getFassungsVermoegen());

        System.out.println(fl2.getId() + " voll? " + fl2.istVoll());

        fl1.verschuetten(30);
        System.out.println(fl1.getId() + " leer? " + fl1.istLeer());

        fl1.setInhalt(250);
        System.out.println(fl1.getFuellGrad());
        System.out.println(fl1.verbleibendeKapazitaet());

        Flasche fl3 = new Flasche(3, 0.25, 600);
        fl3.info();

        Flasche groessereFlasche = fl1.groessereFlasche(fl2);
        System.out.println(groessereFlasche);
        groessereFlasche = fl2.groessereFlasche(fl1);
        System.out.println(groessereFlasche);
    }
}
