public class Halbieren {
	public static double halbiere(double zahl) {
		zahl /= 2;
		if (zahl > 0.2) {
			System.out.println(zahl);
			return halbiere(zahl);
		} else {
			return zahl;
		}
	}

	public static void main(String[] args) {
		System.out.println("Ergebnis: " + halbiere(7.5));
	}
}
