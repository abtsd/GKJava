public class Abschreibung {
	private double preis;
	private final int jahre;
	private double satz;

	public Abschreibung(double preis, int jahre) {
		this.preis = preis;
		this.jahre = jahre;
	}

	public Abschreibung(double preis, int jahre, double satz) {
		this.preis = preis;
		this.jahre = jahre;
		this.satz = satz;
	}

	public void schreibeLinear() {
		double x = preis / jahre;
		System.out.println("Lineare Abschreibung:");
		for (int i = 1; i <= jahre; i++) {
			preis -= x;
			System.out.println(i + "\t" + preis);
		}
	}

	public void schreibeDegressiv() {
		System.out.println("Geometrisch degressive Abschreibung:");
		for (int i = 1; i <= jahre; i++) {
			preis *= 1 - satz / 100;
			System.out.println(i + "\t" + preis);
		}
	}

	public static void main(String[] args) {
		Abschreibung ab = new Abschreibung(15000, 5);
		ab.schreibeLinear();
		System.out.println();

		ab = new Abschreibung(15000, 5, 40);
		ab.schreibeDegressiv();
	}
}
