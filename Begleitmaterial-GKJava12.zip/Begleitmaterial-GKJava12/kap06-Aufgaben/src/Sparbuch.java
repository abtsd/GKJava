public class Sparbuch {
	private final int kontonummer;
	private double kapital;
	private final double zinssatz;

	public Sparbuch(int kontonummer, double kapital, double zinssatz) {
		this.kontonummer = kontonummer;
		this.kapital = kapital;
		this.zinssatz = zinssatz;
	}

	public void zahleEin(double betrag) {
		kapital += betrag;
	}

	public void hebeAb(double betrag) {
		kapital -= betrag;
	}

	public double getErtrag(int laufzeit) {
		double p = 1 + zinssatz / 100;
		double q = 1;

		for (int i = 0; i < laufzeit; i++) {
			q *= p;
		}

		return kapital * q;
	}

	public void verzinse() {
		kapital *= 1 + zinssatz / 100;
	}

	public int getKontonummer() {
		return kontonummer;
	}

	public double getKapital() {
		return kapital;
	}

	public double getZinssatz() {
		return zinssatz;
	}

	public static void main(String[] args) {
		Sparbuch sb = new Sparbuch(4711, 1000, 1.5);
		System.out.println("Kontonummer: " + sb.getKontonummer());
		System.out.println("Kapital: " + sb.getKapital());
		System.out.println("Zinssatz: " + sb.getZinssatz());

		sb.hebeAb(1000);
		System.out.println("Kapital: " + sb.getKapital());

		sb.zahleEin(60000);
		System.out.println("Kapital: " + sb.getKapital());

		System.out.println("Ertrag nach 6 Jahr: " + sb.getErtrag(6));

		sb.verzinse();
		System.out.println("Kapital: " + sb.getKapital());
	}
}
