public class LocalTest {
	private int x = 1;

	public void test() {
		int x = 0;
		
		System.out.println(x);
		System.out.println(this.x);
		
		{
			x = 2;
			int y = 3;
			System.out.println(x + y);
		}
		
		System.out.println(x);
	}
	
	public static void main(String[] args) {
		LocalTest a = new LocalTest();
		a.test();
	}
}
