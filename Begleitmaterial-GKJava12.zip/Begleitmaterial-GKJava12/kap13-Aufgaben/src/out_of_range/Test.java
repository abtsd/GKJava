package out_of_range;

public class Test {
	public static void main(String[] args) {
		test(40);
		test(Person.MIN_ALTER - 1);
		test(Person.MAX_ALTER + 1);
	}

	private static void test(int alter) {
		try {
			Person p = new Person(alter, "Hugo");
			System.out.println(p);
		} catch (OutOfRangeException e) {
			System.out.println(e.getMessage());
		}
	}
}
