package out_of_range;

public class Person {
	public static final int MIN_ALTER = 0;
	public static final int MAX_ALTER = 120;

	private final int alter;
	private final String name;

	public Person(int alter, String name) {
		if (alter < MIN_ALTER || alter > MAX_ALTER) {
			throw new OutOfRangeException(alter, MIN_ALTER, MAX_ALTER);
		}
		
		this.alter = alter;
		this.name = name;
	}

	public String toString() {
		return name + " ist " + alter + " Jahre alt";
	}
}
