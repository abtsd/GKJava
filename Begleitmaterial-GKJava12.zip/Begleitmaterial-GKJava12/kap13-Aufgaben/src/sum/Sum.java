package sum;

public class Sum {
	public static long sum(int n) {
		if (n <= 0)
			throw new IllegalArgumentException();

		long sum = 0;
		for (int i = 1; i <= n; i++) {
			sum += i;
		}
		return sum;
	}

	public static void main(String[] args) {
		try {
			System.out.println(sum(100));
			System.out.println(sum(-1));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
	}
}
