package monat;

public class Test {
	public static void main(String[] args) {
		try {
			Monat m1 = new Monat(4);
			System.out.println(m1.getMonatsname());
			Monat m2 = new Monat(13);
			System.out.println(m2.getMonatsname());
		} catch (MonatAusnahme e) {
			System.out.println(e.getMessage());
		}
	}
}
