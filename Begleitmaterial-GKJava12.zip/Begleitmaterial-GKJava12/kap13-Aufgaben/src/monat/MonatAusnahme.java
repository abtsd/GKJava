package monat;

public class MonatAusnahme extends Exception {
	public MonatAusnahme() {
	}

	public MonatAusnahme(int monat) {
		super(monat + " ist kein Monat");
	}
}
