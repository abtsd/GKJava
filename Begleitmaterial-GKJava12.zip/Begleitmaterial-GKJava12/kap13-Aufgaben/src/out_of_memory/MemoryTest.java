package out_of_memory;

public class MemoryTest {
	public static void main(String[] args) {
		int MAX = 1_000_000_000;
		long[] zahlen = new long[MAX];
		for (int i = 0; i < MAX; i++) {
			zahlen[i] = i;
		}
	}
}
