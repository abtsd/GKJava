package random;

public class CatchZero {
	static final int MAX = 500;

	public static int getZufallszahl() throws Exception {
		int zufallszahl = (int) (Math.random() * 100.);
		if (zufallszahl == 0)
			throw new Exception("*** Zahl ist 0 ***");
		return zufallszahl;
	}

	public static void main(String[] args) {
		for (int i = 0; i < MAX; i++) {
			try {
				System.out.println(getZufallszahl());
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
