package list;

public interface MyList<E> extends Iterable<E> {
	// Neues Element an erster Stelle einfügen
	void addFirst(E obj);

	// Neues Element an letzter Stelle einfügen
	void addLast(E obj);

	// Prüft, ob ein Element in der Liste vorhanden ist
	boolean contains(E obj);

	// Prüft, ob die Liste leer ist
	boolean isEmpty();

	// Liefert die Anzahl Elemente in der Liste
	int size();

	// Liefert das erste Element der Liste
	E getFirst();

	// Liefert das letzte Element der Liste
	E getLast();

	// Liefert das Element an der Position index
	E get(int index);

	// Entfernt ein Element aus der Liste
	boolean remove(E obj);
}
