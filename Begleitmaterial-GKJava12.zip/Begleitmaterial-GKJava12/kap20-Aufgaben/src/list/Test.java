package list;

public class Test {
	public static void print(MyList<Integer> list) {
		for (Integer i : list) {
			System.out.print(i + " ");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		MyList<Integer> list = new MyArrayList<>();
		System.out.println("isEmpty(): " + list.isEmpty());

		for (int i = 1; i <= 4; i++) {
			list.addLast(i);
		}
		list.addFirst(0);

		print(list);
		System.out.println("size(): " + list.size());
		System.out.println("getFirst(): " + list.getFirst());
		System.out.println("getLast(): " + list.getLast());
		System.out.println("get(2): " + list.get(2));
		System.out.println("contains(3) " + list.contains(3));
		System.out.println("remove(4) " + list.remove(4));
		print(list);
	}
}
