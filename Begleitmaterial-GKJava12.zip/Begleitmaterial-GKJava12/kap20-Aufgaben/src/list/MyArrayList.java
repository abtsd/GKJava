package list;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyArrayList<E> implements MyList<E> {
	private static final int BLOCK_SIZE = 20;
	private Object[] data = new Object[BLOCK_SIZE];
	private int freePosition = 0;

	private void expandIfNeeded() {
		if (freePosition >= data.length) {
			Object[] newData = new Object[data.length + BLOCK_SIZE];
			System.arraycopy(data, 0, newData, 0, size());
			data = newData;
		}
	}

	@Override
	public void addFirst(E obj) {
		expandIfNeeded();
		System.arraycopy(data, 0, data, 1, size());
		data[0] = obj;
		freePosition++;
	}

	@Override
	public void addLast(E obj) {
		expandIfNeeded();
		data[freePosition++] = obj;
	}

	@Override
	public boolean contains(E obj) {
		for (int i = 0; i < freePosition; i++) {
			if (data[i].equals(obj))
				return true;
		}
		return false;
	}

	@Override
	public boolean isEmpty() {
		return freePosition == 0;
	}

	@Override
	public int size() {
		return freePosition;
	}

	@Override
	public E getFirst() {
		return get(0);
	}

	@Override
	public E getLast() {
		return get(freePosition - 1);
	}

	@Override
	public E get(int index) {
		if (index >= 0 && index < freePosition) {
			//noinspection unchecked
			return (E) data[index];
		} else {
			throw new ArrayIndexOutOfBoundsException("index = " + index);
		}
	}

	@Override
	public boolean remove(E obj) {
		int idx = 0;
		while (idx < freePosition && !data[idx].equals(obj)) {
			idx++;
		}

		if (idx == freePosition)
			return false;

		System.arraycopy(data, idx + 1, data, idx, freePosition - idx - 1);
		freePosition--;
		return true;
	}

	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			private int idx = 0;

			@Override
			public boolean hasNext() {
				return idx < freePosition;
			}

			@Override
			public E next() {
				if (idx < freePosition) {
					Object obj = data[idx];
					idx++;
					//noinspection unchecked
					return (E) obj;
				} else {
					throw new NoSuchElementException();
				}
			}
		};
	}
}
