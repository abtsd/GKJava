package convert;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Test {
	public static void main(String[] args) {
		List<String> list = List.of("Hugo", "Emil", "Emil");
		System.out.println("Liste: " + list);
		Set<String> set = new HashSet<>(list);
		System.out.println("Menge: " + set);
		List<String> list2 = new ArrayList<>(set);
		System.out.println("Liste: " + list2);
	}
}
