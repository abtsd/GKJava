package set_op;

import java.util.Set;

public class Test {
    public static void main(String[] args) {
        Set<Integer> setA = Set.of(1, 2, 3, 4);
        Set<Integer> setB = Set.of(2, 4, 6, 8);

        Set<Integer> unionSet = SetOp.union(setA, setB);
        System.out.println(unionSet);

        Set<Integer> intersectSet = SetOp.intersection(setA, setB);
        System.out.println(intersectSet);

        Set<Integer> differenceSet = SetOp.difference(setA, setB);
        System.out.println(differenceSet);
    }
}
