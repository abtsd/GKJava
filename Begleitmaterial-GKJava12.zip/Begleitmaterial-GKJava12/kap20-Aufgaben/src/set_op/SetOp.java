package set_op;

import java.util.HashSet;
import java.util.Set;

public class SetOp {
    public static <E> Set<E> union(Set<E> setA, Set<E> setB) {
        Set<E> set = new HashSet<>(setA);
        set.addAll(setB);
        return set;
    }

    public static <E> Set<E> intersection(Set<E> setA, Set<E> setB) {
        Set<E> set = new HashSet<>(setA);
        set.retainAll(setB);
        return set;
    }

    public static <E> Set<E> difference(Set<E> setA, Set<E> setB) {
        Set<E> set = new HashSet<>(setA);
        set.removeAll(setB);
        return set;
    }
}
