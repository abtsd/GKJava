package map1;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class IterateMap {
	public static void main(String[] args) {
		Map<String, Double> map = new TreeMap<>();
		map.put("Meier", 5000.);
		map.put("Schmitz", 4500.);
		map.put("Balder", 4700.);
		map.put("Schulze", 4500.);

		// Variante 1
		for (String key : map.keySet()) {
			System.out.println(key + ": " + map.get(key));
		}
		System.out.println();

		// Variante 2
		String[] keys = map.keySet().toArray(new String[0]);
		for (int i = 0; i < keys.length; i++) {
			String key = keys[i];
			System.out.println(key + ": " + map.get(key));
		}
		System.out.println();

		// Variante 3
		Iterator<String> it1 = map.keySet().iterator();
		while (it1.hasNext()) {
			String key = it1.next();
			System.out.println(key + ": " + map.get(key));
		}
		System.out.println();

		// Variante 4
		for (Map.Entry<String, Double> e : map.entrySet()) {
			System.out.println(e.getKey() + ": " + e.getValue());
		}
		System.out.println();

		// Variante 5
		Object[] entries = map.entrySet().toArray();
		for (int i = 0; i < entries.length; i++) {
			Map.Entry<String, Double> e = (Map.Entry<String, Double>) entries[i];
			System.out.println(e.getKey() + ": " + e.getValue());
		}
		System.out.println();

		// Variante 6
		Iterator<Map.Entry<String, Double>> it2 = map.entrySet().iterator();
		while (it2.hasNext()) {
			Map.Entry<String, Double> e = it2.next();
			System.out.println(e.getKey() + ": " + e.getValue());
		}
		System.out.println();
	}
}
