package konten;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List<Konto> konten = new ArrayList<>();
		konten.add(new Konto(4711, 100));
		konten.add(new Konto(1001, 200));
		konten.add(new Konto(4712, 300));

		Collections.sort(konten);
		System.out.println(konten);
	}
}
