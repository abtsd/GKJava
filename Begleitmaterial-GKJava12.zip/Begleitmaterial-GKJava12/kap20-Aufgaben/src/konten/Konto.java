package konten;

public class Konto implements Comparable<Konto> {
	private int id;
	private double saldo;

	public Konto(int id, double saldo) {
		this.id = id;
		this.saldo = saldo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	@Override
	public String toString() {
		return "Konto{" +
			   "id=" + id +
			   ", saldo=" + saldo +
			   '}';
	}

	@Override
	public int compareTo(Konto o) {
		return id - o.id;
	}
}
