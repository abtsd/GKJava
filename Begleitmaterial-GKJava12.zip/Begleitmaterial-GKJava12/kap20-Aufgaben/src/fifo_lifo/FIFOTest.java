package fifo_lifo;

import java.util.LinkedList;

public class FIFOTest {
	public static void main(String[] args) {
		LinkedList<String> queue = new LinkedList<>();
		queue.add("Paul");
		queue.add("Tim");
		queue.add("Pit");
		System.out.println(queue);

		String s = queue.poll();
		System.out.println(s);
		System.out.println(queue);
	}
}
