package fifo_lifo;

import java.util.LinkedList;

public class LIFOTest {
	public static void main(String[] args) {
		LinkedList<String> stack = new LinkedList<>();
		stack.push("Paul");
		stack.push("Tim");
		stack.push("Pit");
		System.out.println(stack);

		String s = stack.pop();
		System.out.println(s);
		System.out.println(stack);
	}
}
