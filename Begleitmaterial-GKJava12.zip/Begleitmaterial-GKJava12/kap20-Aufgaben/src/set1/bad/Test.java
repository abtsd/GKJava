package set1.bad;

import java.util.HashSet;
import java.util.Set;

public class Test {
	public static void main(String[] args) {
		Point p1 = new Point(1, 2);
		Point p2 = new Point(1, 2);
		Set<Point> set = new HashSet<>();
		set.add(p1);
		set.add(p2);
		System.out.println(set);
		System.out.println(p1.equals(p2));
		System.out.println(set.size());
	}
}
