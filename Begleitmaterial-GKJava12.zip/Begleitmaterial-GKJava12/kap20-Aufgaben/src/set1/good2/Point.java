package set1.good2;

public record Point(int x, int y) {
}
