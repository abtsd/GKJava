package set2;

import java.util.HashSet;
import java.util.Set;

public class Test {
	public static void main(String[] args) {
		Konto k1 = new Konto(1, 1000);
		Konto k2 = new Konto(2, 2000);
		
		Set<Konto> set = new HashSet<>();
		set.add(k1);
		set.add(k2);
		System.out.println(set);

		k2.setId(1);
		System.out.println(k1.equals(k2));
		System.out.println(set);
	}
}
