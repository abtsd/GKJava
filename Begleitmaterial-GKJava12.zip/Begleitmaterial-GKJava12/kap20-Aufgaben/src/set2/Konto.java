package set2;

public class Konto {
	private int id;
	private final double saldo;

	public Konto(int id, double saldo) {
		this.id = id;
		this.saldo = saldo;
	}

	public void setId(int id) {
		this.id = id;
	}

	// Generiert mit Template "IntelliJ Default"
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		Konto konto = (Konto) o;

		return id == konto.id;
	}

	// Generiert mit Template "IntelliJ Default"
	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public String toString() {
		return "Konto{" +
				"id=" + id +
				", saldo=" + saldo +
				'}';
	}
}
