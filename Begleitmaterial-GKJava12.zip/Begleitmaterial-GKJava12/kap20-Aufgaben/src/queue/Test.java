package queue;

public class Test {
	public static void main(String[] args) {
		PrintQueue queue = new PrintQueue();
		
		for (int i = 0; i < 10; i++) {
			Document doc = new Document("Dokument " + (i + 1), 3);
			queue.enqueue(doc);
		}
		
		while (!queue.isEmpty()) {
			queue.process();
		}
	}
}
