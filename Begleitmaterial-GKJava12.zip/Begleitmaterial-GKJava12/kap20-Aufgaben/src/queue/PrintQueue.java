package queue;

import java.util.LinkedList;

public class PrintQueue {
	private final LinkedList<Document> queue;

	public PrintQueue() {
		queue = new LinkedList<>();
	}

	public boolean isEmpty() {
		return queue.isEmpty();
	}

	public void enqueue(Document doc) {
		queue.add(doc);
	}

	private void print(Document doc) {
		System.out.println(doc + " wird gedruckt.");
		System.out.println("Size: " + queue.size());
	}

	public void process() {
		if (queue.isEmpty())
			return;

		Document doc = queue.poll();
		print(doc);
	}
}
