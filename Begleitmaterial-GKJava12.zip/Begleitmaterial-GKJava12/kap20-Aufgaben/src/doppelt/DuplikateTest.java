package doppelt;

import java.util.*;

public class DuplikateTest {
	public static void main(String[] args) {
		List<Integer> numbers1 = List.of(1, 3, 8, 2, 1, 5, 3);
		List<Integer> numbers2 = List.of(1, 3, 8, 2, 5, 6, 9);

		boolean dup = numbers1.size() != new HashSet<>(numbers1).size();
		System.out.println(dup);

		dup = numbers2.size() != new HashSet<>(numbers2).size();
		System.out.println(dup);

		Map<Integer, Integer> map1 = new TreeMap<>();
		for (int n : numbers1) {
			map1.put(n, map1.getOrDefault(n, 0) + 1);
		}
		for (int key : map1.keySet())
			System.out.println(key + ": " + map1.get(key));
		System.out.println();

		Map<Integer, Integer> map2 = new TreeMap<>();
		for (int n : numbers2) {
			map2.put(n, map2.getOrDefault(n, 0) + 1);
		}
		for (int key : map2.keySet())
			System.out.println(key + ": " + map2.get(key));
	}
}
