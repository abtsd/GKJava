package dictionary;

import java.util.*;

public class Dictionary {
	private final Map<String, String> pairs;

	public Dictionary() {
		pairs = new TreeMap<>();
	}

	public void insert(String germanWord, String englishWord) {
		pairs.put(germanWord, englishWord);
	}

	@Override
	public String toString() {
		return pairs.toString();
	}

	public void printEnglishWord(String germanWord) {
		String englishWord = pairs.get(germanWord);
		if (englishWord != null)
			System.out.println(englishWord);
	}

	public void printGermanWords() {
		for (String word : pairs.keySet()) {
			System.out.println(word);
		}
	}

	public void printEnglishWords() {
		for (String word : pairs.values()) {
			System.out.println(word);
		}
	}

	public void printEnglishWordsSorted() {
		List<String> list = new ArrayList<>(pairs.values());
		Collections.sort(list);
		for (String word : list) {
			System.out.println(word);
		}
	}
}
