package dictionary;

public class Test {
	public static void main(String[] args) {
		Dictionary dictionary = new Dictionary();
		dictionary.insert("Katze", "cat");
		dictionary.insert("Hund", "dog");
		dictionary.insert("Pferd", "horse");
		dictionary.insert("Herz", "heart");
		dictionary.insert("gehen", "to go");
		
		System.out.println(dictionary);
		System.out.println();
		dictionary.printEnglishWord("Pferd");
		System.out.println();
		dictionary.printGermanWords();
		System.out.println();
		dictionary.printEnglishWords();
		System.out.println();
		dictionary.printEnglishWordsSorted();
	}
}
