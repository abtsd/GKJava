package map2;

public class User {
	private final int id;

	public User(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "User{" +
			   "id=" + id +
			   '}';
	}

	// Generiert mit Template "IntelliJ Default"
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		User user = (User) o;

		return id == user.id;
	}

	// Generiert mit Template "IntelliJ Default"
//	@Override
//	public int hashCode() {
//		return id;
//	}
}
