Da hashCode in der Klasse User nicht überschrieben ist,
haben user1 und user2 unterschiedliche Hash-Codes.

put legt den Eintrag in einem durch den Hash-Code von user1 bestimmten "Fach" ab.

get sucht aber in einem anderen "Fach", das durch den Hash-Code von user2
bestimmt ist, und findet den Schlüssel nicht.
