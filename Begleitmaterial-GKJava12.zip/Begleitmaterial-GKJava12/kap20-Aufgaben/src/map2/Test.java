package map2;

import java.util.HashMap;
import java.util.Map;

public class Test {
	public static void main(String[] args) {
		Map<User, String> map = new HashMap<>();
		User user1 = new User(4711);
		map.put(user1, "Hugo Meier");

		User user2 = new User(4711);
		System.out.println(map.get(user2));

		System.out.println(user1.hashCode());
		System.out.println(user2.hashCode());
	}
}
