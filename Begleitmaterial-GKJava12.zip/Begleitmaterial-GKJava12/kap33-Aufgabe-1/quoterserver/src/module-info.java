module quoterserver {
    exports de.quoter.services;
}