package de.quoter.services;

public class QuoterUtils {
    public String quote(String text) {
        return "\"" + text + "\"";
    }
}
