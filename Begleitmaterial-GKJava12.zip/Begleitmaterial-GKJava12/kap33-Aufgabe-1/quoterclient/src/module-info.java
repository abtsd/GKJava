module quoterclient {
    requires quoterserver;
}