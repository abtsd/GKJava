package de.quoter.app;

import de.quoter.services.QuoterUtils;

public class QuoterApp {
    public static void main(String[] args) {
        QuoterUtils quoter = new QuoterUtils();
        System.out.println(quoter.quote("Das ist ein Test."));
    }
}
