# Übersetzen
javac -d out/production/quoterserver \
quoterserver/src/*.java quoterserver/src/de/quoter/services/*.java

javac -d out/production/quoterclient -p out/production \
quoterclient/src/*.java quoterclient/src/de/quoter/app/*.java

# Ausführen
java -p out/production -m quoterclient/de.quoter.app.QuoterApp

# JARs erzeugen
mkdir lib
jar --create --file lib/quoterserver.jar -C out/production/quoterserver .
jar --create --file lib/quoterclient.jar -C out/production/quoterclient .

# und ausführen
java -p lib -m quoterclient/de.quoter.app.QuoterApp

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s lib/*.jar
jdeps -s -dotoutput graphs lib/*.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
