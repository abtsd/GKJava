module quoterclient {
    requires quoter;
    uses de.quoter.api.Quoter;
}