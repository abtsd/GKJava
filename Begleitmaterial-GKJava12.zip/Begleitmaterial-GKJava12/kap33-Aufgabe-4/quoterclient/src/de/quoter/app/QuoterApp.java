package de.quoter.app;

import de.quoter.api.Quoter;

import java.util.Optional;
import java.util.ServiceLoader;

public class QuoterApp {
    public static void main(String[] args) {
        Optional<Quoter> optional = ServiceLoader.load(Quoter.class).findFirst();
        optional.ifPresent(quoter -> System.out.println(quoter.quote("Das ist ein Test.")));
        optional.ifPresent(quoter -> System.out.println(quoter.quoteHtml("bread & butter")));
    }
}
