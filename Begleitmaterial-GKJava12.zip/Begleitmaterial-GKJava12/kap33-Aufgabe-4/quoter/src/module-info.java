module quoter {
    exports de.quoter.api;
}
