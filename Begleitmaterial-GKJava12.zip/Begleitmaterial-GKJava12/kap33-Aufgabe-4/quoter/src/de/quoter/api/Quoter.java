package de.quoter.api;

public interface Quoter {
    String quote(String text);
    String quoteHtml(String text);
}
