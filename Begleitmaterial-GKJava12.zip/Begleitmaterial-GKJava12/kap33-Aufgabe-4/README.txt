# Übersetzen
javac -d out/production/quoter \
quoter/src/*.java quoter/src/de/quoter/api/*.java

javac -d out/production/quoterserver -p out/production:lib \
quoterserver/src/*.java quoterserver/src/de/quoter/services/*.java

javac -d out/production/quoterclient -p out/production \
quoterclient/src/*.java quoterclient/src/de/quoter/app/*.java

# Ausführen
java -p out/production:lib -m quoterclient/de.quoter.app.QuoterApp

# JARs erzeugen
jar --create --file lib/quoter.jar -C out/production/quoter .
jar --create --file lib/quoterserver.jar -C out/production/quoterserver .
jar --create --file lib/quoterclient.jar -C out/production/quoterclient .

# und ausführen
java -p lib -m quoterclient/de.quoter.app.QuoterApp

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s --module-path lib lib/quoter.jar lib/quoterclient.jar lib/quoterserver.jar
jdeps -s -dotoutput graphs --module-path lib lib/quoter.jar lib/quoterclient.jar lib/quoterserver.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
