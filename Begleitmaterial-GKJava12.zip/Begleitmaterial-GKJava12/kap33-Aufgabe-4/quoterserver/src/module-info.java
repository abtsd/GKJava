module quoterserver {
    requires java.logging;
    requires quoter;
    requires org.apache.commons.text;
    provides de.quoter.api.Quoter with de.quoter.services.QuoterUtils;
}