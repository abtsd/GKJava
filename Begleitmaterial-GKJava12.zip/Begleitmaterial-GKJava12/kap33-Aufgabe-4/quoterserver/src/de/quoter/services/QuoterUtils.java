package de.quoter.services;

import de.quoter.api.Quoter;
import org.apache.commons.text.StringEscapeUtils;

import java.util.logging.Logger;

public class QuoterUtils implements Quoter {
    private static final Logger LOGGER;

    static {
        System.setProperty("java.util.logging.config.file", "logging.properties");
        LOGGER = Logger.getLogger(QuoterUtils.class.getName());
    }

    @Override
    public String quote(String text) {
        LOGGER.info("quote wird aufgerufen");
        return "\"" + text + "\"";
    }

    @Override
    public String quoteHtml(String text) {
        LOGGER.info("quoteHtml wird aufgerufen");
        return StringEscapeUtils.escapeHtml4("\"" + text + "\"");
    }
}
