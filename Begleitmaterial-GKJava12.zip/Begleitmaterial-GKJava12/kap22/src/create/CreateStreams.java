package create;

import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class CreateStreams {
	public static void main(String[] args) {
		List<Integer> list = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
		list.stream().limit(5).forEach(System.out::println);

		Integer[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		Stream.of(numbers).limit(5).forEach(System.out::println);

		Stream.iterate(1, n -> n + 1).limit(5).forEach(System.out::println);
		IntStream.iterate(1, n -> n + 1).limit(5).forEach(System.out::println);

		Stream.generate(Math::random).limit(5).forEach(System.out::println);
	}
}
