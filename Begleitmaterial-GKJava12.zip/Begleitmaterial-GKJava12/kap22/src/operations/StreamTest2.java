package operations;

import java.util.stream.IntStream;

public class StreamTest2 {
	public static void main(String[] args) {
		IntStream stream1 = IntStream.of(1, 2, 3, 4, 5, 6, 1, 2, 3);
		IntStream stream2 = IntStream.of(1, 2, 3, 4, 5, 6, 1, 2, 3);
		IntStream stream3 = IntStream.of(1, 2, 3, 4, 5, 6, 1, 2, 3);
		stream1.takeWhile(n -> n < 4)
				.forEach(n -> System.out.print(n + " "));
		System.out.println();
		stream2.dropWhile(n -> n < 4)
				.forEach(n -> System.out.print(n + " "));
		System.out.println();
		stream3.dropWhile(n -> n < 4).takeWhile(n -> n >= 4)
				.forEach(n -> System.out.print(n + " "));
		System.out.println();

		IntStream stream4 = IntStream.of(1, 3, 4, 5, 6);
		stream4.skip(3).forEach(n -> System.out.print(n + " "));
		System.out.println();

		IntStream stream5 = IntStream.of(1, 3, 4, 5, 6);
		System.out.println(stream5.anyMatch(n -> n == 4));

		IntStream stream6 = IntStream.of(1, 3, 4, 5, 6);
		System.out.println(stream6.allMatch(n -> n <= 4));

		IntStream stream7 = IntStream.of(1, 3, 4, 5, 6);
		System.out.println(stream7.noneMatch(n -> n > 6));
	}
}
