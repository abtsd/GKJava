package operations;

import java.util.List;
import java.util.stream.Stream;

public class StreamTest3 {
	public static void main(String[] args) {
		List<Integer> list = List.of(1, 2);

		Stream<Stream<Integer>> stream1 = list.stream().map(n -> Stream.of(n, n + 1));
		stream1.forEach(s -> System.out.println(s.toList()));

		Stream<Integer> stream2 = list.stream().flatMap(n -> Stream.of(n, n + 1));
		stream2.forEach(System.out::println);
	}
}
