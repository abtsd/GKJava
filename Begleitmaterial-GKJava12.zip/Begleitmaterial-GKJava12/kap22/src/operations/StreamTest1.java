package operations;

import java.util.Comparator;
import java.util.List;

public class StreamTest1 {
	public static void main(String[] args) {
		List<Artikel> list = List.of(
				new Artikel(4712, 'A', 30.),
				new Artikel(4714, 'A', 20.),
				new Artikel(4713, 'B', 10.),
				new Artikel(4715, 'B', 10.),
				new Artikel(4711, 'A', 10.)
		);

		// Sortieren und ausgeben
		list.stream().sorted(Comparator.comparing(Artikel::getId))
				.forEach(System.out::println);

		// Filtern und zählen
		long count = list.stream().filter(a -> a.getTyp() == 'A').count();
		System.out.println("Anzahl Artikel vom Typ 'A': " + count);

		// Filtern, ändern und Ergebnis als Liste erzeugen
		List<Artikel> filtered = list.stream().filter(a -> a.getTyp() == 'A')
				.peek(a -> a.setPreis(1.1 * a.getPreis())).toList();
		System.out.println(filtered);

		// Map und reduce
		double z = filtered.stream().map(Artikel::getPreis)
						   .reduce(0., (x, y) -> x + y) / filtered.size();
		System.out.println("Durchschnittspreis für Artikel vom Typ A: " + z);
	}
}