public class Encode {
	public static String encode(String text) {
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		String s = text.toLowerCase();
		char c;
		boolean umlaut, sz;
		StringBuilder builder = new StringBuilder();

		for (int i = 0; i < text.length(); i++) {
			umlaut = false;
			sz = false;
			c = s.charAt(i);

			switch (c) {
				case 'ä' -> {
					c = 'a';
					umlaut = true;
				}
				case 'ö' -> {
					c = 'o';
					umlaut = true;
				}
				case 'ü' -> {
					c = 'u';
					umlaut = true;
				}
				case 'ß' -> {
					c = 's';
					sz = true;
				}
			}

			if (c >= 'a' && c <= 'z') {
				builder.append(alphabet.indexOf(c) + 1);
				builder.append(' ');
				if (umlaut)
					builder.append("5 "); // entspricht 'e'
				else if (sz)
					builder.append("19 "); // entspricht 's'
			}
		}

		return builder.toString();
	}

	public static void main(String[] args) {
		String text = "Ich weiß, was es bedeutet. Heute ist schönes Wetter.";
		System.out.println(encode(text));
	}
}
