public class Palindrom {
	public static boolean isPalindrom(String s) {
		StringBuilder sb = new StringBuilder(s.toLowerCase());
		for (int i = 0; i < sb.length(); i++) {
			switch (sb.charAt(i)) {
				case ' ', ',', ';', '.', ':', '!', '?' -> {
					sb.deleteCharAt(i);
					i--;
				}
			}
		}
		return sb.toString().equals(sb.reverse().toString());
	}

	public static void main(String[] args) {
		String text = "O Genie, der Herr ehre Dein Ego!";
		if (isPalindrom(text))
			System.out.println("Ist ein Palindrom.");
		else
			System.out.println("Ist kein Palindrom.");
	}
}
