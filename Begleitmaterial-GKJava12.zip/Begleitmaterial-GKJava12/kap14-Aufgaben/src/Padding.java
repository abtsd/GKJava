public class Padding {
	public static String padStart(String str, int length, char pad) {
		int lenStr = str.length();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length - lenStr; i++) {
			sb.append(pad);
		}
		sb.append(str);
		return sb.toString();
	}

	public static String padEnd(String str, int length, char pad) {
		int lenStr = str.length();
		StringBuilder sb = new StringBuilder();
		sb.append(str);
		for (int i = 0; i < length - lenStr; i++) {
			sb.append(pad);
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		String padded = padStart("Hallo", 10, '-');
		System.out.println(padded);

		padded = padEnd("Hallo", 10, '-');
		System.out.println(padded);
	}
}
