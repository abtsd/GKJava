public class DelimitedString {
	public static String delimitedString(String s, char start, char end) {
		int a = s.indexOf(start);
		int b = s.lastIndexOf(end);
		if (a == -1 || a > b) {
			return null;
		}
		return s.substring(a, b + 1);
	}

	public static void main(String[] args) {
		String text = "Er sagte laut \"Guten Tag!\"";
		System.out.println(delimitedString(text, '"', '"'));
	}
}
