public class PerformanceTest {
	private static final int MAX = 500000;

	public static void main(String[] args) {
		String cmd = args[0];
		switch (cmd) {
			case "String" -> testString();
			case "StringBuilder" -> testStringBuilder();
			case "StringBuffer" -> testStringBuffer();
		}
	}

	private static void testString() {
		String s = "";
		long begin = System.currentTimeMillis();
		for (int i = 0; i < MAX; i++) {
			s = s + "x";
		}
		long end = System.currentTimeMillis();
		System.out.println("String: " + (end - begin));
	}

	private static void testStringBuilder() {
		StringBuilder sb = new StringBuilder();
		long begin = System.currentTimeMillis();
		for (int i = 0; i < MAX; i++) {
			sb.append("x");
		}
		long end = System.currentTimeMillis();
		System.out.println("StringBuilder: " + (end - begin));
	}

	private static void testStringBuffer() {
		StringBuffer sb = new StringBuffer();
		long begin = System.currentTimeMillis();
		for (int i = 0; i < MAX; i++) {
			sb.append("x");
		}
		long end = System.currentTimeMillis();
		System.out.println("StringBuffer: " + (end - begin));
	}
}
