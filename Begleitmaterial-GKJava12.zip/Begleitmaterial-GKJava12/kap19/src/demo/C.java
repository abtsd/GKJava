package demo;

public class C<T> {
	T value;
}
