package demo;

/*
	Notation für "X ist kompatibel zu Y": Y <-- X

	Invarianz:
	Aus B <-- A folgt nicht C<B> <-- C<A>
 */

public class Invarianz {
	public static void main(String[] args) {
		C<A> ca = new C<>();
		// C<B> cb = ca;
	}
}
