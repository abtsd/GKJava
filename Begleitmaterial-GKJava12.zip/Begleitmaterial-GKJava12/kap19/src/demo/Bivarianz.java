package demo;

/*
	Notation für "X ist kompatibel zu Y": Y <-- X

	Bivarianz:
	C<?> <-- C<A>
 */

public class Bivarianz {
	public static void main(String[] args) {
		C<A> ca = new C<>();
		C<?> c = ca;
		// A a = c.value;
		// c.value = new A();
		Object o = c.value;
		c.value = null;
	}
}
