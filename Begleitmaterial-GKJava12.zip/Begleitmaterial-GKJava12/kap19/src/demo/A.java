package demo;

public class A extends B {
}
