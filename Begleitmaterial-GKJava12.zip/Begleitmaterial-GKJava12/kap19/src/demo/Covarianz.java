package demo;

/*
	Notation für "X ist kompatibel zu Y": Y <-- X

	Covarianz:
	Aus B <-- A folgt C<? extends B> <-- C<A>
 */

public class Covarianz {
	public static void main(String[] args) {
		C<A> ca = new C<>();
		C<? extends B> c = ca;
		// c.value = new A();
		B b = c.value;
		c.value = null;
	}
}
