package demo;

/*
	Notation für "X ist kompatibel zu Y": Y <-- X

	Contravarianz:
	Aus B <-- A folgt C<? super A> <-- C<B>
 */

public class Contravarianz {
	public static void main(String[] args) {
		C<B> cb = new C<>();
		C<? super A> c = cb;
		c.value = new A();
		// A a = c.value;
		Object o = c.value;
	}
}
