package demo;

public class B {
}
