package typebound;

public class Konto implements Comparable<Konto> {
	private int id;
	private int saldo;

	public Konto(int id, int saldo) {
		this.id = id;
		this.saldo = saldo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Konto konto = (Konto) o;
		return id == konto.id;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public int compareTo(Konto k) {
		return Integer.compare(id, k.id);
	}
}
