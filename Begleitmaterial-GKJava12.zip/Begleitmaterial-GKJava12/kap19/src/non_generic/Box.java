package non_generic;

public class Box {
	private Object value;

	public void setValue(Object value) {
		this.value = value;
	}

	public Object getValue() {
		return value;
	}
}
