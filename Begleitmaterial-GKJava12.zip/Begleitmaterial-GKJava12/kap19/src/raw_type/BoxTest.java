package raw_type;

public class BoxTest {
	public static void main(String[] args) {
		Box box = new Box();
		box.setValue("Hugo");
		System.out.println(box.getValue());
		
		Box<Integer> ibox = new Box<>();
		ibox.setValue(5000);

		box = ibox;
		box.setValue("Emil");
		System.out.println(ibox.getValue());
	}
}