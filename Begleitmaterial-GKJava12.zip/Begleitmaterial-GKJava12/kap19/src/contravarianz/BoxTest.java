package contravarianz;

public class BoxTest {
	public static void main(String[] args) {
		Box<Object> obox = new Box<>();
		obox.setValue("Hugo");

		Box<? super Number> box = obox;
		Object obj = box.getValue();
		System.out.println(obj);
		box.setValue(4711);

		Box<Integer> ibox = new Box<>();
		ibox.setValue(4711);

		Box<Number> nbox = new Box<>();
		ibox.copyTo(nbox);
		System.out.println(nbox.getValue());

		ibox.copyTo(obox);
		System.out.println(obox.getValue());
	}
}
