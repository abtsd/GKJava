package covarianz;

public class BoxTest {
	public static void main(String[] args) {
		Box<Integer> ibox = new Box<>();
		ibox.setValue(4711);

		Box<? extends Number> box = ibox;
		Number n = box.getValue();
		System.out.println(n);
		box.setValue(null);

		Box<Number> nbox = new Box<>();

		ibox.setValue(5000);
		nbox.copyFrom(ibox);
		System.out.println(nbox.getValue());

		Box<Double> dbox = new Box<>();
		dbox.setValue(123.45);
		nbox.copyFrom(dbox);
		System.out.println(nbox.getValue());
	}
}
