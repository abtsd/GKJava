# Übersetzen
javac -d out/production/brutto -p $PATH_TO_FX \
brutto/src/*.java brutto/src/de/demo/brutto/*.java

cp brutto/src/de/demo/brutto/BruttoRechner.css out/production/brutto/de/demo/brutto

# Ausführen
java -p out/production:$PATH_TO_FX -m brutto/de.demo.brutto.BruttoRechner

# JAR mit Festlegung der Main-Klasse erzeugen
mkdir lib
jar --create --file lib/brutto.jar --main-class de.demo.brutto.BruttoRechner -C out/production/brutto .

# und ausführen
java -p lib:$PATH_TO_FX -m brutto

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s --module-path $PATH_TO_FX lib/*.jar
jdeps -s -dotoutput graphs --module-path $PATH_TO_FX lib/*jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
