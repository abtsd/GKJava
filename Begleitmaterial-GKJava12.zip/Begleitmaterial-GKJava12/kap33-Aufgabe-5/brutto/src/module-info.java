module brutto {
    requires javafx.controls;
    opens de.demo.brutto to javafx.graphics;
}