# Übersetzen
javac -d out/production/mailapi \
mailapi/src/*.java mailapi/src/de/demo/mail/*.java

javac -d out/production/simplemail -p out/production \
simplemail/src/*.java simplemail/src/de/demo/mail/simple/*.java

javac -d out/production/webmail -p out/production \
webmail/src/*.java webmail/src/de/demo/mail/web/*.java

javac -d out/production/mailclient -p out/production \
mailclient/src/*.java mailclient/src/de/demo/mail/client/*.java

# JARs erzeugen
mkdir mailapi/lib
mkdir simplemail/lib
mkdir webmail/lib
mkdir mailclient/lib

jar --create --file mailclient/lib/mailclient.jar \
-C out/production/mailclient .
jar --create --file mailapi/lib/mailapi.jar \
-C out/production/mailapi .
jar --create --file simplemail/lib/simplemail.jar \
-C out/production/simplemail .
jar --create --file webmail/lib/webmail.jar \
-C out/production/webmail .

# und ausführen ...
# SimpleMail
java -p mailclient/lib:mailapi/lib:simplemail/lib \
-m mailclient/de.demo.mail.client.MailClient

# WebMail
java -p mailclient/lib:mailapi/lib:webmail/lib \
-m mailclient/de.demo.mail.client.MailClient

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s mailapi/lib/*.jar simplemail/lib/*.jar webmail/lib/*.jar mailclient/lib/*.jar
jdeps -s -dotoutput graphs \
mailapi/lib/*.jar simplemail/lib/*.jar webmail/lib/*.jar mailclient/lib/*.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
