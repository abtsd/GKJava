module webmail {
    requires mailapi;
    provides de.demo.mail.MailSender with de.demo.mail.web.WebMailSenderImpl;
}