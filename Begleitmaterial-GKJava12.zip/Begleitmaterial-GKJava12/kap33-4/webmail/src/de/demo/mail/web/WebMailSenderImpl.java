package de.demo.mail.web;

import de.demo.mail.MailSender;

public class WebMailSenderImpl implements MailSender {
	@Override
	public boolean sendMail(String to, String text) {
		System.out.println("WebMail an " + to + ":\n" + text);
		return true;
	}
}
