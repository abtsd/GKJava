module mailapi {
    exports de.demo.mail;
}