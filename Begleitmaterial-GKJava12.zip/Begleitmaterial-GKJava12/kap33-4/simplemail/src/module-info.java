module simplemail {
    requires mailapi;
    provides de.demo.mail.MailSender with de.demo.mail.simple.SimpleMailSenderImpl;
}