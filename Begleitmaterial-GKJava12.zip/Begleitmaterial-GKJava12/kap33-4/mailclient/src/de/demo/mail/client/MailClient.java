package de.demo.mail.client;

import de.demo.mail.MailSender;

import java.util.Optional;
import java.util.ServiceLoader;

public class MailClient {
	public static void main(String[] args) {
		Optional<MailSender> optional = ServiceLoader.load(MailSender.class).findFirst();
		if (optional.isPresent()) {
			boolean ok = optional.get().sendMail("hugo.meier@abc.de", "Das ist ein Test.");
			if (ok) {
				System.out.println("Mail wurde versandt.");
			} else {
				System.out.println("Fehler beim Senden.");
			}
		}
	}
}
