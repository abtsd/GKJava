module mailclient {
    requires mailapi;
    uses de.demo.mail.MailSender;
}