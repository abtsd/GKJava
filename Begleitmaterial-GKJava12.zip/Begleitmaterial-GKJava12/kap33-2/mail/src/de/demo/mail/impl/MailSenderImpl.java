package de.demo.mail.impl;

import de.demo.mail.MailSender;

public class MailSenderImpl implements MailSender {
	@Override
	public boolean sendMail(String to, String text) {
		System.out.println("Mail an " + to + ":\n" + text);
		return true;
	}
}
