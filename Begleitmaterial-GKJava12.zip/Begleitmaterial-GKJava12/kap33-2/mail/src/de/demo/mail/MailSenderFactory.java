package de.demo.mail;

import de.demo.mail.impl.MailSenderImpl;

public class MailSenderFactory {
	public static MailSender create() {
		return new MailSenderImpl();
	}
}
