package de.demo.mail;

public interface MailSender {
	boolean sendMail(String to, String text);
}
