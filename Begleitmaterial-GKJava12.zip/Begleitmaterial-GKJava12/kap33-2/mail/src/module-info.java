module mail {
	exports de.demo.mail;
}