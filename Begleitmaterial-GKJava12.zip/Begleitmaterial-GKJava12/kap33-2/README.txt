# Übersetzen
javac -d out/production/mail mail/src/*.java \
mail/src/de/demo/mail/*.java mail/src/de/demo/mail/impl/*.java

javac -d out/production/mailclient -p out/production \
mailclient/src/*.java mailclient/src/de/demo/mail/client/*.java

javac -d out/production/mailclient.javafx -p out/production:$PATH_TO_FX \
mailclient.javafx/src/*.java mailclient.javafx/src/de/demo/mail/client2/*.java

# Ausführen
java -p out/production -m mailclient/de.demo.mail.client.MailClient
java -p out/production:$PATH_TO_FX -m mailclient.javafx/de.demo.mail.client2.MailClient

# JARs erzeugen
mkdir lib
jar --create --file lib/mail.jar -C out/production/mail .
jar --create --file lib/mailclient.jar -C out/production/mailclient .
jar --create --file lib/mailclient.javafx.jar -C out/production/mailclient.javafx .

# und ausführen
java -p lib -m mailclient/de.demo.mail.client.MailClient
java -p lib:$PATH_TO_FX -m mailclient.javafx/de.demo.mail.client2.MailClient

# JAR mit Festlegung der Main-Klasse erzeugen
jar --create --file lib/mailclient.jar \
--main-class de.demo.mail.client.MailClient -C out/production/mailclient .

jar --create --file lib/mailclient.javafx.jar \
--main-class de.demo.mail.client2.MailClient -C out/production/mailclient.javafx .

# und ausführen
java -p lib -m mailclient
java -p lib:$PATH_TO_FX -m mailclient.javafx

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s --module-path $PATH_TO_FX lib/*.jar
jdeps -s -dotoutput graphs --module-path $PATH_TO_FX lib/*.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O

# Alternative zu "opens" im Moduldeskriptor
java --add-opens mailclient.javafx/de.demo.mail.client2=javafx.graphics \
-p out/production:$PATH_TO_FX \
-m mailclient.javafx/de.demo.mail.client2.MailClient
