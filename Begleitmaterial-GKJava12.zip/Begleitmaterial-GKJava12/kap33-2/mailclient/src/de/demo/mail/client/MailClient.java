package de.demo.mail.client;

import de.demo.mail.MailSender;
import de.demo.mail.MailSenderFactory;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;

public class MailClient {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		JLabel label = new JLabel();

		MailSender mailSender = MailSenderFactory.create();
		boolean ok = mailSender.sendMail("hugo.meier@abc.de", "Das ist ein Test.");
		if (ok) {
			label.setText("Mail wurde versandt.");
		} else {
			label.setText("Fehler beim Senden.");
		}

		frame.setLayout(new FlowLayout());
		frame.getContentPane().add(label);
		frame.setSize(400, 100);
		frame.setTitle("MailClient (Swing)");
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
