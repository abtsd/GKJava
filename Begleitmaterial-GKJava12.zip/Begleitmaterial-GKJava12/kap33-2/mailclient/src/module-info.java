module mailclient {
	requires mail;
	requires java.desktop;
}