package de.demo.mail.client2;

import de.demo.mail.MailSender;
import de.demo.mail.MailSenderFactory;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class MailClient extends Application {
	@Override
	public void start(Stage stage) {
		Label label = new Label();

		MailSender mailSender = MailSenderFactory.create();
		boolean ok = mailSender.sendMail("hugo.meier@abc.de", "Das ist ein Test.");
		if (ok) {
			label.setText("Mail wurde versandt.");
		} else {
			label.setText("Fehler beim Senden.");
		}

		StackPane pane = new StackPane();
		pane.getChildren().add(label);
		stage.setScene(new Scene(pane, 400, 100));
		stage.setTitle("MailClient (JavaFX)");
		stage.setResizable(false);
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
