module mailclient.javafx {
	requires mail;
	requires javafx.controls;
	opens de.demo.mail.client2 to javafx.graphics;
}