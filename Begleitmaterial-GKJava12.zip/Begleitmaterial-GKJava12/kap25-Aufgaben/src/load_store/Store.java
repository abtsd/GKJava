package load_store;

import java.io.IOException;

public class Store {
	public static void main(String[] args) throws IOException {
		Artikel a = new Artikel(4711, 140.99, 1000);
		a.store("artikel4711");
	}
}
