package load_store;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Artikel implements Serializable {
	private static final long serialVersionUID = 1L;
	private int nr;
	private double preis;
	private int bestand;

	public Artikel(int nr, double preis, int bestand) {
		this.nr = nr;
		this.preis = preis;
		this.bestand = bestand;
	}

	public int getNr() {
		return nr;
	}

	public void setNr(int nr) {
		this.nr = nr;
	}

	public double getPreis() {
		return preis;
	}

	public void setPreis(double preis) {
		this.preis = preis;
	}

	public int getBestand() {
		return bestand;
	}

	public void setBestand(int bestand) {
		this.bestand = bestand;
	}

	@Override
	public String toString() {
		return "Artikel{" +
				"nr=" + nr +
				", preis=" + preis +
				", bestand=" + bestand +
				'}';
	}

	public void store(String name) throws IOException {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(name))) {
			out.writeObject(this);
			out.flush();
		}
	}

	public static Artikel load(String name) throws IOException, ClassNotFoundException {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(name))) {
			return (Artikel) in.readObject();
		}
	}
}
