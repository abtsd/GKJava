package load_store;

import java.io.IOException;

public class Load {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Artikel a = Artikel.load("artikel4711");
		System.out.println(a);
	}
}
