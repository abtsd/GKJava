package serialize;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;

public class Load {
	public static void main(String[] args) throws Exception {
		SimpleDateFormat f1 = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat f2 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("mitarbeiter.ser"))) {
			while (true) {
				Mitarbeiter m = (Mitarbeiter) in.readObject();

				System.out.println("PersId: " + m.getPersId());
				System.out.println("Name: " + m.getName());
				System.out.println("Geburtsdatum: " + f1.format(m.getGeburtsDatum()));
				Adresse a = m.getAdresse();
				System.out.println(a.getStrasse());
				System.out.println(a.getPlz() + " " + a.getOrt());

				for (Kontakt k : m.getKontakte()) {
					System.out.println(k.getInfo() + " [" + f2.format(k.getTimestamp()) + "]");
				}

				System.out.println();
			}
		} catch (EOFException ignored) {
		}
	}
}
