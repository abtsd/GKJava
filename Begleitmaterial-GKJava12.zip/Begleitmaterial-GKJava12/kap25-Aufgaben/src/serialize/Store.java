package serialize;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class Store {
	public static void main(String[] args) throws IOException {
		Mitarbeiter mit1 = new Mitarbeiter();
		mit1.setPersId(101);
		mit1.setName("Meier, Hugo");
		mit1.setGeburtsDatum(new GregorianCalendar(1970, 0, 1).getTime());
		Adresse adr1 = new Adresse();
		adr1.setStrasse("Hauptstr. 12");
		adr1.setPlz("40880");
		adr1.setOrt("Ratingen");
		mit1.setAdresse(adr1);
		Mail mail1 = new Mail();
		mail1.setTimestamp(new Date());
		mail1.setMailAdresse("hugo.meier@xyz.de");
		Telefon tel1 = new Telefon();
		tel1.setTimestamp(new Date());
		tel1.setTelefonNummer("02102/112233");
		List<Kontakt> kon1 = new ArrayList<>();
		kon1.add(mail1);
		kon1.add(tel1);
		mit1.setKontakte(kon1);

		Mitarbeiter mit2 = new Mitarbeiter();
		mit2.setPersId(102);
		mit2.setName("Schmitz, Otto");
		mit2.setGeburtsDatum(new GregorianCalendar(1961, 2, 22).getTime());
		Adresse adr2 = new Adresse();
		adr2.setStrasse("Dorfstr. 5");
		adr2.setPlz("40880");
		adr2.setOrt("Ratingen");
		mit2.setAdresse(adr2);
		Mail mail2 = new Mail();
		mail2.setTimestamp(new Date());
		mail2.setMailAdresse("otto.schmitz@web.de");
		Mail mail3 = new Mail();
		mail3.setTimestamp(new Date());
		mail3.setMailAdresse("otto.schmitz@gmx.de");
		Telefon tel2 = new Telefon();
		tel2.setTimestamp(new Date());
		tel2.setTelefonNummer("02102/445566");
		List<Kontakt> kon2 = new ArrayList<>();
		kon2.add(mail2);
		kon2.add(mail3);
		kon2.add(tel2);
		mit2.setKontakte(kon2);

		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("mitarbeiter.ser"))) {
			out.writeObject(mit1);
			out.writeObject(mit2);
			out.flush();
		}
	}
}
