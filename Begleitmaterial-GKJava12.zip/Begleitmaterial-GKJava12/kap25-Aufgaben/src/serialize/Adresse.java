package serialize;

import java.io.Serializable;

public class Adresse implements Serializable {
	private static final long serialVersionUID = 1L;
	private String strasse;
	private String plz;
	private String ort;

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}
}
