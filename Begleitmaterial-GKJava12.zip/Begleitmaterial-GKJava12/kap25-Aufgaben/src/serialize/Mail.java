package serialize;

public class Mail extends Kontakt {
	private static final long serialVersionUID = 1L;
	private String mailAdresse;

	public String getMailAdresse() {
		return mailAdresse;
	}

	public void setMailAdresse(String mailAdresse) {
		this.mailAdresse = mailAdresse;
	}

	@Override
	public String getInfo() {
		return "Mail: " + mailAdresse;
	}
}
