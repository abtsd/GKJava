package serialize;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Mitarbeiter implements Serializable {
	private static final long serialVersionUID = 1L;
	private int persId;
	private String name;
	private Date geburtsDatum;
	private Adresse adresse;
	private List<Kontakt> kontakte;

	public int getPersId() {
		return persId;
	}

	public void setPersId(int persId) {
		this.persId = persId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getGeburtsDatum() {
		return geburtsDatum;
	}

	public void setGeburtsDatum(Date geburtsDatum) {
		this.geburtsDatum = geburtsDatum;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public List<Kontakt> getKontakte() {
		return kontakte;
	}

	public void setKontakte(List<Kontakt> kontakte) {
		this.kontakte = kontakte;
	}
}
