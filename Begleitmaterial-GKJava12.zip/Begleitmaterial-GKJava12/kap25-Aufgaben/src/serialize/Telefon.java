package serialize;

public class Telefon extends Kontakt {
	private static final long serialVersionUID = 1L;
	private String telefonNummer;

	public String getTelefonNummer() {
		return telefonNummer;
	}

	public void setTelefonNummer(String telefonNummer) {
		this.telefonNummer = telefonNummer;
	}

	@Override
	public String getInfo() {
		return "Telefon: " + telefonNummer;
	}
}
