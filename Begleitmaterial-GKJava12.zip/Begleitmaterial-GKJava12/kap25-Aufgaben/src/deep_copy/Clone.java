package deep_copy;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Clone {
	public static void main(String[] args) {
		Kunde kd = new Kunde("Hugo Meier", "Hauptstr. 12, 40880 Ratingen");
		Konto kto1 = new Konto(4711, 10000.);
		kto1.setKunde(kd);
		System.out.println(kto1);

		Konto kto2 = clone(kto1);
		System.out.println(kto2);

		System.out.println(kto1 == kto2);
	}

	public static <T extends Serializable> T clone(T obj) {
		T result = null;
		byte[] bytes = null;

		try (ByteArrayOutputStream bytesOutput = new ByteArrayOutputStream();
			 ObjectOutputStream objectOutput = new ObjectOutputStream(bytesOutput)) {
			objectOutput.writeObject(obj);
			objectOutput.flush();
			bytes = bytesOutput.toByteArray();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}

		//noinspection ConstantConditions
		try (ByteArrayInputStream bytesInput = new ByteArrayInputStream(bytes);
			 ObjectInputStream objectInput = new ObjectInputStream(bytesInput)) {
			//noinspection unchecked
			result = (T) objectInput.readObject();
		} catch (IOException | ClassNotFoundException e) {
			System.err.println(e.getMessage());
		}

		return result;
	}
}
