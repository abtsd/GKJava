package deep_copy;

import java.io.Serializable;

public class Konto implements Serializable {
	private static final long serialVersionUID = 1L;
	private int ktoId;
	private double saldo;
	private Kunde kd;

	public Konto() {
	}

	public Konto(int ktoId, double saldo) {
		this.ktoId = ktoId;
		this.saldo = saldo;
	}

	public void setKtoId(int ktoId) {
		this.ktoId = ktoId;
	}

	public int getKtoId() {
		return ktoId;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setKunde(Kunde kd) {
		this.kd = kd;
	}

	public Kunde getKunde() {
		return kd;
	}

	public void add(double betrag) {
		saldo += betrag;
	}

	public String toString() {
		return "Konto [ktoId=" + ktoId + ", saldo=" + saldo + ", kd=" + kd + "]";
	}
}
