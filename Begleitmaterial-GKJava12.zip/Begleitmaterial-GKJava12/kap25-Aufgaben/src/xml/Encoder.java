package xml;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Encoder {
	public static void main(String[] args) {
		Artikel[] array = new Artikel[] {
				new Artikel(4711, "Hammer", 2.20, 100),
				new Artikel(4712, "Zange", 2.50, 50)
		};

		try (XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream("daten.xml")))) {
			encoder.writeObject(array.length);
			for (Artikel artikel : array) {
				encoder.writeObject(artikel);
			}
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		}
	}
}
