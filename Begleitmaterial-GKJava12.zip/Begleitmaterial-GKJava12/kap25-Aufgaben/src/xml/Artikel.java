package xml;

public class Artikel {
	private int id;
	private String name;
	private double preis;
	private int menge;

	public Artikel() {
	}

	public Artikel(int id, String name, double preis, int menge) {
		this.id = id;
		this.name = name;
		this.preis = preis;
		this.menge = menge;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPreis() {
		return preis;
	}

	public void setPreis(double preis) {
		this.preis = preis;
	}

	public int getMenge() {
		return menge;
	}

	public void setMenge(int menge) {
		this.menge = menge;
	}

	@Override
	public String toString() {
		return "Artikel{" +
				"id=" + id +
				", name='" + name + '\'' +
				", preis=" + preis +
				", menge=" + menge +
				'}';
	}
}
