package xml;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Decoder {
	public static void main(String[] args) {
		try (XMLDecoder decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("daten.xml")))) {
			int length = (Integer) decoder.readObject();
			for (int i = 0; i < length; i++) {
				Artikel a = (Artikel) decoder.readObject();
				System.out.println(a);
			}
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		}
	}
}
