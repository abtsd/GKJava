package eof;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SerializeTest2 {
	public static void main(String[] args) throws Exception {
		Kunde k1 = new Kunde("Meier, Hugo", "Hauptstr. 12, 40880 Ratingen");
		Kunde k2 = new Kunde("Schmitz, Otto", "Dorfstr. 5, 40880 Ratingen");

		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("kunden.ser"))) {
			out.writeObject(k1);
			out.writeObject(k2);
			out.writeObject(null);
			out.flush();
		}
	}
}
