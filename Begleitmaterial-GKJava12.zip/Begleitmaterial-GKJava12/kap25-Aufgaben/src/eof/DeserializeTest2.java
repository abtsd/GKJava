package eof;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializeTest2 {
	public static void main(String[] args) throws Exception {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("kunden.ser"))) {
			Kunde k;
			while ((k = (Kunde) in.readObject()) != null) {
				System.out.println(k.getName() + "; " + k.getAdresse());
			}
		}
	}
}
