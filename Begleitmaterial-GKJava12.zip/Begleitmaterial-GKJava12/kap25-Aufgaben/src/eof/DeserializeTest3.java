package eof;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializeTest3 {
	public static void main(String[] args) throws Exception {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("kunden.ser"))) {
			int n = in.readInt();
			for (int i = 0; i < n; i++) {
				Kunde k = (Kunde) in.readObject();
				System.out.println(k.getName() + "; " + k.getAdresse());
			}
		}
	}
}
