package eof;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeserializeTest1 {
	public static void main(String[] args) throws Exception {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("kunden.ser"))) {
			while (true) {
				Kunde k = (Kunde) in.readObject();
				System.out.println(k.getName() + "; " + k.getAdresse());
			}
		} catch (EOFException ignored) {
		}
	}
}
