package json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Map;

public class Store {
    public static void main(String[] args) throws IOException {
        Map<Integer, Artikel> map = Map.ofEntries(
                Map.entry(4711, new Artikel(4711, "Hammer", 2.20, 100)),
                Map.entry(4712, new Artikel(4712, "Zange", 2.50, 50)),
                Map.entry(4713, new Artikel(4713, "Zollstock", 1.50, 40))
        );

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (Writer writer = new FileWriter("daten.json")) {
            gson.toJson(map, writer);
        }
    }
}
