package json;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.Map;

public class Load {
    public static void main(String[] args) throws IOException {
        Gson gson = new Gson();

        try (Reader reader = new FileReader("daten.json")) {
            Type type = new TypeToken<Map<Integer, Artikel>>() {
            }.getType();
            Map<Integer, Artikel> map = gson.fromJson(reader, type);
            System.out.println(map);
            Artikel artikel = map.get(4711);
            System.out.println(artikel);
        }
    }
}
