package todo;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.MouseInputAdapter;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.print.PrinterException;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

public class ToDo extends JFrame {
	private static final String FILE_NAME = "todo.xml";

	private final JTextField item;
	private final JList<String> list;
	private Vector<String> items;

	public ToDo() {
		super("ToDo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Font inputFont = new Font(Font.DIALOG, Font.PLAIN, 20);
		Font labelFont = new Font(Font.DIALOG, Font.PLAIN, 18);

		item = new JTextField();
		item.setFont(inputFont);

		list = new JList<>();

		MyMouseAdapter adapter = new MyMouseAdapter();
		list.addMouseListener(adapter);
		list.addMouseMotionListener(adapter);

		JButton add = new JButton("Hinzufügen");
		JButton copy = new JButton("Kopieren");
		JButton removeItem = new JButton("Eintrag löschen");
		JButton removeList = new JButton("Liste löschen");
		JButton print = new JButton("Drucken");

		TitledBorder itemBorder = new TitledBorder("Eintrag");
		itemBorder.setTitleFont(labelFont);
		itemBorder.setTitleColor(Color.BLUE);
		item.setBorder(itemBorder);

		TitledBorder listBorder = new TitledBorder("Liste");
		listBorder.setTitleFont(labelFont);
		listBorder.setTitleColor(Color.BLUE);
		list.setBorder(listBorder);
		list.setFont(inputFont);

		add.addActionListener(e -> {
			String s = item.getText().trim();
			if (s.length() > 0) {
				items.add(s);
				list.setListData(items);
				item.setText("");
			}
		});

		copy.addActionListener(e ->
			item.setText(list.getSelectedValue())
		);

		removeItem.addActionListener(e -> {
			int[] idx = list.getSelectedIndices();
			for (int i = idx.length - 1; i >= 0; i--) {
				items.remove(idx[i]);
			}
			list.setListData(items);
		});

		removeList.addActionListener(e -> {
			items.clear();
			list.setListData(items);
		});

		print.addActionListener(e -> {
			JTextArea area = new JTextArea();
			area.setFont(new Font(Font.DIALOG, Font.PLAIN, 10));
			fillArea(area);

			Runnable printTask = () -> {
				try {
					area.print();
				} catch (PrinterException ex) {
					System.out.println(ex.getMessage());
				}
			};
			new Thread(printTask).start();
		});

		add(item, BorderLayout.NORTH);
		JScrollPane pane = new JScrollPane(list);
		add(pane, BorderLayout.CENTER);
		JPanel buttons = new JPanel();
		buttons.add(add);
		buttons.add(copy);
		buttons.add(removeItem);
		buttons.add(print);
		buttons.add(removeList);
		add(buttons, BorderLayout.SOUTH);

		load();
		if (items == null) {
			items = new Vector<>();
		}
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				store();
				System.exit(0);
			}
		});

		setSize(800, 600);
		setVisible(true);
	}

	public void load() {
		String dir = System.getProperty("user.home");
		try (XMLDecoder decoder = new XMLDecoder(new BufferedInputStream(
				new FileInputStream(new File(dir, FILE_NAME))))) {
			//noinspection unchecked
			items = (Vector<String>) decoder.readObject();
			list.setListData(items);
		} catch (FileNotFoundException ignored) {
		}
	}

	public void store() {
		String dir = System.getProperty("user.home");
		try (XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(
				new FileOutputStream(new File(dir, FILE_NAME))))) {
			encoder.writeObject(items);
		} catch (FileNotFoundException ex) {
			System.err.println(ex.getMessage());
		}
	}

	private class MyMouseAdapter extends MouseInputAdapter {
		private int dragSourceIndex;

		@Override
		public void mousePressed(MouseEvent e) {
			dragSourceIndex = list.getSelectedIndex();
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			int currentIndex = list.getSelectedIndex();
			if (currentIndex != dragSourceIndex) {
				int dragTargetIndex = list.getSelectedIndex();
				String dragElement = items.get(dragSourceIndex);
				items.remove(dragSourceIndex);
				items.add(dragTargetIndex, dragElement);
				dragSourceIndex = currentIndex;
				list.setListData(items);
			}
		}
	}

	private void fillArea(JTextArea area) {
		Date now = new Date();
		SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		area.append(f.format(now) + "\n\n");
		for (String item : items) {
			area.append(item + "\n");
		}
	}

	public static void main(String[] args) {
		new ToDo();
	}
}
