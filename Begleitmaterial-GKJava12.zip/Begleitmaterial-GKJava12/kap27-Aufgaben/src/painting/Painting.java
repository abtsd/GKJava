package painting;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;
import java.util.ArrayList;

public class Painting extends JFrame {
	private static final String FILE_NAME = "zeichnung.xml";

	private final JCheckBox filled;
	private final JComboBox<String> colors;
	private boolean isFilled;
	private ArrayList<MyRectangle> rectangles = new ArrayList<>();
	private MyRectangle currentRectangle;
	private Color color;

	public Painting() {
		super("Painting");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Content content = new Content();
		add(content, BorderLayout.CENTER);

		JPanel p = new JPanel();

		String[] items = {"schwarz", "weiß", "blau", "gelb", "grün", "rot"};
		colors = new JComboBox<>(items);
		colors.addActionListener(e -> {
			String item = (String) colors.getSelectedItem();
			if (item == null)
				return;
			switch (item) {
				case "schwarz" -> color = Color.BLACK;
				case "weiß" -> color = Color.WHITE;
				case "blau" -> color = Color.BLUE;
				case "gelb" -> color = Color.YELLOW;
				case "grün" -> color = Color.GREEN;
				case "rot" -> color = Color.RED;
			}
		});
		p.add(colors);

		filled = new JCheckBox("gefüllt", false);
		filled.addActionListener(e -> isFilled = filled.isSelected());
		p.add(filled);

		JButton clear = new JButton("Löschen");
		clear.addActionListener(e -> {
			rectangles.clear();
			currentRectangle = null;
			repaint();
		});
		p.add(clear);

		JButton save = new JButton("Speichern");
		save.addActionListener(e -> {
			try (XMLEncoder encoder = new XMLEncoder(
					new BufferedOutputStream(new FileOutputStream(FILE_NAME)))) {
				encoder.writeObject(rectangles);
			} catch (FileNotFoundException ex) {
				System.err.println(ex.getMessage());
			}
		});
		p.add(save);

		JButton load = new JButton("Laden");
		load.addActionListener(e -> {
			try (XMLDecoder decoder = new XMLDecoder(
					new BufferedInputStream(new FileInputStream(FILE_NAME)))) {
				//noinspection unchecked
				rectangles = (ArrayList<MyRectangle>) decoder.readObject();
				repaint();
			} catch (FileNotFoundException ex) {
				System.err.println(ex.getMessage());
			}
		});
		p.add(load);

		add(p, BorderLayout.SOUTH);

		pack();
		setVisible(true);
	}

	private class Content extends JPanel {
		public Content() {
			setBackground(Color.WHITE);
			setPreferredSize(new Dimension(600, 400));
			MyMouseAdapter adapter = new MyMouseAdapter();
			addMouseListener(adapter);
			addMouseMotionListener(adapter);
		}

        @Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			for (MyRectangle r : rectangles) {
				g.setColor(r.color);
				if (r.isFilled)
					g.fillRect(r.x, r.y, r.b, r.h);
				else
					g.drawRect(r.x, r.y, r.b, r.h);
			}

			if (currentRectangle != null) {
				g.setColor(currentRectangle.color);
				if (currentRectangle.isFilled)
					g.fillRect(currentRectangle.x, currentRectangle.y, currentRectangle.b, currentRectangle.h);
				else
					g.drawRect(currentRectangle.x, currentRectangle.y, currentRectangle.b, currentRectangle.h);
			}
		}

		class MyMouseAdapter extends MouseAdapter {
			@Override
			public void mousePressed(MouseEvent e) {
				currentRectangle = new MyRectangle(isFilled, color, e.getX(), e.getY(), 0, 0);
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				if (currentRectangle.b > 0 && currentRectangle.h > 0)
					rectangles.add(currentRectangle);
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();

				if (x > currentRectangle.x && y > currentRectangle.y) {
					currentRectangle.b = x - currentRectangle.x;
					currentRectangle.h = y - currentRectangle.y;
					if (e.isShiftDown())
						currentRectangle.h = currentRectangle.b;
				}

				repaint();
			}
		}
	}

	public static void main(String[] args) {
		new Painting();
	}
}
