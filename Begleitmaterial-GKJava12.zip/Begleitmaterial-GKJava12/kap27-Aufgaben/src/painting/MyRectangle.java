package painting;

import java.awt.*;

public class MyRectangle {
	int x, y, b, h;
	boolean isFilled;
	Color color;

	public MyRectangle() {
	}

	public MyRectangle(boolean isFilled, Color color, int x, int y, int b, int h) {
		this.isFilled = isFilled;
		this.color = color;
		this.x = x;
		this.y = y;
		this.b = b;
		this.h = h;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public boolean isFilled() {
		return isFilled;
	}

	public void setFilled(boolean filled) {
		isFilled = filled;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
}
