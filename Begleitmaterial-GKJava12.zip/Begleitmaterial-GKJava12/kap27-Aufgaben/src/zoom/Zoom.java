package zoom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Zoom extends JFrame {
	private static final int DEFAULT_SIZE = 18;
	private final JTextArea area;
	private final String fontName = "DialogInput";
	private final int fontStyle = Font.PLAIN;
	private int fontSize = DEFAULT_SIZE;

	public Zoom() {
		super("Zoom");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		area = new JTextArea();
		area.setWrapStyleWord(true);
		area.setLineWrap(true);
		area.setFont(new Font(fontName, fontStyle, fontSize));
		add(new JScrollPane(area, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER));

		area.addMouseWheelListener(e -> {
			if (e.isControlDown()) {
				if (e.getWheelRotation() < 0) {
					area.setFont(new Font(fontName, fontStyle, fontSize++));
				} else {
					area.setFont(new Font(fontName, fontStyle, fontSize--));
				}
			}
		});

		area.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.isControlDown()) {
					switch (e.getKeyCode()) {
						case KeyEvent.VK_PLUS -> area.setFont(new Font(fontName, fontStyle, fontSize++));
						case KeyEvent.VK_MINUS -> area.setFont(new Font(fontName, fontStyle, fontSize--));
						case KeyEvent.VK_0 -> {
							fontSize = DEFAULT_SIZE;
							area.setFont(new Font(fontName, fontStyle, fontSize));
						}
					}
				}
			}
		});

		setSize(800, 600);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Zoom();
	}
}
