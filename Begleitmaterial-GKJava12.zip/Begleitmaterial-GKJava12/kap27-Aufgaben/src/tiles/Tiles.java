package tiles;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Tiles extends JFrame {
	private final JPanel[] panels;

	public Tiles() {
		super("Tiles");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel tiles = new JPanel();
		tiles.setBackground(Color.LIGHT_GRAY);
		tiles.setLayout(new GridLayout(7, 7, 1, 1));

		panels = new JPanel[49];
		
		for (int i = 0; i < 49; i++) {
			panels[i] = new JPanel();

			panels[i].addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					JPanel p = (JPanel) e.getSource();
					p.setBackground(getRandomColor());
				}
			});

			tiles.add(panels[i]);
		}

		reset();

		add(tiles, BorderLayout.CENTER);

		JPanel p = new JPanel();
		JButton colors = new JButton("Farben");
		colors.addActionListener(e -> setColors());
		p.add(colors);
		JButton reset = new JButton("Zurücksetzen");
		reset.addActionListener(e -> reset());
		p.add(reset);
		add(p, BorderLayout.SOUTH);

		setSize(400, 400);
		setVisible(true);
	}

	private Color getRandomColor() {
		Random random = new Random();
		return new Color(random.nextInt(256), random.nextInt(256),
				random.nextInt(256), 255);
	}

	private void setColors() {
		for (int i = 0; i < 49; i++) {
			panels[i].setBackground(getRandomColor());
		}
	}

	private void reset() {
		for (int i = 0; i < 49; i++) {
			panels[i].setBackground(Color.WHITE);
		}
	}

	public static void main(String[] args) {
		new Tiles();
	}
}
