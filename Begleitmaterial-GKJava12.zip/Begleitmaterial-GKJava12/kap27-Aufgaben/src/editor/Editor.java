package editor;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Editor extends JFrame {
	private String file;
	private final JTextArea text;

	public Editor() {
		super("Editor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JMenuBar menuBar = new JMenuBar();
		menuBar.add(buildMenu());
		setJMenuBar(menuBar);

		text = new JTextArea();
		text.setFont(new Font("Monospaced", Font.PLAIN, 14));
		add(new JScrollPane(text));

		setSize(800, 600);
		setVisible(true);
	}

	private void doNew() {
		text.setText("");
		file = null;
		setTitle("Unbekannt.txt");
	}

	private void doOpen() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("."));
		fileChooser.setFileFilter(new MyFilter());
		int result = fileChooser.showOpenDialog(null);
		if (result != JFileChooser.APPROVE_OPTION)
			return;

		String filename = fileChooser.getSelectedFile().getPath();
		try {
			text.read(new FileReader(filename), null);
			this.file = filename;
			setTitle(this.file);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	private void doSave() {
		if (file == null) {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("."));
			fileChooser.setFileFilter(new MyFilter());
			fileChooser.setSelectedFile(new File("Unbekannt.txt"));
			int result = fileChooser.showSaveDialog(null);
			if (result != JFileChooser.APPROVE_OPTION)
				return;
			file = fileChooser.getSelectedFile().getPath();
		}

		try {
			text.write(new FileWriter(file));
			setTitle(file);
		} catch (IOException e) {
			file = null;
			System.out.println(e.getMessage());
		}
	}

	private void doSaveAs() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("."));
		fileChooser.setFileFilter(new MyFilter());
		if (file == null)
			fileChooser.setSelectedFile(new File("Unbekannt.txt"));
		int result = fileChooser.showSaveDialog(null);
		if (result != JFileChooser.APPROVE_OPTION)
			return;

		String filename = fileChooser.getSelectedFile().getPath();
		try {
			text.write(new FileWriter(filename));
			file = filename;
			setTitle(file);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	private JMenu buildMenu() {
		JMenu menu = new JMenu("Datei");

		JMenuItem mi = new JMenuItem("Neu");
		mi.addActionListener(e -> doNew());
		menu.add(mi);

		mi = new JMenuItem("Öffnen...");
		mi.addActionListener(e -> doOpen());
		menu.add(mi);

		mi = new JMenuItem("Speichern");
		mi.addActionListener(e -> doSave());
		menu.add(mi);

		mi = new JMenuItem("Speichern unter...");
		mi.addActionListener(e -> doSaveAs());
		menu.add(mi);

		menu.addSeparator();

		mi = new JMenuItem("Beenden");
		mi.addActionListener(e -> dispose());
		menu.add(mi);

		return menu;
	}

	private static class MyFilter extends FileFilter {
		@Override
		public boolean accept(File f) {
			if (f.isDirectory())
				return true;
			String name = f.getName();
			if (name.endsWith(".java"))
				return true;
			else return name.endsWith(".txt");
		}

		@Override
		public String getDescription() {
			return "Text file (*.java,*.txt)";
		}
	}

	public static void main(String[] args) {
		new Editor();
	}
}
