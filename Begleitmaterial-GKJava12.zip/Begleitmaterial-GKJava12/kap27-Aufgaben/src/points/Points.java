package points;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class Points extends JFrame {
	public Points() {
		super("Points");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new MyCanvas());
		setSize(400, 300);
		setVisible(true);
	}

	private static class MyCanvas extends JPanel {
		private final List<Point> points = new ArrayList<>();

		public MyCanvas() {
			setBackground(Color.WHITE);
			setForeground(Color.RED);

			addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					points.add(e.getPoint());
					repaint();
				}
			});
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			for (Point p : points) {
				g.fillOval(p.x - 4, p.y - 4, 8, 8);
			}
		}
	}

	public static void main(String[] args) {
		new Points();
	}
}
