package gridbag;

import javax.swing.*;
import java.awt.*;

public class GridBagLayoutDemo extends JFrame {
	public GridBagLayoutDemo() {
		super("GridBagLayoutDemo");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container container = getContentPane();

		GridBagLayout gridbag = new GridBagLayout();
		GridBagConstraints constraints = new GridBagConstraints();
		container.setLayout(gridbag);

		// Label: Titel
		constraints.insets = new Insets(10, 0, 10, 0);
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		JLabel title = new JLabel("Artikeldaten");
		title.setFont(new Font("SansSerif", Font.BOLD, 24));
		title.setForeground(Color.red);
		gridbag.setConstraints(title, constraints);
		container.add(title);

		// Label: Artikel
		constraints.insets = new Insets(3, 3, 3, 3);
		constraints.gridwidth = GridBagConstraints.RELATIVE;
		constraints.anchor = GridBagConstraints.EAST;
		JLabel articleLabel = new JLabel("Artikel:");
		gridbag.setConstraints(articleLabel, constraints);
		container.add(articleLabel);

		// Textfeld: Artikel
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		JTextField article = new JTextField(30);
		gridbag.setConstraints(article, constraints);
		container.add(article);

		// Label: Warengruppe
		constraints.gridwidth = GridBagConstraints.RELATIVE;
		constraints.anchor = GridBagConstraints.EAST;
		JLabel groupLabel = new JLabel("Warengruppe:");
		gridbag.setConstraints(groupLabel, constraints);
		container.add(groupLabel);

		// Combobox: Warengruppe
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		String[] list = { "Warengruppe 1", "Warengruppe 2", "Warengruppe 3", "Warengruppe 4" };
		JComboBox<String> group = new JComboBox<>(list);
		gridbag.setConstraints(group, constraints);
		container.add(group);

		// Label: Beschreibung
		constraints.gridwidth = GridBagConstraints.RELATIVE;
		constraints.anchor = GridBagConstraints.NORTHEAST;
		JLabel descLabel = new JLabel("Beschreibung:");
		gridbag.setConstraints(descLabel, constraints);
		container.add(descLabel);

		// Textfläche: Beschreibung
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		JTextArea desc = new JTextArea(5, 30);
		JScrollPane scroll = new JScrollPane(desc);
		gridbag.setConstraints(scroll, constraints);
		container.add(scroll);

		// Label: Lieferbar
		constraints.gridwidth = GridBagConstraints.RELATIVE;
		constraints.anchor = GridBagConstraints.EAST;
		JLabel availableLabel = new JLabel("Lieferbar?");
		gridbag.setConstraints(availableLabel, constraints);
		container.add(availableLabel);

		// Checkbox: Lieferbar
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		JCheckBox available = new JCheckBox();
		gridbag.setConstraints(available, constraints);
		container.add(available);

		// Label: Lager
		constraints.gridwidth = GridBagConstraints.RELATIVE;
		constraints.anchor = GridBagConstraints.EAST;
		JLabel stockLabel = new JLabel("Lager:");
		gridbag.setConstraints(stockLabel, constraints);
		container.add(stockLabel);

		// Radiobuttons
		JRadioButton rb1 = new JRadioButton("A", true);
		JRadioButton rb2 = new JRadioButton("B");
		JRadioButton rb3 = new JRadioButton("C");
		ButtonGroup bg = new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		JPanel rb = new JPanel();
		rb.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		rb.add(rb1);
		rb.add(rb2);
		rb.add(rb3);
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.WEST;
		gridbag.setConstraints(rb, constraints);
		container.add(rb);

		// Button: OK
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.CENTER;
		constraints.ipadx = 50;
		constraints.insets = new Insets(10, 0, 10, 0);
		JButton ok = new JButton("OK");
		gridbag.setConstraints(ok, constraints);
		container.add(ok);

		pack();
		setVisible(true);
	}

	public static void main(String[] args) {
		new GridBagLayoutDemo();
	}
}
