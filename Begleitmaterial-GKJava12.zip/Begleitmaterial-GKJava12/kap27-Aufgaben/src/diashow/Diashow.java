package diashow;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Arrays;

public class Diashow extends JFrame implements Runnable {
	private final String dir;
	private final int delay;
	private final JLabel image;
	private final JLabel text;
	private final File[] files;

	public Diashow(String dir, int delay) {
		super("Diashow");

		this.dir = dir;
		this.delay = delay;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		text = new JLabel();
		text.setHorizontalAlignment(JLabel.CENTER);
		add(text, BorderLayout.NORTH);

		image = new JLabel();
		image.setHorizontalAlignment(JLabel.CENTER);
		image.setVerticalAlignment(JLabel.CENTER);
		add(image, BorderLayout.CENTER);

		setSize(800, 800);
		setVisible(true);

		files = getFiles();
		if (files == null) {
			text.setText(dir + " ist kein Verzeichnis");
		} else if (files.length == 0) {
			text.setText(dir + " enthält keine Bilder");
		} else {
			Arrays.sort(files);
			new Thread(this).start();
		}
	}

	public File[] getFiles() {
		File file = new File(dir);
		return file.listFiles(pathname -> {
			if (!pathname.isFile())
				return false;
			String name = pathname.getName().toLowerCase();
			return name.endsWith(".gif") || name.endsWith(".jpg")
					|| name.endsWith(".jpeg") || name.endsWith(".png");
		});
	}

	public void run() {
		int i = 0;

		while (true) {
			text.setText(files[i].getName());
			ImageIcon icon = new ImageIcon(files[i].getPath());
			image.setIcon(icon);
			try {
				Thread.sleep(delay);
			} catch (InterruptedException ignored) {
			}

			i++;
			if (i == files.length)
				i = 0;
		}
	}

	public static void main(String[] args) {
		String dir = args[0];
		int delay = Integer.parseInt(args[1]);
		new Diashow(dir, delay);
	}
}
