package time_display;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeDisplay extends JFrame {
	private final JButton button;
	private Thread t;
	private volatile String datum;

	public TimeDisplay() {
		super("TimeDisplay");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		add(new MyCanvas(), BorderLayout.CENTER);

		JPanel p = new JPanel();
		button = new JButton("Start");
		button.addActionListener(e -> {
			if (button.getText().equals("Start")) {
				start();
				button.setText("Stop");
			} else {
				stop();
				button.setText("Start");
			}
		});
		p.add(button);
		add(p, BorderLayout.SOUTH);

		setSize(600, 200);
		setVisible(true);
	}

	private class MyCanvas extends JPanel {
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);

			if (datum != null) {
				g.setFont(new Font("SansSerif", Font.BOLD, 48));
				g.setColor(Color.red);
				g.drawString(datum, 20, 80);
			}
		}
	}

	public void start() {
		if (t == null) {
			t = new Thread(() -> {
				while (true) {
					SimpleDateFormat f = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
					datum = f.format(new Date());
					repaint();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						break;
					}
				}
			});
			t.start();
		}
	}

	public void stop() {
		if (t != null) {
			t.interrupt();
			t = null;
		}
		datum = null;
		repaint();
	}

	public static void main(String[] args) {
		new TimeDisplay();
	}
}
