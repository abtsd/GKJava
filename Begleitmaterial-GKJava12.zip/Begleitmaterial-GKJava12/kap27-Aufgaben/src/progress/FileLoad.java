package progress;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileLoad extends JFrame implements Runnable {
	private final JProgressBar bar;
	private final JButton load;
	private File file;

	public FileLoad() {
		super("FileLoad");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel p1 = new JPanel();
		bar = new JProgressBar(0, 100);
		bar.setValue(0);
		bar.setStringPainted(true);
		p1.add(bar);
		add(p1, BorderLayout.CENTER);

		JPanel p2 = new JPanel();
		load = new JButton("Laden");
		load.addActionListener(e -> {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("."));
			if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
				file = fileChooser.getSelectedFile();
				load.setEnabled(false);
				bar.setValue(0);
				Thread t = new Thread(this);
				t.setPriority(Thread.NORM_PRIORITY);
				t.start();
				System.out.println(t.getPriority());
			}
		});
		p2.add(load);
		add(p2, BorderLayout.SOUTH);

		setSize(300, 150);
		setVisible(true);
	}

	public void run() {
		try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
			long count = 0;
			long length = file.length();

			while (in.read() != -1) {
				if (++count % 500 == 0) {
					final int value = (int) ((double) count / length * 100);
					EventQueue.invokeLater(() -> bar.setValue(value));
				}
			}

			EventQueue.invokeLater(() -> {
				bar.setValue(100);
				load.setEnabled(true);
			});
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}

	public static void main(String[] args) {
		new FileLoad();
	}
}
