package window_events;

import javax.swing.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class WindowEvents extends JFrame implements WindowListener {
	public WindowEvents() {
		super("WindowEvents");
		addWindowListener(this);
		setSize(300, 200);
		setVisible(true);
	}

	public void windowClosing(WindowEvent e) {
		System.out.println("windowClosing");
		dispose();
	}

	public void windowActivated(WindowEvent e) {
		System.out.println("windowActivated");
	}

	public void windowClosed(WindowEvent e) {
		System.out.println("windowClosed");
	}

	public void windowDeactivated(WindowEvent e) {
		System.out.println("windowDeactivated");
	}

	public void windowDeiconified(WindowEvent e) {
		System.out.println("windowDeiconified");
	}

	public void windowIconified(WindowEvent e) {
		System.out.println("windowIconified");
	}

	public void windowOpened(WindowEvent e) {
		System.out.println("windowOpened");
	}

	public static void main(String[] args) {
		new WindowEvents();
	}
}
