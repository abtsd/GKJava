package colors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class ColorTest extends JFrame {
	private int r = 255;
	private int g = 255;
	private int b = 255;

	public ColorTest() {
		super("ColorTest");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel sliders = new JPanel();
		sliders.setLayout(new GridLayout(3, 3));
		sliders.setBorder(new EmptyBorder(10, 10, 10, 10));

		sliders.add(new JLabel("R", JLabel.CENTER));
		sliders.add(new JLabel("G", JLabel.CENTER));
		sliders.add(new JLabel("B", JLabel.CENTER));

		JSlider rSlider = new JSlider(JSlider.HORIZONTAL, 0, 255, 255);
		rSlider.setMajorTickSpacing(85);
		rSlider.setPaintTicks(true);
		rSlider.setPaintLabels(true);
		sliders.add(rSlider);

		JSlider gSlider = new JSlider(JSlider.HORIZONTAL, 0, 255, 255);
		gSlider.setMajorTickSpacing(85);
		gSlider.setPaintTicks(true);
		gSlider.setPaintLabels(true);
		sliders.add(gSlider);

		JSlider bSlider = new JSlider(JSlider.HORIZONTAL, 0, 255, 255);
		bSlider.setMajorTickSpacing(85);
		bSlider.setPaintTicks(true);
		bSlider.setPaintLabels(true);
		sliders.add(bSlider);

		JLabel rLabel = new JLabel("255", JLabel.CENTER);
		sliders.add(rLabel);

		JLabel gLabel = new JLabel("255", JLabel.CENTER);
		sliders.add(gLabel);

		JLabel bLabel = new JLabel("255", JLabel.CENTER);
		sliders.add(bLabel);

		add(sliders, BorderLayout.NORTH);

		JPanel colorPanel = new JPanel();
		colorPanel.setBackground(new Color(255, 255, 255));
		add(colorPanel, BorderLayout.CENTER);

		rSlider.addChangeListener(e -> {
			r = rSlider.getValue();
			colorPanel.setBackground(new Color(r, g, b));
			rLabel.setText(String.valueOf(r));
		});

		gSlider.addChangeListener(e -> {
			g = gSlider.getValue();
			colorPanel.setBackground(new Color(r, g, b));
			gLabel.setText(String.valueOf(g));
		});

		bSlider.addChangeListener(e -> {
			b = bSlider.getValue();
			colorPanel.setBackground(new Color(r, g, b));
			bLabel.setText(String.valueOf(b));
		});

		setSize(600, 300);
		setVisible(true);
	}

	public static void main(String[] args) {
		new ColorTest();
	}
}
