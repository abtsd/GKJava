package image_viewer;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.io.File;

public class ImageViewer extends JFrame {
	private JLabel imageLabel;

	public ImageViewer() {
		super("ImageViewer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel top = new JPanel();
		JButton open = new JButton("Öffnen");
		open.addActionListener(e -> {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("./src/image_viewer"));
			fileChooser.setFileFilter(new MyFilter());
			int result = fileChooser.showOpenDialog(this);
			if (result == JFileChooser.APPROVE_OPTION) {
				File f = fileChooser.getSelectedFile();
				ImageIcon icon = new ImageIcon(f.getPath());
				imageLabel.setIcon(icon);
			}
		});
		top.add(open);
		add(top, BorderLayout.NORTH);

		imageLabel = new JLabel();
		imageLabel.setHorizontalAlignment(JLabel.CENTER);
		imageLabel.setVerticalAlignment(JLabel.CENTER);
		JScrollPane sp = new JScrollPane(imageLabel);
		add(sp, BorderLayout.CENTER);

		setSize(300, 400);
		setVisible(true);
	}

	private static class MyFilter extends FileFilter {
		@Override
		public boolean accept(File file) {
			if (file.isDirectory())
				return true;

			String name = file.getName();
			if (name.endsWith(".gif"))
				return true;
			if (name.endsWith(".jpg"))
				return true;
			if (name.endsWith(".jpeg"))
				return true;
			return name.endsWith(".png");
		}

		@Override
		public String getDescription() {
			return "Image file (*.gif,*.jpg,*.jpeg, *.png)";
		}
	}

	public static void main(String[] args) {
		new ImageViewer();
	}
}
