package measures;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.DecimalFormat;

public class Measures extends JFrame {
	private final JTextField input;
	private JTextField m;
	private JTextField inch;
	private JTextField foot;
	private JTextField yard;
	private final JComboBox<String> selectionBox;
	private final StringBuilder number;
	private String unit;

	public Measures() {
		super("Measures");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container container = getContentPane();
		container.setLayout(new BorderLayout(10, 10));

		JPanel p1 = new JPanel();
		p1.setLayout(new FlowLayout(FlowLayout.CENTER, 25, 10));
		input = new JTextField(20);
		input.setHorizontalAlignment(JTextField.RIGHT);
		input.setFont(new Font("Monospaced", Font.PLAIN, 18));
		p1.add(input);
		String[] items = { "m", "inch", "foot", "yard" };
		selectionBox = new JComboBox<>(items);
		selectionBox.addActionListener(e -> {
			unit = (String) selectionBox.getSelectedItem();
			m.setText("");
			inch.setText("");
			foot.setText("");
			yard.setText("");
		});
		p1.add(selectionBox);
		container.add(p1, BorderLayout.NORTH);

		JPanel p2 = new JPanel();
		p2.setLayout(new GridLayout(4, 3, 5, 5));
		addButton(p2, "7");
		addButton(p2, "8");
		addButton(p2, "9");
		addButton(p2, "4");
		addButton(p2, "5");
		addButton(p2, "6");
		addButton(p2, "1");
		addButton(p2, "2");
		addButton(p2, "3");
		addButton(p2, "0");
		addButton(p2, ".");
		addButton(p2, "C");
		p2.setBorder(new EmptyBorder(0, 20, 0, 0));
		container.add(p2, BorderLayout.CENTER);

		JPanel p3 = new JPanel();
		p3.setLayout(new GridLayout(4, 2, 10, 5));
		m = addField(p3, "m");
		inch = addField(p3, "inch");
		foot = addField(p3, "foot");
		yard = addField(p3, "yard");
		container.add(p3, BorderLayout.EAST);

		JPanel p4 = new JPanel();
		addButton(p4, "Berechnen");
		container.add(p4, BorderLayout.SOUTH);

		number = new StringBuilder();
		unit = "m";

		pack();
		setVisible(true);
	}

	private void addButton(JPanel panel, String s) {
		JButton button = new JButton(s);
		button.addActionListener(e -> keyAction(button.getText()));
		panel.add(button);
	}

	private JTextField addField(JPanel panel, String s) {
		JTextField textField = new JTextField(20);
		textField.setHorizontalAlignment(JTextField.RIGHT);
		textField.setFont(new Font("Monospaced", Font.PLAIN, 12));
		textField.setEditable(false);
		JPanel p = new JPanel();
		p.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 5));
		p.add(textField);
		p.add(new JLabel(s));
		panel.add(p);
		return textField;
	}

	private void keyAction(String text) {
		number.setLength(0);
		number.append(input.getText());

		if (text.compareTo("0") >= 0 && text.compareTo("9") <= 0) {
			number.append(text);
			input.setText(number.toString());
		}

		switch (text) {
			case "." -> {
				if (number.toString().indexOf('.') == -1) {
					number.append(".");
					input.setText(number.toString());
				}
			}
			case "C" -> {
				number.setLength(0);
				input.setText("");
			}
			case "Berechnen" -> {
				m.setText("");
				inch.setText("");
				foot.setText("");
				yard.setText("");
				try {
					String s = number.toString().replace(',', '.');
					double val = Double.parseDouble(s);
					convert(val, unit);
				} catch (NumberFormatException ex) {
					number.setLength(0);
					input.setText("");
				}
			}
		}
	}

	private void convert(double value, String e) {
		double result;
		switch (e) {
			case "m" -> {
				result = value;
				m.setText(format(result));
				result = 1. / 0.0254 * value;
				inch.setText(format(result));
				result = 1. / 0.3048 * value;
				foot.setText(format(result));
				result = 1. / 0.9144 * value;
				yard.setText(format(result));
			}
			case "inch" -> {
				result = 0.0254 * value;
				m.setText(format(result));
				result = value;
				inch.setText(format(result));
				result = 1. / 12. * value;
				foot.setText(format(result));
				result = 1. / 36. * value;
				yard.setText(format(result));
			}
			case "foot" -> {
				result = 0.3048 * value;
				m.setText(format(result));
				result = 12 * value;
				inch.setText(format(result));
				result = value;
				foot.setText(format(result));
				result = 1. / 3. * value;
				yard.setText(format(result));
			}
			case "yard" -> {
				result = 0.9144 * value;
				m.setText(format(result));
				result = 36 * value;
				inch.setText(format(result));
				result = 3 * value;
				foot.setText(format(result));
				result = value;
				yard.setText(format(result));
			}
		}
	}

	private static String format(double value) {
		DecimalFormat decimalFormat = new DecimalFormat("0.0000");
		return decimalFormat.format(value);
	}

	public static void main(String[] args) {
		new Measures();
	}
}
