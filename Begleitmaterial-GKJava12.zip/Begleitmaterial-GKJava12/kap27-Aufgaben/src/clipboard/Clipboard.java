package clipboard;

import javax.swing.*;
import java.awt.*;

public class Clipboard extends JFrame {
	public Clipboard() {
		super("Clipboard");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JTextArea text = new JTextArea();
		add(new JScrollPane(text), BorderLayout.CENTER);

		JPanel buttons = new JPanel();

		JButton copy = new JButton("Copy");
		copy.addActionListener(e -> text.copy());
		buttons.add(copy);

		JButton cut = new JButton("Cut");
		cut.addActionListener(e -> text.cut());
		buttons.add(cut);

		JButton paste = new JButton("Paste");
		paste.addActionListener(e -> text.paste());
		buttons.add(paste);

		add(buttons, BorderLayout.SOUTH);

		setSize(500, 200);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Clipboard();
	}
}
