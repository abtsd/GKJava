module text {
	requires org.apache.commons.text;
}