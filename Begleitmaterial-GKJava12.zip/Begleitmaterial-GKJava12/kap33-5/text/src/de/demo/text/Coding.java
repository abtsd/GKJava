package de.demo.text;

import org.apache.commons.text.AlphabetConverter;

import java.io.UnsupportedEncodingException;

public class Coding {
	public static void main(String[] args) throws UnsupportedEncodingException {
		Character[] originals = new Character[]{'a', 'b', 'c', 'd', 'e', 'f', ' '};
		Character[] encoding = new Character[]{'1', '2', '3', '4', '5', '6', '-'};

		AlphabetConverter converter = AlphabetConverter.createConverterFromChars(
				originals, encoding, null);

		String encoded = converter.encode("f e d c b a");
		System.out.println(encoded);

		String decoded = converter.decode(encoded);
		System.out.println(decoded);
	}
}
