module db {
    requires java.sql;
}