package de.demo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {
	public static void main(String[] args) {
		String url = "jdbc:sqlite:mydb.db";
		try (Connection con = DriverManager.getConnection(url);
			 Statement stmt = con.createStatement()) {
			String sql = """
				create table if not exists artikel (
					id integer primary key,
					name text,
					preis real,
					menge integer)
				""";
			stmt.executeUpdate(sql);

			sql = """
				insert into artikel (id, name, preis, menge)
				values (4711, 'Hammer', 3.9, 10)
				""";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}
