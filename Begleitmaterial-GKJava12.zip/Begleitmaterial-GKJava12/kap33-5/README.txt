# Übersetzen
javac -d out/production/db db/src/*.java db/src/de/demo/db/*.java

javac -d out/production/text -p lib \
text/src/*.java text/src/de/demo/text/*.java

# JARs erzeugen
jar --create --file lib/db.jar -C out/production/db .
jar --create --file lib/text.jar -C out/production/text .

# und ausführen
java -p lib -m db/de.demo.db.CreateDB
java -p lib -m db/de.demo.db.Query

java -p lib -m text/de.demo.text.Coding

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s --multi-release 21 --module-path lib lib/db.jar lib/text.jar
jdeps -s --multi-release 21 -dotoutput graphs --module-path lib lib/db.jar lib/text.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
