package interface_als_typ;

public interface X {
	void method();
}
