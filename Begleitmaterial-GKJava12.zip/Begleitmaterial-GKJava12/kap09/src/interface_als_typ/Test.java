package interface_als_typ;

public class Test {
	public static void main(String[] args) {
		X x = new A();

		x.method();
		((A) x).doSomething();

		System.out.println(x instanceof A);
		System.out.println(x instanceof X);
	}
}
