package interface_als_typ;

public class A implements X {
	@Override
	public void method() {
		System.out.println("method");
	}

	public void doSomething() {
		System.out.println("doSomething");
	}
}
