package default1;

public class XImpl2 implements X {
    @Override
    public void m1() {
        System.out.println("Methode m1");
    }

    @Override
    public void m2() {
        System.out.println("Methode m2 neu implementiert");
    }

    public static void main(String[] args) {
        X x = new XImpl2();
        x.m2();
        x.m3();
    }
}