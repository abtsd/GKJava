package static_private;

public class B implements X {
	public static void main(String[] args) {
		B b = new B();
		b.m1();

		// Folgende Aufrufe sind nicht möglich:
		// b.m2();
		// b.m3();
		// B.m3();
	}
}
