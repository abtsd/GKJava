package static_private;

public class A {
	public static void main(String[] args) {
		X.m3();
	}
}
