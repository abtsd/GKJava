package static_private;

public interface X {
	default void m1() {
		System.out.println("Methode m1 aus X");
		m2();
	}

	private void m2() {
		System.out.println("Methode m2 aus X");
	}

	static void m3() {
		System.out.println("Methode m3 aus X");
	}
}