package default4;

public interface Y {
	default void m() {
		System.out.println("Methode m aus Y");
	}
}