package default4;

public class A implements X, Y {
	public void m() {
		System.out.println("Methode m aus A");
		// X.super.m();
	}

	public static void main(String[] args) {
		A a = new A();
		a.m();
	}
}