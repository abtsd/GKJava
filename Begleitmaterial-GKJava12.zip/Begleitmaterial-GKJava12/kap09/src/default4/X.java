package default4;

public interface X {
	default void m() {
		System.out.println("Methode m aus X");
	}
}