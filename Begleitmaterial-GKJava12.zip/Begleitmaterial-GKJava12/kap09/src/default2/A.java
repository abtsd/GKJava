package default2;

public class A {
	public void m() {
		System.out.println("Methode m aus A");
	}
}