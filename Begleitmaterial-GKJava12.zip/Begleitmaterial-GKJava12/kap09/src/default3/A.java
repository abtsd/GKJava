package default3;

public class A implements Y {
	public static void main(String[] args) {
		A a = new A();
		a.m();
	}
}