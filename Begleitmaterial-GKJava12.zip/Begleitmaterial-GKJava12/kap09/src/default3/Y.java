package default3;

public interface Y extends X {
	default void m() {
		System.out.println("Methode m aus Y");
	}
}