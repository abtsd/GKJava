package lifecycle1;

public interface Lifecycle {
	void start();

	void stop();
}