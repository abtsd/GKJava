package geo;

public class Rechteck implements Geo {
	private final double breite;
	private final double hoehe;

	public Rechteck(double breite, double hoehe) {
		this.breite = breite;
		this.hoehe = hoehe;
	}

	@Override
	public double getFlaeche() {
		return breite * hoehe;
	}
}
