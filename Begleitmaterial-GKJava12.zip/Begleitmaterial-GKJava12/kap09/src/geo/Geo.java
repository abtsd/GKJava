package geo;

public interface Geo {
	double getFlaeche();
}
