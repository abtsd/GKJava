package geo;

public class Kreis implements Geo {
	private final double radius;
	private static final double PI = 3.14159;

	public Kreis(double radius) {
		this.radius = radius;
	}

	@Override
	public double getFlaeche() {
		return PI * radius * radius;
	}
}
