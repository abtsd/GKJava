package geschachtelt;

public class A implements X, X.Y {
	public interface Z {
		void z();
	}
	
	public void x() {
		System.out.println("Methode x");
	}

	public void y() {
		System.out.println("Methode y");
	}
}
