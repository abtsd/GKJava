package geschachtelt;

public interface X {
	void x();
	
	interface Y {
		void y();
	}
}
