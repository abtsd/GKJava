package geschachtelt;

public class B implements A.Z {
	public void z() {
		System.out.println("Methode z");
	}
	
	public static void main(String[] args) {
		X a1 = new A();
		a1.x();
		
		X.Y a2 = new A();
		a2.y();
		
		A.Z b = new B();
		b.z();
	}
}
