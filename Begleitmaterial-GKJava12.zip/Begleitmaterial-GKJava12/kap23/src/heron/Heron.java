package heron;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Heron {
	public static Stream<Double> heron(double a) {
		return Stream.iterate((a + 1) / 2, x -> 0.5 * (x + a / x));
	}

	public static <T> Optional<T> find(Stream<T> stream, Predicate<T> predicate) {
		return stream.filter(predicate).findFirst();
	}

	public static void main(String[] args) {
		double a = 2;
		double EPSILON = 1.e-8;

		Optional<Double> value = find(heron(a), r -> Math.abs(r * r - a) < EPSILON);
		if (value.isPresent()) {
			double z = value.get();
			System.out.println("Wurzel  : " + Math.sqrt(a));
			System.out.println("Näherung: " + z);
		}
	}
}
