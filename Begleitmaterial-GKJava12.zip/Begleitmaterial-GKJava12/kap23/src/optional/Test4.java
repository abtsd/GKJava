package optional;

import artikel.Artikel;

import java.util.List;
import java.util.Optional;

public class Test4 {
	public static Optional<Artikel> findById(int id, List<Artikel> artikelListe) {
		return artikelListe
				.stream()
				.filter(a -> a.id() == id)
				.findFirst();
	}

	public static void main(String[] args) {
		List<Artikel> list1 = List.of(
				new Artikel(4711, 10.),
				new Artikel(4712, 20.),
				new Artikel(4713, 30.));

		List<Artikel> list2 = List.of(
				new Artikel(4714, 40.),
				new Artikel(4715, 50.),
				new Artikel(4716, 60.));

		int id = 4715;
		Optional<Artikel> optionalArtikel = findById(id, list1)
				.or(() -> findById(id, list2));

		optionalArtikel.ifPresentOrElse(
				System.out::println,
				() -> System.out.println("Artikel " + id + " nicht gefunden."));
	}
}
