package optional;

import artikel.Artikel;
import motivation.Test;

import java.util.List;
import java.util.Optional;

public class Test2 {
	public static Optional<Artikel> findById(int id, List<Artikel> artikelListe) {
		return Optional.ofNullable(Test.findById(id, artikelListe));
	}

	public static void main(String[] args) {
		List<Artikel> artikelListe = List.of(
				new Artikel(4711, 10.),
				new Artikel(4712, 20.),
				new Artikel(4713, 30.));

		int id = 4712;
		Optional<Artikel> optionalArtikel = findById(id, artikelListe);
		if (optionalArtikel.isPresent())
			System.out.println(optionalArtikel.get());
		else
			System.out.println("Artikel " + id + " nicht gefunden.");
	}
}
