package motivation;

import artikel.Artikel;

import java.util.List;

public class Test {
	public static Artikel findById(int id, List<Artikel> artikelListe) {
		for (Artikel artikel : artikelListe) {
			if (artikel.id() == id)
				return artikel;
		}
		return null;
	}

	public static void main(String[] args) {
		List<Artikel> artikelListe = List.of(
				new Artikel(4711, 10.),
				new Artikel(4712, 20.),
				new Artikel(4713, 30.));

		Artikel artikel = findById(4712, artikelListe);
		System.out.println(artikel.preis());

		artikel = findById(5000, artikelListe);
		System.out.println(artikel.preis());
	}
}
