package supplier;

import java.util.Optional;
import java.util.function.Supplier;

public class Test {
	public static <T> Optional<T> optional(Supplier<T> supplier) {
		try {
			return Optional.of(supplier.get());
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	public static void main(String[] args) {
		String text = "123";
		Optional<Integer> value = optional(() -> Integer.parseInt(text));
		value.ifPresentOrElse(System.out::println,
				() -> System.out.println("Keine Zahl"));
	}
}
