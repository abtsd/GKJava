package artikel;

public record Artikel(int id, double preis) {
}
