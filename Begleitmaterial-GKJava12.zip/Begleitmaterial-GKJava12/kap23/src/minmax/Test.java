package minmax;

import artikel.Artikel;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Test {
	public static void main(String[] args) {
		List<Artikel> list = List.of(
				new Artikel(4711, 10.),
				new Artikel(4712, 20.),
				new Artikel(4713, 30.));

		Optional<Double> min = list.stream()
				.min(Comparator.comparing(Artikel::preis))
				.map(Artikel::preis);

		Optional<Double> max = list.stream()
				.max(Comparator.comparing(Artikel::preis))
				.map(Artikel::preis);

		min.ifPresent(x -> System.out.println("Minimum: " + x));
		max.ifPresent(x -> System.out.println("Maximum: " + x));
	}
}
