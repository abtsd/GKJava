package lokale_klasse;

public interface Iterator {
	boolean hasNext();

	Object next();
}
