package statische_klasse;

public class Test {
	public static void main(String[] args) {
		Account account = new Account(4711);
		Account.Permissions perm = account.getPermissions();
		perm.canRead = true;
		perm.canWrite = true;
		System.out.println(account.getUserId());
		System.out.println(perm.info());
	}
}
