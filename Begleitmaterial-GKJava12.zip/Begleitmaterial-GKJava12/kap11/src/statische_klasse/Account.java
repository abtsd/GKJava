package statische_klasse;

public class Account {
	private final int userId;
	private final Permissions perm;

	public static class Permissions {
		public boolean canRead;
		public boolean canWrite;
		public boolean canDelete;

		public String info() {
			return "read: " + canRead + ", " + "write: " + canWrite + ", " +
					"delete: " + canDelete;
		}
	}

	public Account(int userId) {
		this.userId = userId;
		perm = new Permissions();
	}

	public int getUserId() {
		return userId;
	}

	public Permissions getPermissions() {
		return perm;
	}
}
