package clone3;

public class Test {
	public static void main(String[] args) throws CloneNotSupportedException {
		Kunde kunde = new Kunde("Hugo Meier", "Hauptstr. 12, 40880 Ratingen");

		Konto konto1 = new Konto(4711, 10000.);
		konto1.setKunde(kunde);

		Konto konto2 = konto1.clone();

		System.out.println("VORHER");
		System.out.println(konto2.getId());
		System.out.println(konto2.getSaldo());
		System.out.println(konto2.getKunde().getName());
		System.out.println(konto2.getKunde().getAdresse());

		kunde.setAdresse("Hauptstr. 42, 40880 Ratingen");

		System.out.println();
		System.out.println("NACHHER");
		System.out.println(konto2.getId());
		System.out.println(konto2.getSaldo());
		System.out.println(konto2.getKunde().getName());
		System.out.println(konto2.getKunde().getAdresse());
	}
}
