package object;

public class Test {
	public static void main(String[] args) {
		Kunde kunde = new Kunde("Hugo Meier", "Hauptstr. 12, 40880 Ratingen");

		Konto konto1 = new Konto(4711, 10000.);
		konto1.setKunde(kunde);

		Konto konto2 = new Konto(4811, 0.);

		System.out.println("Objekt konto1 gleicht Objekt konto2: "
				+ konto1.equals(konto2));
		System.out.println("Hashcode von Objekt kto1: " + konto1.hashCode());
		System.out.println("Hashcode von Objekt kto2: " + konto2.hashCode());
	}
}
