package math;

import java.util.Random;

public class RandomTest {
	public static void main(String[] args) {
		Random rand = new Random(1);
		for (int i = 0; i < 10; i++) {
			System.out.print(rand.nextInt(100) + " ");
		}
		System.out.println();

		rand.setSeed(2);
		for (int i = 0; i < 10; i++) {
			System.out.print(rand.nextInt(100) + " ");
		}
		System.out.println();

		rand = new Random();
		for (int i = 0; i < 10; i++) {
			System.out.print(rand.nextInt(100) + " ");
		}
	}
}
