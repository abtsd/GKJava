package math;

public class MathTest {
	public static void main(String[] args) {
		double x = 3.5, y = 2.;
		double abstand = Math.hypot(x, y);
		System.out.println("Abstand: " + abstand);

		double radius = 2.;
		double flaeche = Math.PI * Math.pow(radius, 2);
		System.out.println("Fläche: " + flaeche);

		double anfangsBetrag = 5000.;
		double zinssatz = 7.5;
		double n = 10.;
		double endBetrag = anfangsBetrag * Math.pow(1. + zinssatz / 100., n);
		System.out.println("Endbetrag: " + endBetrag);

		System.out.println(Math.ceil(3.6));
		System.out.println(Math.floor(3.6));
		System.out.println(Math.round(3.6));
	}
}
