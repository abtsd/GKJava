package math;

import java.math.BigInteger;
import java.util.Random;

public class Primzahlen {
	// erzeugt eine zufällige n-stellige Zahl
	public static BigInteger getZahl(int n) {
		Random r = new Random();
		StringBuilder s = new StringBuilder();

		s.append(1 + r.nextInt(9));
		for (int i = 1; i < n; i++) {
			s.append(r.nextInt(10));
		}

		return new BigInteger(s.toString());
	}

	// erzeugt ausgehend von start die nächste Primzahl > start
	public static BigInteger nextPrimzahl(BigInteger start) {
		if (start.mod(BigInteger.TWO).equals(BigInteger.ZERO)) // gerade Zahl?
			start = start.add(BigInteger.ONE);
		else
			start = start.add(BigInteger.TWO);

		if (start.isProbablePrime(100))
			return start;
		else
			return nextPrimzahl(start); // rekursiver Aufruf
	}

	public static void main(String[] args) {
		int num = 60;
		if (args.length > 0)
			num = Integer.parseInt(args[0]);

		BigInteger start = getZahl(num);

		for (int i = 0; i < 10; i++) {
			start = nextPrimzahl(start);
			System.out.println(start);
		}
	}
}
