package system;

import java.util.Enumeration;
import java.util.Properties;
import java.util.Scanner;

public class SystemTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.print("Key: ");
			String key = sc.nextLine();
			if (key.length() == 0)
				break;
			System.out.println(System.getProperty(key));
		}
		sc.close();

		Properties p = System.getProperties();
		Enumeration e = p.propertyNames();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			System.out.println(key + "=" + System.getProperty(key));
		}
	}
}
