package system;

public class PerformanceTest {
	private static final int MAX_ITERATIONS = 100;

	public static void testMethod() {
		// ...
	}

	public static void main(String[] args) {
		long start = System.nanoTime();
		for (int i = 0; i < MAX_ITERATIONS; i++) {
			testMethod();
		}
		long end = System.nanoTime();
		System.out.println((end - start) / MAX_ITERATIONS + " ns");
	}
}
