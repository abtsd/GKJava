package arrays;

public class Konto implements Comparable {
	private int id;
	private double saldo;

	public Konto() {
	}

	public Konto(int id, double saldo) {
		this.id = id;
		this.saldo = saldo;
	}

	public int getId() {
		return id;
	}

	public void setId(int nr) {
		id = nr;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double betrag) {
		saldo = betrag;
	}

	public void zahleEin(double betrag) {
		saldo += betrag;
	}

	public void zahleAus(double betrag) {
		saldo -= betrag;
	}

	@Override
	public String toString() {
		return "Konto{" +
				"id=" + id +
				", saldo=" + saldo +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Konto)) return false;
		return id == ((Konto) o).id;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public int compareTo(Object obj) {
		return id - ((Konto) obj).id;
	}
}
