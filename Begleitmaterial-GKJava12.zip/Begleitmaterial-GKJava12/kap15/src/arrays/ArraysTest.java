package arrays;

import java.util.Arrays;

public class ArraysTest {
	public static void main(String[] args) {
		int[] z = { 9, 8, 7, 6, 5, 4, 2, 1, 0 };
		Arrays.sort(z);
		System.out.println(Arrays.toString(z));

		int r = Arrays.binarySearch(z, 8);
		System.out.println(r);
		r = Arrays.binarySearch(z, 3);
		System.out.println(r);

		Konto k1 = new Konto(4711, 100);
		Konto k2 = new Konto(6000, 200);
		Konto k3 = new Konto(4044, 300);
		Konto k4 = new Konto(1234, 400);
		Konto[] konten = { k1, k2, k3, k4 };
		Arrays.sort(konten);
		System.out.println(Arrays.toString(konten));
	}
}
