package wrapper;

public class BoxingTest {
	public static void main(String[] args) {
		Integer integer = 1234; // boxing
		int i = integer; 		// unboxing

		IntegerBox box = new IntegerBox();
		box.setValue(4711);
		i = box.getValue();
		System.out.println(i);

		integer++;
		System.out.println(integer);
		integer += 10;
		System.out.println(integer);
	}
}
