package wrapper;

public class IntegerBox {
	private Integer value;

	public void setValue(Integer value) {
		this.value = value;
	}

	public Integer getValue() {
		return value;
	}
}