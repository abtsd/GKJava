package date_time;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class DateAndTime {
	public static void main(String[] args) {
		// Datum/Zeit festlegen
		LocalDate heute = LocalDate.now();
		System.out.println("Heute: " + heute);
		LocalDate geburtstag = LocalDate.of(2006, 12, 28);
		System.out.println("Geburtstag: " + geburtstag);
		LocalTime tagesschau = LocalTime.of(20, 0);
		System.out.println("Tagesschau: " + tagesschau);
		LocalDateTime klausur = LocalDateTime.of(2023, 1, 20, 11, 30);
		System.out.println("Klausur: " + klausur);
		System.out.println();

		// Datum/Zeit parsen
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		LocalDate d1 = LocalDate.parse("28.12.2006", dtf1);
		System.out.println("Datum: " + d1);
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
		LocalDateTime d2 = LocalDateTime.parse("202301201130", dtf2);
		System.out.println("Datum und Uhrzeit: " + d2);
		System.out.println();

		// Datum/Zeit formatiert ausgeben
		LocalDateTime jetzt = LocalDateTime.now();
		DateTimeFormatter dtf3 = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
		System.out.println(dtf3.format(jetzt));
		DateTimeFormatter dtf4 = DateTimeFormatter.ofPattern("d. MMMM yyyy");
		System.out.println(dtf4.format(jetzt));
		DateTimeFormatter dtf5 = DateTimeFormatter.ofPattern("d. MMMM yyyy")
				.withLocale(Locale.of("en", "US"));
		System.out.println(dtf5.format(jetzt));
		System.out.println();

		// Rechnen mit Datums- und Zeitwerten
		LocalDate in7Tagen = heute.plus(7, ChronoUnit.DAYS);
		System.out.println("In 7 Tagen: " + in7Tagen);
		LocalDate in3Monaten = heute.plus(3, ChronoUnit.MONTHS);
		System.out.println("In 3 Monaten: " + in3Monaten);
		LocalDate in1Jahr = heute.plus(1, ChronoUnit.YEARS);
		System.out.println("In 1 Jahr: " + in1Jahr);
		LocalDateTime in1Stunde = jetzt.plus(1, ChronoUnit.HOURS);
		System.out.println("In 1 Stunde: " + in1Stunde);
		LocalDateTime vor30Minuten = jetzt.minus(30, ChronoUnit.MINUTES);
		System.out.println("Vor 30 Minuten: " + vor30Minuten);
		System.out.println();

		// Zeitspannen ermitteln
		LocalDateTime beginn = LocalDateTime.of(2016, 1, 4, 12, 0, 0);
		LocalDateTime ende = LocalDateTime.of(2016, 1, 5, 10, 30, 10);
		Duration dauer = Duration.between(beginn, ende);
		System.out.println("Dauer: " + dauer);
		System.out.println("Dauer: " + dauer.toMinutes());
		LocalDateTime bestelltAm = LocalDateTime.of(2016, 1, 4, 0, 0);
		LocalDateTime geliefertAm = LocalDateTime.of(2016, 2, 3, 0, 0);
		Duration lieferZeit = Duration.between(bestelltAm, geliefertAm);
		System.out.println("Lieferzeit: " + lieferZeit.toDays());
		System.out.println();

		// Einzelne Elemente extrahieren
		LocalDateTime d3 = LocalDateTime.of(2016, 2, 4, 12, 30, 15);
		int jahr = d3.getYear();
		System.out.println("Jahr: " + jahr);
		Month monat = d3.getMonth();
		System.out.println("Monat: " + monat.getDisplayName(TextStyle.FULL, Locale.getDefault()) + " "
				+ monat.getValue());
		int anz = monat.length(d3.toLocalDate().isLeapYear());
		System.out.println("Anzahl Tage: " + anz);
		int tag = d3.getDayOfMonth();
		System.out.println("Tag: " + tag);
		DayOfWeek wochentag = d3.getDayOfWeek();
		System.out.println("Wochentag: " + wochentag.getDisplayName(TextStyle.FULL, Locale.getDefault()));
		int stunde = d3.getHour();
		System.out.println("Stunde: " + stunde);
		int minute = d3.getMinute();
		System.out.println("Minute: " + minute);
		int sekunde = d3.getSecond();
		System.out.println("Sekunde: " + sekunde);
		System.out.println();

		// Zeitzonen
		ZonedDateTime now = ZonedDateTime.now();
		System.out.println("Jetzt: " + now);
		ZoneId germanTimeZone = ZoneId.of("Europe/Berlin");
		ZonedDateTime nowInGermany = ZonedDateTime.now(germanTimeZone);
		System.out.println("Jetzt in Deutschland: " + nowInGermany);
		ZoneId newYorkTimeZone = ZoneId.of("America/New_York");
		ZonedDateTime nowInNewYork = ZonedDateTime.now(newYorkTimeZone);
		System.out.println("Jetzt in New York: " + nowInNewYork);
		LocalDateTime termin = LocalDateTime.of(2016, 2, 4, 12, 30, 15);
		ZonedDateTime terminInGermany = termin.atZone(germanTimeZone);
		System.out.println("Termin in Deutschland: " + terminInGermany);
		ZonedDateTime terminInNewYork = terminInGermany.withZoneSameInstant(newYorkTimeZone);
		System.out.println("Termin in New York: " + terminInNewYork);
		System.out.println();

		// Laufzeit messen
		Instant instant1 = Instant.now();
		double x = 0;
		for (int i = 0; i < 1_000_000; i++) {
			x += Math.sin(i) + Math.cos(i);
		}
		Instant instant2 = Instant.now();
		System.out.println("Wert: " + x);
		System.out.println("Laufzeit: " + Duration.between(instant1, instant2).toMillis());
	}
}
