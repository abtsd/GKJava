package date_time;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DatumTest {
	public static void main(String[] args) {
		SimpleDateFormat f1 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		SimpleDateFormat f2 = new SimpleDateFormat("dd.MM.yyyy");

		// aktuelles Rechnerdatum
		Date datum = new Date();
		System.out.println(f1.format(datum));

		// Datum in der Zeitzone America/New_York
		TimeZone tz = TimeZone.getTimeZone("America/New_York");
		GregorianCalendar cal1 = new GregorianCalendar(tz);
		cal1.setTime(datum);
		System.out.println("Zeitzone: " + tz.getID());
		System.out.println("Tag: " + cal1.get(Calendar.DATE));
		System.out.println("Monat: " + (cal1.get(Calendar.MONTH) + 1));
		System.out.println("Jahr: " + cal1.get(Calendar.YEAR));
		System.out.println("Stunde: " + cal1.get(Calendar.HOUR_OF_DAY));
		System.out.println("Minute: " + cal1.get(Calendar.MINUTE));
		System.out.println("Sekunde: " + cal1.get(Calendar.SECOND));

		// Datum auf den 1.1.2023 setzen
		GregorianCalendar cal2 = new GregorianCalendar();
		cal2.set(2023, 0, 1);
		System.out.println(f2.format(cal2.getTime()));

		// und 40 Tage dazu addieren
		cal2.add(Calendar.DATE, 40);
		System.out.println(f2.format(cal2.getTime()));
	}
}
