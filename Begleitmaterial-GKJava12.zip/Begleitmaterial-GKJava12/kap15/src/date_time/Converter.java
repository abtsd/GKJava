package date_time;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class Converter {
	public static LocalDate convertToLocalDate(Date date) {
		return LocalDate.ofInstant(date.toInstant(), ZoneId.systemDefault());
	}

	public static LocalDateTime convertToLocalDateTime(Date date) {
		return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
	}

	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(convertToLocalDate(date));
		System.out.println(convertToLocalDateTime(date));
	}
}
