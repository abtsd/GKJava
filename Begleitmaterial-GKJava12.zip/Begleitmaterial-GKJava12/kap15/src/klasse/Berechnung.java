package klasse;

public interface Berechnung {
	int berechne(int a, int b);
}
