package klasse;

public class ClassTest2 {
	public static void main(String[] args) throws ClassNotFoundException {
		Class aClass = Class.forName(args[0]);
		System.out.println(aClass.getName());

		Class superclass = aClass.getSuperclass();
		if (superclass != null)
			System.out.println("Superklasse: " + superclass.getName());

		Class[] interfaces = aClass.getInterfaces();
		if (interfaces.length > 0) {
			System.out.println("implementierte Interfaces:");
			for (Class anInterface : interfaces) {
				System.out.println("   " + anInterface.getName());
			}
		}
	}
}
