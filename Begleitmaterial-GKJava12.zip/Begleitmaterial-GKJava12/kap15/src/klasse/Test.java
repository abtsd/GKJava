package klasse;

public class Test {
	public static void main(String[] args) throws Exception {
		Class c = Class.forName(args[0]);
		Berechnung b = (Berechnung) c.getDeclaredConstructor().newInstance();
		System.out.println(b.berechne(10, 5));
	}
}
