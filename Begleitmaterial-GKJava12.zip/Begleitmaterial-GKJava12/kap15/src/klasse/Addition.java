package klasse;

public class Addition implements Berechnung {
	public int berechne(int a, int b) {
		return a + b;
	}
}
