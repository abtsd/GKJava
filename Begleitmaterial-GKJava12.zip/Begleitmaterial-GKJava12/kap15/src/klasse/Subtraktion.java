package klasse;

public class Subtraktion implements Berechnung {
	public int berechne(int a, int b) {
		return a - b;
	}
}
