package klasse;

public class ClassTest1 {
	public static void main(String[] args) throws ClassNotFoundException {
		System.out.println("".getClass().getName());
		System.out.println(String.class.getName());
		System.out.println(Class.forName("java.util.Vector").getName());
	}
}
