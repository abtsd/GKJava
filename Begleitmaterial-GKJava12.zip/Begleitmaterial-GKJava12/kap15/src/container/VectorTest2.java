package container;

import object.Kunde;

import java.util.Enumeration;
import java.util.Vector;

public class VectorTest2 {
	public static void main(String[] args) {
		Vector kunden = new Vector();

		kunden.add(new Kunde("Hugo Meier", "Hauptstr. 12, 40880 Ratingen"));
		kunden.add(new Kunde("Otto Schmitz", "Dorfstr. 5, 40880 Ratingen"));
		kunden.add(0, new Kunde("Willi Peters", "Hauptstr. 22, 40880 Ratingen"));

		Enumeration e = kunden.elements();
		while (e.hasMoreElements()) {
			Kunde k = (Kunde) e.nextElement();
			System.out.println(k.getName() + ", " + k.getAdresse());
		}
	}
}
