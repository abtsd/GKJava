package container;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class PropertiesTest2 {
	public static void main(String[] args) throws IOException {
		Properties p = new Properties();

		FileInputStream in = new FileInputStream("properties.xml");
		p.loadFromXML(in);
		in.close();

		Enumeration keys = p.propertyNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = p.getProperty(key);
			System.out.println(key + "=" + value);
		}

		p.put("Gewicht", "6.5");
		p.put("Farbe", "gelb");

		FileOutputStream out = new FileOutputStream("properties2.xml");
		p.storeToXML(out, "Beispiel Version 2");
		out.close();
	}
}
