package clone2;

public class Konto implements Cloneable {
	private int id;
	private double saldo;
	private Kunde kunde;

	public Konto() {
	}

	public Konto(int id, double saldo) {
		this.id = id;
		this.saldo = saldo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setKunde(Kunde kunde) {
		this.kunde = kunde;
	}

	public Kunde getKunde() {
		return kunde;
	}

	public void add(double betrag) {
		saldo += betrag;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Konto)) return false;
		return id == ((Konto) o).id;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public Konto clone() throws CloneNotSupportedException {
		Konto k = (Konto) super.clone();
		k.kunde = new Kunde(kunde);
		return k;
	}
}
