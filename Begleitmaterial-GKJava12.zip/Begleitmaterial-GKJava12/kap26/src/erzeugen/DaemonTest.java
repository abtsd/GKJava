package erzeugen;

public class DaemonTest extends Thread {
	@Override
	public void run() {
		System.out.println("Beginn run");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException ignored) {
		}
		System.out.println("Ende run");
	}

	public static void main(String[] args) throws InterruptedException {
		DaemonTest p = new DaemonTest();
		p.setDaemon(true);
		p.start();
		Thread.sleep(2000);
		System.out.println("Ende main");
	}
}
