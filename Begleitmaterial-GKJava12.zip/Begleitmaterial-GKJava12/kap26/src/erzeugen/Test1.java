package erzeugen;

public class Test1 extends Thread {
	@Override
	public void run() {
		String name = getName();

		for (int i = 0; i < 3; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ignored) {
			}

			System.out.println(name + ": " + i);
		}

		System.out.println(name + ": Ich bin fertig!");
	}

	public static void main(String[] args) {
		Test1 t1 = new Test1();
		Test1 t2 = new Test1();
		t1.start();
		t2.start();
		System.out.println("Habe zwei Threads gestartet.");
	}
}
