package erzeugen;

public class Test2 implements Runnable {
	@Override
	public void run() {
		String name = Thread.currentThread().getName();

		for (int i = 0; i < 3; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ignored) {
			}

			System.out.println(name + ": " + i);
		}

		System.out.println(name + ": Ich bin fertig!");
	}

	public static void main(String[] args) {
		Thread t1 = new Thread(new Test2());
		Thread t2 = new Thread(new Test2());
		t1.start();
		t2.start();
		System.out.println("Habe zwei Threads gestartet.");
	}
}
