package suspend;

import java.io.IOException;
import java.time.LocalTime;

public class StopAndGo extends Thread {
	private boolean stop;

	@Override
	public void run() {
		try {
			while (true) {
				synchronized (this) {
					while (stop)
						wait();
				}
				System.out.println(LocalTime.now());
				Thread.sleep(3000);
			}
		} catch (InterruptedException ignored) {
		}
	}

	public synchronized void doSuspend() {
		stop = true;
	}

	public synchronized void doResume() {
		stop = false;
		notify();
	}

	public static void main(String[] args) throws IOException {
		StopAndGo stopAndGo = new StopAndGo();
		stopAndGo.start();

		boolean run = true;
		while (run) {
			int b = System.in.read();
			switch (b) {
				case 's' -> stopAndGo.doSuspend(); // stoppen
				case 'e' -> { // beenden
					stopAndGo.interrupt();
					run = false;
				}
				case 'w' -> stopAndGo.doResume(); // weiter
			}
		}
	}
}
