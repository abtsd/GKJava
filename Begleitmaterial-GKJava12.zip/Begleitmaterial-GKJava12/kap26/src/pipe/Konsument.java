package pipe;

import java.io.EOFException;
import java.io.IOException;

public class Konsument extends Thread {
	private final Pipe pipe;

	public Konsument(Pipe p) {
		this.pipe = p;
	}

	@Override
	public void run() {
		try {
			int summe = 0;
			while (true) {
				int value = pipe.get();
				summe += value;
				System.out.println("\tKonsument: " + summe);
				Thread.sleep(3000);
			}
		} catch (InterruptedException | EOFException ignored) {
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
