package pipe;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class Pipe {
	private final DataOutputStream out;
	private final DataInputStream in;

	public Pipe() throws IOException {
		PipedOutputStream src = new PipedOutputStream();
		PipedInputStream snk = new PipedInputStream();
		src.connect(snk);
		out = new DataOutputStream(src);
		in = new DataInputStream(snk);
	}

	public void put(int value) throws IOException {
		out.writeInt(value);
	}

	public int get() throws IOException {
		return in.readInt();
	}

	public void close() throws IOException {
		out.close();
	}

	public static void main(String[] args) throws IOException {
		Pipe pipe = new Pipe();
		Produzent p = new Produzent(pipe);
		Konsument k = new Konsument(pipe);
		p.start();
		k.start();
	}
}
