package pipe;

import java.io.IOException;
import java.util.Random;

public class Produzent extends Thread {
	private final Pipe pipe;

	public Produzent(Pipe p) {
		this.pipe = p;
	}

	@Override
	public void run() {
		Random random = new Random();
		try {
			for (int i = 0; i < 5; i++) {
				System.out.println("Produzent: " + i);
				pipe.put(i);
				Thread.sleep(1000 + random.nextInt(2000));
			}
			pipe.close();
		} catch (InterruptedException ignored) {
		} catch (IOException e) {
			System.err.println(e);
		}
	}
}
