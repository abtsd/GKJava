package sync;

public class SyncTest extends Thread {
    private final Work w;

    public SyncTest(Work w) {
        this.w = w;
    }

    @Override
    public void run() {
        w.doWorkA(getName());
    }

    public static void main(String[] args) throws InterruptedException {
        Work w = new Work();
        SyncTest t1 = new SyncTest(w);
        SyncTest t2 = new SyncTest(w);
        SyncTest t3 = new SyncTest(w);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        t3.start();
        Work.doWorkB(Thread.currentThread().getName());
        Work.doWorkB(Thread.currentThread().getName());
    }
}
