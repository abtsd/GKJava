package sync;

public class DeadlockTest {
	private final Object a = new Object();
	private final Object b = new Object();

	public void f(String name) {
		System.out.println(name + " will a sperren");
		synchronized (a) {
			System.out.println(name + " a gesperrt");
			try {
				Thread.sleep(500);
			} catch (InterruptedException ignored) {
			}
			System.out.println(name + " will b sperren");
			synchronized (b) {
				System.out.println(name + " b gesperrt");
			}
		}
	}

	public void g(String name) {
		System.out.println(name + " will b sperren");
		synchronized (b) {
			System.out.println(name + " b gesperrt");
			System.out.println(name + " will a sperren");
			synchronized (a) {
				System.out.println(name + " a gesperrt");
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		final DeadlockTest test = new DeadlockTest();
		Thread t1 = new Thread(() -> test.f("Thread 1"));
		Thread t2 = new Thread(() -> test.g("Thread 2"));

		t1.start();
		Thread.sleep(200);
		t2.start();
	}
}
