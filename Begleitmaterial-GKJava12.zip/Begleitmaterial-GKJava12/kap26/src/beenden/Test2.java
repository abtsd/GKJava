package beenden;

import java.io.IOException;

public class Test2 implements Runnable {
	public void run() {
		try {
			while (!Thread.currentThread().isInterrupted()) {
				System.out.println(new java.util.Date());
				Thread.sleep(1000);
			}
		} catch (InterruptedException ignored) {
		}
	}

	public static void main(String[] args) throws IOException {
		Thread t = new Thread(new Test2());
		t.start();
		System.in.read(); // blockiert bis RETURN
		t.interrupt();
	}
}
