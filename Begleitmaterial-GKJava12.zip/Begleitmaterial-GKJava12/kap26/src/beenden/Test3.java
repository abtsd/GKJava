package beenden;

import java.io.IOException;

public class Test3 implements Runnable {
	private volatile boolean isStopped;

	public void start() {
		new Thread(this).start();
	}

	public void stop() {
		isStopped = true;
	}

	public void run() {
		while (!isStopped) {
			System.out.println(new java.util.Date());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ignored) {
			}
		}
	}

	public static void main(String[] args) throws IOException {
		Test3 test = new Test3();
		test.start();
		System.in.read();
		test.stop();
	}
}
