package beenden;

public class JoinTest extends Thread {
	@Override
	public void run() {
		System.out.println(getName() + ": Es geht los!");

		try {
			Thread.sleep(5000);
		} catch (InterruptedException ignored) {
		}

		System.out.println(getName() + ": Erledigt!");
	}

	public static void main(String[] args) throws InterruptedException {
		JoinTest t = new JoinTest();
		t.start();
		System.out.println("Auf das Ende warten ...");
		t.join();
		System.out.println("Endlich!");
	}
}
