package beenden;

import java.io.IOException;

public class Test1 implements Runnable {
	public void run() {
		while (true) {
			System.out.println(new java.util.Date());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				break;
			}
		}
	}

	public static void main(String[] args) throws IOException {
		Thread t = new Thread(new Test1());
		t.start();
		System.in.read(); // blockiert bis RETURN
		t.interrupt();
	}
}
