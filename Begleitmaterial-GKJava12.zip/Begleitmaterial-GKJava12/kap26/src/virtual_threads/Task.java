package virtual_threads;

import java.util.concurrent.Callable;

public class Task implements Callable<Integer> {
	private final int number;

	public Task(int number) {
		this.number = number;
	}

	@Override
	public Integer call() throws Exception {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			return 0;
		}
		return number;
	}
}
