package virtual_threads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Test1 {
	public static void main(String[] args) throws ExecutionException, InterruptedException {
		ExecutorService executor = Executors.newFixedThreadPool(100);
		long start = System.currentTimeMillis();

		List<Future<Integer>> futures = new ArrayList<>();
		for (int i = 0; i < 10_000; i++) {
			futures.add(executor.submit(new Task(i)));
		}

		long sum = 0;
		for (Future<Integer> future : futures) {
			sum += future.get();
		}

		long end = System.currentTimeMillis();
		System.out.println("sum = " + sum + ", time = " + (end - start) + " ms");
		executor.shutdown();
	}
}
