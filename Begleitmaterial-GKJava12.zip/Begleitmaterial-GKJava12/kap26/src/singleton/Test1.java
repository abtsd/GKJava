package singleton;

public class Test1 {
    public static void main(String[] args) {
        MySingleton1 singleton1 = MySingleton1.getInstance();
        System.out.println(singleton1.getValue());

        MySingleton1 singleton2 = MySingleton1.getInstance();
        System.out.println(singleton2.getValue());
    }
}
