package singleton;

public class MySingleton1 {
    private static MySingleton1 instance;
    private final double value;

    private MySingleton1() {
        value = Math.random();
    }

    public static synchronized MySingleton1 getInstance() {
        if (instance == null) {
            instance = new MySingleton1();
        }
        return instance;
    }

    public double getValue() {
        return value;
    }
}
