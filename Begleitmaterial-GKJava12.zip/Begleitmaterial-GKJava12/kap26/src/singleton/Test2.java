package singleton;

public class Test2 {
    public static void main(String[] args) {
        MySingleton2 singleton1 = MySingleton2.getInstance();
        System.out.println(singleton1.getValue());

        MySingleton2 singleton2 = MySingleton2.getInstance();
        System.out.println(singleton2.getValue());
    }
}
