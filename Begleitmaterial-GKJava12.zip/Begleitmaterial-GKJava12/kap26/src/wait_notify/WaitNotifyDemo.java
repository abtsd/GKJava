package wait_notify;

import java.io.IOException;

public class WaitNotifyDemo {
	private static final Object lock = new Object();
	private static boolean wait = true;

	public static void main(String[] args) {
		Thread waiter = new Thread(() -> {
			synchronized (lock) {
				while (wait) {
					System.out.println("Waiter: wait == " + wait);
					System.out.println("Waiter wartet");
					try {
						lock.wait();
					} catch (InterruptedException ignored) {
					}
				}
				System.out.println("Waiter: wait == " + wait);
			}
		});

		Thread notifier = new Thread(() -> {
			System.out.println("Notifier: Weiter mit RETURN");
			try {
				System.in.read();
			} catch (IOException ignored) {
			}
			synchronized (lock) {
				wait = false;
				lock.notify();
				System.out.println("Notifier: notify aufgerufen");
			}
		});

		waiter.start();
		notifier.start();
	}
}
