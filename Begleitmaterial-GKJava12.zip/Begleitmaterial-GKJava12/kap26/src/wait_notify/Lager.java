package wait_notify;

public class Lager {
	private int value;
	private boolean full;

	public synchronized void put(int value) throws InterruptedException {
		while (full) { // solange das Lager voll ist
			wait();
		}

		// Lager ist leer und wird gefüllt
		this.value = value;
		full = true;
		notify();
	}

	public synchronized int get() throws InterruptedException {
		while (!full) { // solange das Lager leer ist
			wait();
		}

		// Lager ist voll und wird geleert
		full = false;
		notify();
		return value;
	}

	public static void main(String[] args) {
		Lager lager = new Lager();
		Produzent p = new Produzent(lager);
		Konsument k = new Konsument(lager);
		p.start();
		k.start();
	}
}
