package wait_notify;

import java.util.Random;

public class Konsument extends Thread {
	private final Lager lager;

	public Konsument(Lager lager) {
		this.lager = lager;
	}

	public void run() {
		try {
			Random random = new Random();
			int i = 0;
			while (true) {
				int value = lager.get();
				if (value == -1)
					break;
				System.out.println("\t" + value + " aus Lager entfernt");
				Thread.sleep(1000 + random.nextInt(1000));
				System.out.println("\t" + value + " konsumiert");
			}
		} catch (InterruptedException ignored) {
		}
	}
}
