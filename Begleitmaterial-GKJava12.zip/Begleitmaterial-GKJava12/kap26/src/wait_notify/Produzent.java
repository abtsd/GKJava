package wait_notify;

import java.util.Random;

public class Produzent extends Thread {
    private static final int MAX = 5;
    private final Lager lager;

    public Produzent(Lager lager) {
        this.lager = lager;
    }

    @Override
    public void run() {
        try {
			Random random = new Random();
            for (int i = 0; i < MAX; i++) {
                System.out.println(i + " wird produziert");
                Thread.sleep(1000 + random.nextInt(4000));
                lager.put(i);
                System.out.println(i + " auf Lager");
            }
            lager.put(-1); // Produktion gestoppt
        } catch (InterruptedException ignored) {
        }
    }
}
