package collections;

public class ContextPerThread implements Runnable {
    private static final ThreadLocal<Context> ctx = new ThreadLocal<>();
    private static final UserRepository userRepository = new UserRepository();
    private final int id;

    public ContextPerThread(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        String user = userRepository.getUserById(id);
        ctx.set(new Context(user));
        System.out.println("Context für " + id + " ist " + ctx.get());
    }

    public static void main(String[] args) throws InterruptedException {
        ContextPerThread firstUser = new ContextPerThread(1);
        ContextPerThread secondUser = new ContextPerThread(2);

        new Thread(firstUser).start();
        new Thread(secondUser).start();
    }
}
