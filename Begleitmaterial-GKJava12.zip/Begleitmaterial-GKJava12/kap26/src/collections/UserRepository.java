package collections;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {
    private final Map<Integer, String> map = new HashMap<>();

    public UserRepository() {
        map.put(1, "Hugo");
        map.put(2, "Emil");
    }

    public String getUserById(int id) {
        return map.get(id);
    }
}
