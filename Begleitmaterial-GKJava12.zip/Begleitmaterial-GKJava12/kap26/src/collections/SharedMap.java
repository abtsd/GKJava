package collections;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SharedMap implements Runnable {
    private static final Map<Integer, Context> ctxMap = new ConcurrentHashMap<>();
    private static final UserRepository userRepository = new UserRepository();
    private final int id;

    public SharedMap(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        String user = userRepository.getUserById(id);
        ctxMap.put(id, new Context(user));
        System.out.println("Context für " + id + " ist " + ctxMap.get(id));
    }

    public static void main(String[] args) throws InterruptedException {
        SharedMap firstUser = new SharedMap(1);
        SharedMap secondUser = new SharedMap(2);

        new Thread(firstUser).start();
        new Thread(secondUser).start();
    }
}
