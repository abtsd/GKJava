package safe.good;

public class Account {
	private int balance;

	public synchronized void deposit(int amount) {
		balance += amount;
	}

	public static void main(String[] args) throws InterruptedException {
		Account konto = new Account();

		Runnable runnable = () -> {
			for (int i = 0; i < 10000; i++) {
				konto.deposit(1);
			}
		};

		Thread t1 = new Thread(runnable);
		Thread t2 = new Thread(runnable);
		t1.start();
		t2.start();

		t1.join();
		t2.join();

		System.out.println("Eingezahlt wurden insgesamt " + konto.balance + " Euro.");
	}
}
