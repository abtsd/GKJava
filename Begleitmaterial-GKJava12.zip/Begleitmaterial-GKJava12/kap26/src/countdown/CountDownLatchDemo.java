package countdown;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchDemo {
    public static void main(String[] args) throws InterruptedException {
        final int n = 3;
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(n);

        for (int i = 0; i < n; i++) {
            new Thread(new Worker("Worker " + i, start, done)).start();
        }

        System.out.println("BEGIN");
        start.countDown();
        done.await();
        System.out.println("END");
    }
}

class Worker implements Runnable {
    private final String name;
    private final CountDownLatch start;
    private final CountDownLatch done;

    Worker(String name, CountDownLatch start, CountDownLatch done) {
        this.name = name;
        this.start = start;
        this.done = done;
    }

    @Override
    public void run() {
        try {
            start.await();
            doWork();
            done.countDown();
        } catch (InterruptedException ignored) {
        }
    }

    void doWork() throws InterruptedException {
        Thread.sleep((1 + (int) (Math.random() * 5)) * 1000);
        System.out.println(name + " beendet");
    }
}
