package sum;

public class SimpleSum {
	private long sum;

	public static void main(String[] args) {
		new SimpleSum().sum();
	}

	public void sum() {
		long startTime = System.currentTimeMillis();
		for (long n = 0; n < 1_000_000_000; n++) {
			sum += n;
		}
		long time = System.currentTimeMillis() - startTime;
		System.out.println("Sum: " + sum);
		System.out.println("Time: " + time);
	}
}
