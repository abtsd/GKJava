package sum;

public class ConcurrentSum {
	private long sum;
	private final Thread[] threads = new Thread[4];

	public static void main(String[] args) {
		new ConcurrentSum().sum();
	}

	private void sum() {
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < 4; i++) {
			final long start = i * (1_000_000_000 / 4);
			final long end = (i + 1) * (1_000_000_000 / 4);
			threads[i] = new Thread(() -> {
				long threadSum = 0;
				for (long n = start; n < end; n++) {
					threadSum += n;
				}
				synchronized (ConcurrentSum.this) {
					sum += threadSum;
				}
			});
			threads[i].start();
		}

		for (int i = 0; i < 4; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException ignored) {
			}
		}

		long time = System.currentTimeMillis() - startTime;
		System.out.println("Sum: " + sum);
		System.out.println("Time: " + time);
	}
}
