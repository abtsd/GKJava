package async;

import java.util.concurrent.CompletableFuture;

public class CompletableFutureDemo1 {
	public static void main(String[] args) {
		System.out.println("Variante 1");
		CompletableFuture<Integer> f1 = CompletableFuture.supplyAsync(() -> 1);
		CompletableFuture<Integer> f2 = f1.thenApplyAsync(x -> x + 2);
		CompletableFuture<Integer> f3 = f2.thenApplyAsync(x -> x + 3);
		CompletableFuture<Void> f4 = f3.thenAcceptAsync(System.out::println);
		f4.join();

		System.out.println("Variante 2");
		CompletableFuture.supplyAsync(() -> 1)
				.thenApplyAsync(x -> x + 2)
				.thenApplyAsync(x -> x + 3)
				.thenAcceptAsync(System.out::println)
				.join();
		System.out.println("Ende");
	}
}
