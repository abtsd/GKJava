package async;

import java.util.concurrent.CompletableFuture;

public class CompletableFutureDemo2 {
	public static void main(String[] args) {
		CompletableFuture<Integer> f1 = CompletableFuture.supplyAsync(() -> 1);
		CompletableFuture<Integer> f2 = f1.thenApplyAsync(x -> x + 2);
		CompletableFuture<Integer> f3 = f1.thenApplyAsync(x -> x + 3);
		CompletableFuture<Integer> f4 = f2.thenCombine(f3, (a, b) -> a * b);
		System.out.println(f4.join());
	}
}
