package async;

import java.util.concurrent.CompletableFuture;

public class CompletableFutureDemo3 {
	public static void main(String[] args) {
		CompletableFuture<Void> f1 = CompletableFuture.supplyAsync(() -> 1)
				.thenAcceptAsync(System.out::println);
		CompletableFuture<Void> f2 = CompletableFuture.supplyAsync(() -> 2)
				.thenAcceptAsync(System.out::println);
		CompletableFuture.allOf(f1, f2).join();
		System.out.println("Ende");
	}
}
