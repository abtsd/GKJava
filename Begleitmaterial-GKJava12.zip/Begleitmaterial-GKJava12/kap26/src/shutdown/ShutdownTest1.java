package shutdown;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ShutdownTest1 {
	private final BufferedWriter log;

	public ShutdownTest1() throws IOException {
		log = new BufferedWriter(new FileWriter("log.txt"));
	}

	public void process() throws IOException {
		log.write("Das ist ein Test.");
		log.newLine();
		try {
			Thread.sleep(60000);
		} catch (InterruptedException ignored) {
		}
	}

	public void close() throws IOException {
		log.close();
	}

	public static void main(String[] args) throws IOException {
		ShutdownTest1 test = new ShutdownTest1();
		test.process();
		test.close();
	}
}
