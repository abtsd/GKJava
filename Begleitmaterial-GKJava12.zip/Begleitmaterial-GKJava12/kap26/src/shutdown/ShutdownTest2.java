package shutdown;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ShutdownTest2 {
	private final BufferedWriter log;

	public ShutdownTest2() throws IOException {
		log = new BufferedWriter(new FileWriter("log.txt"));

		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				close();
			} catch (IOException ignored) {
			}
		}));
	}

	public void process() throws IOException {
		log.write("Das ist ein Test.");
		log.newLine();
		try {
			Thread.sleep(60000);
		} catch (InterruptedException ignored) {
		}
	}

	public void close() throws IOException {
		log.close();
	}

	public static void main(String[] args) throws IOException {
		ShutdownTest2 test = new ShutdownTest2();
		test.process();
	}
}
