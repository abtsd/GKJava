package threadpool;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SubmitRunnable3 {
	public static void main(String[] args) throws InterruptedException {
		ExecutorService service = Executors.newCachedThreadPool();

		Future<?> future = service.submit(() -> System.out.println(1 / 0));
		try {
			future.get();
		} catch (InterruptedException | ExecutionException e) {
			System.out.println(e.getMessage());
		}

		service.shutdown();
	}
}
