package threadpool;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SubmitCallable {
	public static void main(String[] args) {
		ExecutorService service = Executors.newCachedThreadPool();

		Future<Integer> future = service.submit(() -> 42);
		try {
			int result = future.get();
			System.out.println(result);
		} catch (InterruptedException | ExecutionException ignored) {
		}

		service.shutdown();
	}
}
