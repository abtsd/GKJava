package threadpool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecuteRunnable {
	public static void main(String[] args) {
		ExecutorService service = Executors.newFixedThreadPool(3);

		for (int i = 0; i < 3; i++) {
			final int n = i;
			service.execute(() -> {
				String name = Thread.currentThread().getName();
				System.out.println(n + ": " + name);
			});
		}

		service.shutdown();
	}
}
