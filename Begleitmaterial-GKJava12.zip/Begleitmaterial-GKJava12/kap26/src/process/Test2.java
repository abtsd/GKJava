package process;

import java.util.Optional;

public class Test2 {
	public static void main(String[] args) throws Exception {
		String name = "xed";
		Optional<ProcessHandle> opt = Util.findProcessByName(name);
		if (opt.isPresent()) {
			ProcessHandle handle = opt.get();
			System.out.println("Warte auf Beendigung von " + name + " ...");
			handle.onExit().join();
			System.out.println("Prozess " + handle.pid() + " wurde beendet.");
		} else {
			System.out.println("Prozess existiert nicht.");
		}
	}
}
