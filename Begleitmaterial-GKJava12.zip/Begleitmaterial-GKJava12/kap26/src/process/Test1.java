package process;

import java.util.Optional;

public class Test1 {
	public static void main(String[] args) {
		String name = "xed";
		Optional<ProcessHandle> opt = Util.findProcessByName(name);
		if (opt.isPresent()) {
			ProcessHandle handle = opt.get();
			handle.destroy();
			handle.onExit()
					.thenAccept(h -> System.out.println("Prozess " + h.pid() + " wurde beendet."))
					.join();
		} else {
			System.out.println("Prozess existiert nicht.");
		}
	}
}
