package process;

import java.util.Optional;

public class Util {
	public static Optional<ProcessHandle> findProcessByName(String name) {
		return ProcessHandle.allProcesses()
				.filter(h -> {
					Optional<String> opt = h.info().command();
					return opt.isPresent() && opt.get().endsWith(name);
				})
				.findFirst();
	}
}
