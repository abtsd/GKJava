public class Formatieren {
	public static void main(String[] args) {
		String f = "Der Artikel %s kosten %.2f €.";
		String aus1 = String.format(f, "A4711", 7.5);
		System.out.println(aus1);
		String aus2 = f.formatted("A4711", 7.5);
		System.out.println(aus2);
	}
}
