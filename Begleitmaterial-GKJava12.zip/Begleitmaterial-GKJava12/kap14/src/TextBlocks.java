public class TextBlocks {
	public static void main(String[] args) {
		System.out.println("""
				1) Guten Tag.
				Auf Wiedersehen.
			"""
		);

		System.out.println("""
			2) Guten Tag.
			Auf Wiedersehen."""
		);

		System.out.println("""
			3) "Guten Tag."
			Auf Wiedersehen."""
		);

		System.out.println("""
			4) Guten Tag. \
			Auf Wiedersehen."""
		);

		System.out.println("""
			5) Guten Tag.     \s
			Auf Wiedersehen."""
		);
	}
}
