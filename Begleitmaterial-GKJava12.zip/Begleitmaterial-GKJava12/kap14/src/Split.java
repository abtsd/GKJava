import java.util.Arrays;

public class Split {
	public static void main(String[] args) {
		String data = "Hugo Meier;12345;Musterdorf";
		String[] words = data.split(";");
		System.out.println(Arrays.toString(words));
		String str = String.join(";", words);
		System.out.println(str);
	}
}
