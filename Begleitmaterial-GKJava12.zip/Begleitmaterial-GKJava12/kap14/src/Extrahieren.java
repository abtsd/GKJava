public class Extrahieren {
	public static void main(String[] args) {
		String a = "Schmitz, Hugo";
		String b = "\n\t Hallo\b   ";
		System.out.println(a.substring(0, a.indexOf(",")));
		System.out.println(b.trim().length());
		System.out.println(b.strip().length());
		System.out.println("#" + b.trim() + "#");
		System.out.println("#" + b.strip() + "#");
	}
}
