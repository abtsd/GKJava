public class Ersetzen {
	public static void main(String[] args) {
		String a = "4711,Hammer,20";
		String b = a.replace(',', ';');
		System.out.println(b);
		System.out.println(b.toUpperCase());
	}
}
