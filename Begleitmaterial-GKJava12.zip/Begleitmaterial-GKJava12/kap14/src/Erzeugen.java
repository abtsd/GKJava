public class Erzeugen {
	public static void main(String[] args) {
		String a = "Hallo";
		String b = "Hallo";
		String c = new String(a);
		String d = new String(new char[]{'H', 'a', 'l', 'l', 'o'});
		String e = a.concat(" ").concat("Welt");
		String f = a + " " + "Welt";
		int preis = 5;
		String g = "Dieser Artikel kostet " + preis + " Euro.";
		String h = "*".repeat(10);

		System.out.println(a == b);
		System.out.println(a == c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(f.length());
		System.out.println(g);
		System.out.println(h);
	}
}
