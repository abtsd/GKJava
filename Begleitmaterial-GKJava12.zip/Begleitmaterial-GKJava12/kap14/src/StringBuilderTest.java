public class StringBuilderTest {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Ich")
				.append("was soll es bedeuten ...")
				.insert(3, " weiß nicht, ");
		System.out.println(sb);
	}
}
