public class Suchen {
	public static void main(String[] args) {
		String str = "Das ist ein Test.";
		int idx = str.indexOf(" ");
		System.out.println(idx);
		System.out.println(str.indexOf(" ", idx + 1));
		System.out.println(str.lastIndexOf(" "));
		System.out.println(str.contains("ist"));
	}
}
