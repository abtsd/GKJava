import java.util.Arrays;

public class Konvertieren {
	public static void main(String[] args) {
		String a = String.valueOf(3.57);
		byte[] bytes = "Hallo".getBytes();
		char[] chars = "Hallo".toCharArray();
		System.out.println(a.replace('.', ','));
		System.out.println(Arrays.toString(bytes));
		System.out.println(Arrays.toString(chars));
	}
}
