public class Vergleichen {
	public static void main(String[] args) {
		String a = "Hallo";
		String b = "Hallo";
		String c = "Das ist ein Test";
		String d = "\n\t ";

		System.out.println(a.equals(b));
		System.out.println(c.startsWith("Das") && c.endsWith("Test"));
		System.out.println("a".compareTo("b"));
		System.out.println(d.isBlank());
	}
}
