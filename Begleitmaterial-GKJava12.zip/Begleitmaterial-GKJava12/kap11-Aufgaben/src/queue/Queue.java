package queue;

public class Queue {
	private Node head;
	private Node tail;

	public void enter(int x) {
		Node p = new Node();
		p.data = x;

		if (head == null)
			head = p;
		else
			tail.next = p;

		tail = p;
	}

	public int leave() {
		if (head == null)
			return -1;
		Node p = head;
		head = head.next;
		return p.data;
	}

	private static class Node {
		int data;
		Node next;
	}
}
