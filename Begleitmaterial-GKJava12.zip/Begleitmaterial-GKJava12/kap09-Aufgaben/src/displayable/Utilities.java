package displayable;

public class Utilities {
	private static int counter;

	public static void display(Displayable a) {
		System.out.println("LFD. NR.: " + ++counter);
		a.display();
		System.out.println();
	}
}
