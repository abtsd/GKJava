package displayable;

public interface Displayable {
	void display();
}
