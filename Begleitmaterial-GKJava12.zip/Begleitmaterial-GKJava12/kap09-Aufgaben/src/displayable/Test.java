package displayable;

public class Test {
	public static void main(String[] args) {
		Sparbuch sb1 = new Sparbuch(4711, 5000, 2.5);
		Utilities.display(sb1);

		Sparbuch sb2 = new Sparbuch(1234, 1500, 2.5);
		Utilities.display(sb2);
	}
}
