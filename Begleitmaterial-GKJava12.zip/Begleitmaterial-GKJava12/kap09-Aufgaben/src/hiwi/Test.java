package hiwi;

public class Test {
	public static void main(String[] args) {
		HiWi h = new HiWi();

		h.setName("Hugo Meier");
		h.setMatrNr(123456);
		h.setGehalt(400.);
		h.setDauer(12);

		System.out.println(h);

		System.out.println(((Student) h).getName());
		System.out.println(((Student) h).getMatrNr());
	}
}
