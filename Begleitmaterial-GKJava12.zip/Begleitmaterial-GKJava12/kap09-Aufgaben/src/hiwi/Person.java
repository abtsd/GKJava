package hiwi;

public interface Person {
	String getName();

	void setName(String name);
}
