package hiwi;

public interface Student extends Person {
	int getMatrNr();

	void setMatrNr(int matrNr);
}
