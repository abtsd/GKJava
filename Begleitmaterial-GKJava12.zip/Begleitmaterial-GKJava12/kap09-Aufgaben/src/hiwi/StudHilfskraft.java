package hiwi;

public interface StudHilfskraft extends Angestellter, Student {
	int getDauer();

	void setDauer(int dauer);
}
