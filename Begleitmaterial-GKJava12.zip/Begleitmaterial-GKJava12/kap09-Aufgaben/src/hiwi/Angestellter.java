package hiwi;

public interface Angestellter extends Person {
	double getGehalt();

	void setGehalt(double gehalt);
}
