package list;

public class Test {
	public static void main(String[] args) {
		IntegerList integerList = new ArrayIntegerList(100);
		integerList.insertLast(10);
		integerList.insertLast(2);
		integerList.insertLast(22);
		integerList.insertLast(13);

		System.out.println(integerList.getLength());
		System.out.println(integerList.getFirst());

		integerList.deleteFirst();

		System.out.println(integerList.getLength());
		System.out.println(integerList.getFirst());

		System.out.println(integerList.search(22));
	}
}
