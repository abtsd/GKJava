package obst;

public class Orange implements Obst {
	public String getName() {
		return "Orange";
	}

	public String getFarbe() {
		return "orange";
	}
}
