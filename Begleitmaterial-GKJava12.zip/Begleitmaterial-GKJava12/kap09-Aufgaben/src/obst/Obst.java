package obst;

public interface Obst {
	String getName();

	String getFarbe();
}
