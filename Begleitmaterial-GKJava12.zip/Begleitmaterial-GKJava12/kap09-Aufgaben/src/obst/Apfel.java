package obst;

public class Apfel implements Obst {
	public String getName() {
		return "Apfel";
	}

	public String getFarbe() {
		return "grün";
	}
}
