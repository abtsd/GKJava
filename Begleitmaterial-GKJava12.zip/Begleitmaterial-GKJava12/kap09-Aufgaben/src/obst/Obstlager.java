package obst;

public class Obstlager {
	private final Obst[] lager = { new Orange(), new Birne(), new Apfel() };

	public void print() {
		for (Obst obst : lager) {
			System.out.println(obst.getName() + " " + obst.getFarbe());
		}
	}

	public static void main(String[] args) {
		Obstlager obstlager = new Obstlager();
		obstlager.print();
	}
}
