package obst;

public class Birne implements Obst {
	public String getName() {
		return "Birne";
	}

	public String getFarbe() {
		return "gelb";
	}
}
