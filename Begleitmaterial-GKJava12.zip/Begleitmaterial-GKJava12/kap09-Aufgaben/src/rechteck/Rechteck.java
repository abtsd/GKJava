package rechteck;

public interface Rechteck {
	int getBreite();

	int getHoehe();

	default boolean isQuadrat() {
		return getBreite() == getHoehe();
	}

	static int compare(Rechteck a, Rechteck b) {
		int fa = a.getBreite() * a.getHoehe();
		int fb = b.getBreite() * b.getHoehe();
		if (fa < fb)
			return -1;
		else if (fa == fb)
			return 0;
		else
			return 1;
	}
}