package rechteck;

public class MeinRechteck implements Rechteck {
    private final int breite;
    private final int hoehe;
    
    public MeinRechteck(int b, int h) {
        breite = b;
        hoehe = h;
    }
    
    public int getBreite() {
        return breite;
    }
    
    public int getHoehe() {
        return hoehe;
    }
}