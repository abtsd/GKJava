package rechteck;

public class Test {
    public static void main(String[] args) {
        MeinRechteck r1 = new MeinRechteck(2, 3);
        MeinRechteck r2 = new MeinRechteck(3, 2);
        MeinRechteck r3 = new MeinRechteck(3, 3);
        
        System.out.println(r1.isQuadrat());
        System.out.println(r2.isQuadrat());
        System.out.println(r3.isQuadrat());
        
        System.out.println(Rechteck.compare(r1, r2));
        System.out.println(Rechteck.compare(r1, r3));
    }
}
