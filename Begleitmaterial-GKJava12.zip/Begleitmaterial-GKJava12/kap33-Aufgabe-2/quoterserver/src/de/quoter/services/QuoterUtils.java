package de.quoter.services;

import java.util.logging.Logger;

public class QuoterUtils {
	private static final Logger LOGGER;

	static {
		System.setProperty("java.util.logging.config.file", "logging.properties");
		LOGGER = Logger.getLogger(QuoterUtils.class.getName());
	}

	public String quote(String text) {
		LOGGER.info("quote wird aufgerufen");
		return "\"" + text + "\"";
	}
}
