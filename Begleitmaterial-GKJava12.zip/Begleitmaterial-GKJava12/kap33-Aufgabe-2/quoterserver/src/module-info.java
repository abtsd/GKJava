module quoterserver {
    requires java.logging;
    exports de.quoter.services;
}