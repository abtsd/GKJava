import de.example.utils.Datum;
import de.example.utils.Kalender;

public class Test {
	public static void main(String[] args) {
		int jahr = 2024;

		System.out.println(Kalender.schaltjahr(jahr));

		for (int m = 1; m <= 12; m++) {
			System.out.println("Jahr: " + jahr + ", Monat: " + m + ", Anzahl Tage: " +
					Kalender.tage(jahr, m));
		}

		Datum datum = new Datum(29, 2, 2024);
		System.out.println(datum.display());
	}
}
