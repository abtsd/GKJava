package de.example.utils;

public class Datum {
	private final int tag;
	private final int monat;
	private final int jahr;

	public Datum(int tag, int monat, int jahr) {
		this.tag = tag;
		this.monat = monat;
		this.jahr = jahr;
	}

	public String display() {
		int t = Kalender.tage(jahr, monat);
		if (t == 0 || tag < 1 || tag > t)
			return "Ungültiges Datum";
		return tag + "." + monat + "." + jahr;
	}
}
