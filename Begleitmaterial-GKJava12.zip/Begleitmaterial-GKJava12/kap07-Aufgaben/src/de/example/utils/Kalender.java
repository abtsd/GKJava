package de.example.utils;

public class Kalender {
	public static boolean schaltjahr(int jahr) {
		return jahr % 4 == 0 && (jahr % 100 != 0 || jahr % 400 == 0);
	}

	public static int tage(int jahr, int monat) {
		if (!(monat > 0 && monat <= 12))
			return 0;

		switch (monat) {
			case 4, 6, 9, 11 -> {
				return 30;
			}
			case 2 -> {
				return schaltjahr(jahr) ? 29 : 28;
			}
			default -> {
				return 31;
			}
		}
	}
}
