jar --create --file kalendar.jar -C out/production/kap07-Aufgaben de/example/utils
java -cp out/production/kap07-Aufgaben:kalender.jar Test
