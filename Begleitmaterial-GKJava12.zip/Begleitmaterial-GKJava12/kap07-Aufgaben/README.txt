jar --create --file kalender.jar -C out/production/kap07-Aufgaben de/example/utils
java -cp out/production/kap07-Aufgaben:kalender.jar Test
