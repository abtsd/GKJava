public class Schaltjahr {
	public static void main(String[] args) {
		int jahr = 2024;
		boolean schaltjahr;

		if (jahr % 4 == 0 && (jahr % 100 != 0 || jahr % 400 == 0))
			schaltjahr = true;
		else
			schaltjahr = false;

		if (schaltjahr)
			System.out.println(jahr + " ist ein Schaltjahr.");
		else
			System.out.println(jahr + " ist kein Schaltjahr.");
	}
}
