public class Primfaktoren {
	public static void main(String[] args) {
		int n = 18844;
		int t = 2;

		while (n > 1) {
			if (n % t == 0) {
				n = n / t;
				System.out.print(t + " ");
			} else {
				t++;
			}
		}
		System.out.println();
	}
}
