public class Quersumme {
	public static void main(String[] args) {
		int x = 12389;
		
		int quersumme = 0;
		while (x > 0) {
			quersumme = quersumme + x % 10;
			x = x / 10;
		}
		
		System.out.println("Quersumme: " + quersumme);
	}
}
