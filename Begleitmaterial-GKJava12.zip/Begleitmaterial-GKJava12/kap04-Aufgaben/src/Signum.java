public class Signum {
	public static void main(String[] args) {
		double x = 1.23;
		double y = 1.234;
		double z = 0.01;
		
		double abs = (x - y < 0) ? y - x : x - y;
		
		if (abs < z)
			System.out.println(0);
		else if (x < y)
			System.out.println(-1);
		else
			System.out.println(1);
	}
}
