public class Schritte {
	public static void main(String[] args) {
		double start = 0;
		double end = 100;
		int anzahlSchritte = 5;

		double delta = (end - start) / (anzahlSchritte - 1);

		double x;
		for (int n = 0; n < anzahlSchritte; n++) {
			x = start + delta * n;
			System.out.println(x);
		}
	}
}
