public class Fakultaet {
	public static void main(String[] args) {
		int n = 20; // Überlauf, wenn n > 20
//		int n = 170; // Infinity, wenn n > 170

		long fak = 1;
//		double fak = 1;
		for (int i = 1; i <= n; i++) {
			fak *= i;
		}

		System.out.println(fak);
	}
}
