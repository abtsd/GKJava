public class Log {
	public static void main(String[] args) {
		int x = 15;
		int n = 0;
		for (int z = 1; z < x; n++) {
			z *= 2;
		}
		System.out.println(n);
	}
}
