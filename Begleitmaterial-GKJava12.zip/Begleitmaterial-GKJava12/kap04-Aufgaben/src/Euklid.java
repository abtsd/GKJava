public class Euklid {
	public static void main(String[] args) {
		int p = 216;
		int q = 378;

		if (p < q) {
			int h = p;
			p = q;
			q = h;
		}

		int r;
		while (q != 0) {
			r = p % q;
			p = q;
			q = r;
		}

		System.out.println(p);
	}
}
