public class Jahreszeit {
	public static void main(String[] args) {
		int monat = 3;

		String jahreszeit = switch (monat) {
			case 3, 4, 5 -> "Frühling";
			case 6, 7, 8 -> "Sommer";
			case 9, 10, 11 -> "Herbst";
			case 12, 1, 2 -> "Winter";
			default -> "Unbekannt";
		};

		System.out.println("Jahreszeit: " + jahreszeit);
	}
}
