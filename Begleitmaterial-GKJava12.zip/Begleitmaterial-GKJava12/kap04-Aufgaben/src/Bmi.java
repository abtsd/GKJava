public class Bmi {
	public static void main(String[] args) {
		double weight = 56.;
		double height = 1.7;

		double bmi = weight / (height * height);

		String text = "";
		if (bmi < 18.5) {
			text = "Untergewicht: " + bmi;
		} else if ((bmi >= 18.5) && (bmi < 25)) {
			text = "Normalgewicht: " + bmi;
		} else if ((bmi >= 25) && (bmi < 30)) {
			text = "Übergewicht: " + bmi;
		} else if (bmi >= 30) {
			text = "Adipositas: " + bmi;
		}

		System.out.println(text);
	}
}
