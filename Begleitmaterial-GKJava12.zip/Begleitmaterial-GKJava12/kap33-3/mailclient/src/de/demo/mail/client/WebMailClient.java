package de.demo.mail.client;

import de.demo.mail.MailSender;
import de.demo.mail.web.WebMailSenderFactory;

public class WebMailClient {
	public static void main(String[] args) {
		MailSender mailSender = WebMailSenderFactory.create();
		boolean ok = mailSender.sendMail("hugo.meier@abc.de", "Das ist ein Test.");
		if (ok) {
			System.out.println("Mail wurde versandt.");
		} else {
			System.out.println("Fehler beim Senden.");
		}
	}
}
