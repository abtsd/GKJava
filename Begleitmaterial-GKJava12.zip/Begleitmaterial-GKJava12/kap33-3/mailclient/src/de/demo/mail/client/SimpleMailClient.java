package de.demo.mail.client;

import de.demo.mail.MailSender;
import de.demo.mail.simple.SimpleMailSenderFactory;

public class SimpleMailClient {
	public static void main(String[] args) {
		MailSender mailSender = SimpleMailSenderFactory.create();
		boolean ok = mailSender.sendMail("hugo.meier@abc.de", "Das ist ein Test.");
		if (ok) {
			System.out.println("Mail wurde versandt.");
		} else {
			System.out.println("Fehler beim Senden.");
		}
	}
}
