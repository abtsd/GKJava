module mailclient {
    requires mailapi;
    requires simplemail;
    requires webmail;
}