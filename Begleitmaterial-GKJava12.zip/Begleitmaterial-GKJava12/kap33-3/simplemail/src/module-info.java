module simplemail {
    requires mailapi;
    exports de.demo.mail.simple;
}