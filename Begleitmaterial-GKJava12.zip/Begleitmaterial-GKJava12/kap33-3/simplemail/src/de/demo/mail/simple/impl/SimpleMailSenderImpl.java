package de.demo.mail.simple.impl;

import de.demo.mail.MailSender;

public class SimpleMailSenderImpl implements MailSender {
	@Override
	public boolean sendMail(String to, String text) {
		System.out.println("SimpleMail an " + to + ":\n" + text);
		return true;
	}
}
