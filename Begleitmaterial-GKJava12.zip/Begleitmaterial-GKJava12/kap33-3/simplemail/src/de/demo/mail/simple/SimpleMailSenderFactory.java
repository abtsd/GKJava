package de.demo.mail.simple;

import de.demo.mail.MailSender;
import de.demo.mail.simple.impl.SimpleMailSenderImpl;

public class SimpleMailSenderFactory {
	public static MailSender create() {
		return new SimpleMailSenderImpl();
	}
}
