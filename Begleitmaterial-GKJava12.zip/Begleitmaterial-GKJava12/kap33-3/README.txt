# Übersetzen
javac -d out/production/mailapi mailapi/src/*.java \
mailapi/src/de/demo/mail/*.java

javac -d out/production/simplemail -p out/production \
simplemail/src/*.java simplemail/src/de/demo/mail/simple/*.java \
simplemail/src/de/demo/mail/simple/impl/*.java

javac -d out/production/webmail -p out/production \
webmail/src/*.java webmail/src/de/demo/mail/web/*.java \
webmail/src/de/demo/mail/web/impl/*.java

javac -d out/production/mailclient -p out/production \
mailclient/src/*.java mailclient/src/de/demo/mail/client/*.java

# Ausführen
java -p out/production -m mailclient/de.demo.mail.client.SimpleMailClient
java -p out/production -m mailclient/de.demo.mail.client.WebMailClient

# JARs erzeugen
mkdir lib
jar --create --file lib/mailclient.jar -C out/production/mailclient .
jar --create --file lib/mailapi.jar -C out/production/mailapi .
jar --create --file lib/simplemail.jar -C out/production/simplemail .
jar --create --file lib/webmail.jar -C out/production/webmail .

# und ausführen
java -p lib -m mailclient/de.demo.mail.client.SimpleMailClient
java -p lib -m mailclient/de.demo.mail.client.WebMailClient

# Abhängigkeiten analysieren
mkdir graphs
jdeps -s lib/*.jar
jdeps -s -dotoutput graphs lib/*.jar
dot -Tpng -Gdpi=300 graphs/summary.dot -O
