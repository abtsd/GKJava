package de.demo.mail.web;

import de.demo.mail.MailSender;
import de.demo.mail.web.impl.WebMailSenderImpl;

public class WebMailSenderFactory {
	public static MailSender create() {
		return new WebMailSenderImpl();
	}
}
