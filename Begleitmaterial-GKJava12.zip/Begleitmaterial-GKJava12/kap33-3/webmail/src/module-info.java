module webmail {
    requires mailapi;
    exports de.demo.mail.web;
}