package print;

public class Test {
	public static void main(String[] args) {
		Pair<String, Integer> p1 = new Pair<>("Hallo", 1);
		print(p1);

		Pair<String, Pair<String, Integer>> p2 = new Pair<>("Hi", p1);
		print(p2);
	}

	public static void print(Pair<?, ?> p) {
		System.out.println("(" + p.getA() + ", " + p.getB() + ")");
	}
}
