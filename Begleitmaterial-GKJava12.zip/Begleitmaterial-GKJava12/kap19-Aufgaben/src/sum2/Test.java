package sum2;

import java.math.BigInteger;

public class Test {
	public static void main(String[] args) {
		Pair<Integer, Double> z1 = new Pair<>(12, 1.23);
		System.out.println(sum(z1));

		BigInteger big = new BigInteger("99999999999999999999");
		Pair<BigInteger, Double> z2 = new Pair<>(big, 1.);
		System.out.println(sum(z2));
	}

	public static <U extends Number, V extends Number> double sum(Pair<U, V> p) {
		return p.getA().doubleValue() + p.getB().doubleValue();
	}
}
