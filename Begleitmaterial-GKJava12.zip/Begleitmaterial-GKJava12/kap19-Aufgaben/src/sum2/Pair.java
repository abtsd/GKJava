package sum2;

public class Pair<T, U> {
	protected T a;
	protected U b;

	public Pair(T a, U b) {
		this.a = a;
		this.b = b;
	}

	public T getA() {
		return a;
	}

	public U getB() {
		return b;
	}

	public String toString() {
		return "(" + a + ", " + b + ")";
	}
}
