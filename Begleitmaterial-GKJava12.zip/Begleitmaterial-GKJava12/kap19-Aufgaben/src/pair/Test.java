package pair;

public class Test {
	public static void main(String[] args) {
		Pair<String, Integer> p1 = new Pair<>("Hallo", 1);
		String a = p1.getA();
		int b = p1.getB();
		System.out.println(a);
		System.out.println(b);
		System.out.println(p1);

		Pair<String, Pair<String, Integer>> p2 = new Pair<>("Hi", p1);
		a = p2.getA();
		p1 = p2.getB();
		System.out.println(a);
		System.out.println(p1);
		System.out.println(p2);
	}
}
