package pair2;

import java.util.List;

public record Pair<A, B>(A first, B second) {
    @Override
    public String toString() {
        return "(" + first + ", " + second + ")";
    }

    public static <X, Y> Pair<X, Y> of(X x, Y y) {
        return new Pair<>(x, y);
    }

    public static <T> Pair<T, T> fromList(List<? extends T> list) {
        return new Pair<T, T>(list.get(0), list.get(1));
    }

    public static <T> List<T> toList(Pair<T, T> pair) {
        return List.of(pair.first, pair.second);
    }
}
