package pair2;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        Pair<Integer, Integer> pair1 = new Pair<>(2, 5);
        System.out.println(pair1.first());
        System.out.println(pair1.second());
        System.out.println(pair1);

        int x = 10 - 8;
        int y = x + 3;
        Pair<Integer, Integer> pair2 = new Pair<>(x, y);
        System.out.println(pair1.equals(pair2));

        Pair<String, Integer> pair3 = new Pair<>("Hugo", 123);
        System.out.println(pair3);

        Pair<String, Integer> pair4 = Pair.of("Hugo", 123);
        System.out.println(pair4);

        List<Integer> list1 = List.of(1, 2);
        Pair<Integer, Integer> pair5 = Pair.fromList(list1);
        System.out.println(pair5);

        List<Integer> list2 = Pair.toList(pair1);
        System.out.println(list2);
    }
}
