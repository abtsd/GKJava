package ordered;

public class Test {
	public static void main(String[] args) {
		Person a = new Person("Hugo");
		Person b = new Person("Emil");
		System.out.println(a.greater(b));
	}
}
