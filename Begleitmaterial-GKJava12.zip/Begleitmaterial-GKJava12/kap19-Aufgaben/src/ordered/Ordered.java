package ordered;

public interface Ordered<T> extends Comparable<T> {
	default boolean less(T obj) {
		return this.compareTo(obj) < 0;
	}

	default boolean greater(T obj) {
		return this.compareTo(obj) > 0;
	}

	default boolean lessEqual(T obj) {
		return this.compareTo(obj) <= 0;
	}

	default boolean greaterEqual(T obj) {
		return this.compareTo(obj) >= 0;
	}
}
