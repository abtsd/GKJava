package kontakt;

import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		Kontakt[] kontakte = new Kontakt[4];

		kontakte[0] = new Kontakt("Pit", "Flick", "123");
		kontakte[1] = new Kontakt("Hugo", "Meier", "325234");
		kontakte[2] = new Kontakt("Bert", "Brecht", "324123");
		kontakte[3] = new Kontakt("Rolf", "Brecht", "111222");
		
		Arrays.sort(kontakte);
		for (Kontakt k : kontakte)
			System.out.println(k);
	}
}
