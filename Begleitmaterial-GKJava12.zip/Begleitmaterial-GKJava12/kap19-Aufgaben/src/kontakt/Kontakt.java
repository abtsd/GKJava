package kontakt;

public class Kontakt implements Comparable<Kontakt> {
	private String vorname = "";
	private String nachname = "";
	private String telnr;

	public Kontakt(String vorname, String nachname, String telnr) {
		this.vorname = vorname;
		this.nachname = nachname;
		this.telnr = telnr;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getTelnr() {
		return telnr;
	}

	public void setTelnr(String telnr) {
		this.telnr = telnr;
	}

	@Override
	public String toString() {
		return "Kontakt [nachname=" + nachname + ", vorname=" + vorname + ", telnr=" + telnr + "]";
	}

	@Override
	public int compareTo(Kontakt other) {
		String nameThis = nachname + " " + vorname;
		String nameOther = other.nachname + " " + other.vorname;
		return nameThis.compareTo(nameOther);
	}
}
