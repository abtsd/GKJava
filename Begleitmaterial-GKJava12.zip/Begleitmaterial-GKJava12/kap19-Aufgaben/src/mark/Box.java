package mark;

public class Box<T> implements Markable<T> {
	private T value;
	private T mark;

	public void setValue(T value) {
		this.value = value;
	}

	public T getValue() {
		return value;
	}

	@Override
	public void setMark(T m) {
		mark = m;
	}

	@Override
	public T getMark() {
		return mark;
	}
}
