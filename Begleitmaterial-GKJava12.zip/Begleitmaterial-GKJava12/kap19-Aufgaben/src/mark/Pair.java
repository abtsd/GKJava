package mark;

public class Pair<T, U> implements Markable<String> {
	protected T a;
	protected U b;
	private String mark;

	public Pair(T a, U b) {
		this.a = a;
		this.b = b;
	}

	public T getA() {
		return a;
	}

	public U getB() {
		return b;
	}

	public String toString() {
		return "(" + a + ", " + b + ")";
	}

	@Override
	public void setMark(String m) {
		mark = m;
	}

	@Override
	public String getMark() {
		return mark;
	}
}
