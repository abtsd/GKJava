package mark;

public interface Markable<S> {
	void setMark(S m);

	S getMark();
}
