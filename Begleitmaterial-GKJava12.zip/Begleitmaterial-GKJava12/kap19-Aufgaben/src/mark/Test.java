package mark;

public class Test {
	public static void main(String[] args) {
		Pair<Integer, Integer> p = new Pair<>(1, 2);
		p.setMark("Marke A");
		System.out.println(p.getMark());

		Box<Integer> b = new Box<>();
		b.setValue(4711);
		b.setMark(1);
		System.out.println(b.getMark());
	}
}
