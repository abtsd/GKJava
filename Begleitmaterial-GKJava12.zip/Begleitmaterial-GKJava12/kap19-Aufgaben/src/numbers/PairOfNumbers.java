package numbers;

public class PairOfNumbers<T extends Number, U extends Number> extends Pair<T, U> {
	public PairOfNumbers(T a, U b) {
		super(a, b);
	}

	public double sum() {
		return a.doubleValue() + b.doubleValue();
	}
}
