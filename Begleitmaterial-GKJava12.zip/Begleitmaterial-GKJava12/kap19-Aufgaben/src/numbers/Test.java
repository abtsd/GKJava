package numbers;

import java.math.BigInteger;

public class Test {
	public static void main(String[] args) {
		PairOfNumbers<Integer, Double> z1 = new PairOfNumbers<>(12, 1.23);
		System.out.println(z1.sum());

		BigInteger big = new BigInteger("99999999999999999999");
		PairOfNumbers<BigInteger, Double> z2 = new PairOfNumbers<>(big, 1.);
		System.out.println(z2.sum());
	}
}
