package singleton2;

public class Test {
	public static void main(String[] args) {
		EnumSingleton singleton1 = EnumSingleton.INSTANCE;
		System.out.println(singleton1.getValue());

		EnumSingleton singleton2 = EnumSingleton.INSTANCE;
		System.out.println(singleton2.getValue());
	}
}
