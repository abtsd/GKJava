package singleton2;

public enum EnumSingleton {
	INSTANCE;

	private final double value = Math.random();

	public double getValue() {
		return value;
	}
}
