package int_konstanten;

public class Ampelfarbe {
	public static final int ROT = 0;
	public static final int GELB = 1;
	public static final int GRUEN = 2;
}