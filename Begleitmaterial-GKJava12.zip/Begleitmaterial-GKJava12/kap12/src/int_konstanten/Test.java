package int_konstanten;

public class Test {
	public static String info(int farbe) {
		return switch (farbe) {
			case Ampelfarbe.ROT -> "Anhalten";
			case Ampelfarbe.GELB -> "Achtung";
			case Ampelfarbe.GRUEN -> "Weiterfahren";
			default -> "???";
		};
	}

	public static void main(String[] args) {
		System.out.println(info(Ampelfarbe.ROT));
		System.out.println(info(Ampelfarbe.GELB));
		System.out.println(info(Ampelfarbe.GRUEN));
		System.out.println(info(4711));
	}
}
