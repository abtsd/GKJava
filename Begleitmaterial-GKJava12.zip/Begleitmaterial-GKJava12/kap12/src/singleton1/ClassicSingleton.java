package singleton1;

public class ClassicSingleton {
	public static final ClassicSingleton INSTANCE = new ClassicSingleton();
	private final double value;

	private ClassicSingleton() {
		value = Math.random();
	}

	public double getValue() {
		return value;
	}
}
