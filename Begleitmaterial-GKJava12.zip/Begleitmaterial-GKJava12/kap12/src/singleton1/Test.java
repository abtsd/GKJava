package singleton1;

public class Test {
	public static void main(String[] args) {
		ClassicSingleton singleton1 = ClassicSingleton.INSTANCE;
		System.out.println(singleton1.getValue());

		ClassicSingleton singleton2 = ClassicSingleton.INSTANCE;
		System.out.println(singleton2.getValue());
	}
}
