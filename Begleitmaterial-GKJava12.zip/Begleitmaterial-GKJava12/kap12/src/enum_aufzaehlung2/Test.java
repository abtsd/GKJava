package enum_aufzaehlung2;

public class Test {
	public static void main(String[] args) {
		System.out.println(Ampelfarbe.ROT.info());
		System.out.println(Ampelfarbe.GELB.info());
		System.out.println(Ampelfarbe.GRUEN.info());
	}
}
