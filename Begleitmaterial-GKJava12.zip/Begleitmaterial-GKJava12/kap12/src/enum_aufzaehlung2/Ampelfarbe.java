package enum_aufzaehlung2;

public enum Ampelfarbe {
	ROT {
		@Override
		public String info() {
			return "Anhalten";
		}
	},
	GELB {
		@Override
		public String info() {
			return "Achtung";
		}
	},
	GRUEN {
		@Override
		public String info() {
			return "Weiterfahren";
		}
	};

	public abstract String info();
}
