package typ_sicher;

public class Ampelfarbe {
	public static final Ampelfarbe ROT = new Ampelfarbe(0);
	public static final Ampelfarbe GELB = new Ampelfarbe(1);
	public static final Ampelfarbe GRUEN = new Ampelfarbe(2);

	private final int value;

	private Ampelfarbe(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}