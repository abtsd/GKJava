package typ_sicher;

public class Test {
	public static String info(Ampelfarbe farbe) {
		if (farbe == Ampelfarbe.ROT)
			return "Anhalten";
		else if (farbe == Ampelfarbe.GELB)
			return "Achtung";
		else if (farbe == Ampelfarbe.GRUEN)
			return "Weiterfahren";
		else return "???";
	}

	public static void main(String[] args) {
		System.out.println(info(Ampelfarbe.ROT));
		System.out.println(info(Ampelfarbe.GELB));
		System.out.println(info(Ampelfarbe.GRUEN));
	}
}
