package enum_aufzaehlung1;

public enum Ampelfarbe {
	ROT, GELB, GRUEN
}
