package enum_aufzaehlung1;

public class Test {
	public static String info(Ampelfarbe farbe) {
		return switch (farbe) {
			case ROT -> "Anhalten";
			case GELB -> "Achtung";
			case GRUEN -> "Weiterfahren";
		};
	}

	public static void main(String[] args) {
		System.out.println(info(Ampelfarbe.ROT));
		System.out.println(info(Ampelfarbe.GELB));
		System.out.println(info(Ampelfarbe.GRUEN));

		for (Ampelfarbe farbe : Ampelfarbe.values()) {
			System.out.println(farbe.ordinal() + " " + farbe.name() + " " + farbe);
		}
	}
}
