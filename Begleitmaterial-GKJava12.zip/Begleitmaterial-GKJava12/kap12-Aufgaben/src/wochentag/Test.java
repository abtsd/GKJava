package wochentag;

public class Test {
	public static void main(String[] args) {
		Wochentag wochentag = Wochentag.MI;
		System.out.println("Es ist " + wochentag.getName() +
				". Noch " + Wochentag.bisWochenende(wochentag) +
				" Tage bis zum Sonntag.");
	}
}
