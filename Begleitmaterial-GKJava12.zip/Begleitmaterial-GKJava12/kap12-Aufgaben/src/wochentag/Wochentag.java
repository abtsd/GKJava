package wochentag;

public enum Wochentag {
	MO("Montag"),
	DI("Dienstag"),
	MI("Mittwoch"),
	DO("Donnerstag"),
	FR("Freitag"),
	SA("Samstag"),
	SO("Sonntag");

	private final String name;

	Wochentag(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static int bisWochenende(Wochentag wochentag) {
		return Wochentag.SO.ordinal() - wochentag.ordinal();
	}
}
