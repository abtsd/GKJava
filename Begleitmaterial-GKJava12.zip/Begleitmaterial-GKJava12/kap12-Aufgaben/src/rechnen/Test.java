package rechnen;

public class Test {
	public static void main(String[] args) {
		double x = 10;
		double y = 2;

		for (Operation op : Operation.values()) {
			System.out.println(x + " " + op.toString() + " " + y + " = " + op.compute(x, y));
		}
	}
}
