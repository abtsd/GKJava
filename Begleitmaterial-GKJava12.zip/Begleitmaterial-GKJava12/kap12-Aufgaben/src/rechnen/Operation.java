package rechnen;

public enum Operation {
	PLUS("+") {
		@Override
		public double compute(double x, double y) {
			return x + y;
		}
	},
	MINUS("-") {
		@Override
		public double compute(double x, double y) {
			return x - y;
		}
	},
	TIMES("*") {
		@Override
		public double compute(double x, double y) {
			return x * y;
		}
	},
	DIVIDE("/") {
		@Override
		public double compute(double x, double y) {
			return x / y;
		}
	};

	private String symbol;

	Operation(String symbol) {
		this.symbol = symbol;
	}

	public String toString() {
		return symbol;
	}

	public abstract double compute(double x, double y);
}
