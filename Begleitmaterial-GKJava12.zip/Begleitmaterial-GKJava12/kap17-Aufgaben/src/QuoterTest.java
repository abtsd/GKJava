import quoter.demo.api.Quoter;

public class QuoterTest {
	public static void main(String[] args) {
		Quoter quoter = Quoter.newInstance();
		if (quoter != null)
			System.out.println(quoter.quote("Das ist ein Test."));
	}
}
