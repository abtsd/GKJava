package factory;

public class Test {
	public static void main(String[] args) throws Exception {
		Service service = ServiceFactory.createService(args[0]);
		service.work();
	}
}
