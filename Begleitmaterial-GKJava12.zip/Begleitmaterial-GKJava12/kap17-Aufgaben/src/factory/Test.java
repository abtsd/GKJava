package factory;

public class Test {
	public static void main(String[] args) throws Exception {
		Service service1 = ServiceFactory.createService("factory.ServiceImpl1");
		service1.work();

		Service service2 = ServiceFactory.createService("factory.ServiceImpl2");
		service2.work();
	}
}
