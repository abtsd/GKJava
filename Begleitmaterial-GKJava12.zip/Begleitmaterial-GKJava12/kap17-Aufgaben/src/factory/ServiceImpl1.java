package factory;

public class ServiceImpl1 implements Service {
	public void work() {
		System.out.println("Version 1");
	}
}
