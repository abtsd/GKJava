package factory;

public class ServiceImpl2 implements Service {
	public void work() {
		System.out.println("Version 2");
	}
}
