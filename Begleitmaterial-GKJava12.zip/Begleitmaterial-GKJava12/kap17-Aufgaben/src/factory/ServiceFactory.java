package factory;

public class ServiceFactory {
    public static Service createService(String className) throws Exception {
        Class c = Class.forName(className);
        return (Service) c.getDeclaredConstructor().newInstance();
    }
}
