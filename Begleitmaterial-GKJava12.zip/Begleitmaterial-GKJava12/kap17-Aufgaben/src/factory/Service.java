package factory;

public interface Service {
    void work();
}
