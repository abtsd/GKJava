package service.demo.impl;

import service.demo.api.MyService;

public class MyServiceImplA implements MyService {
	@Override
	public String getName() {
		return "Service A";
	}
}
