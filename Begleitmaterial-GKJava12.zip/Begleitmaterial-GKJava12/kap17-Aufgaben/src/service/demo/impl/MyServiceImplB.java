package service.demo.impl;

import service.demo.api.MyService;

public class MyServiceImplB implements MyService {
	@Override
	public String getName() {
		return "Service B";
	}
}
