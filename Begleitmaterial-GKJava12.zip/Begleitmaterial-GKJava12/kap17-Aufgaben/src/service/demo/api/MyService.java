package service.demo.api;

public interface MyService {
	String getName();
}
