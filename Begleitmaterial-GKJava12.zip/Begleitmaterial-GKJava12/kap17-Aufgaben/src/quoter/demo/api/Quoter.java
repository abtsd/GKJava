package quoter.demo.api;

import java.util.ServiceLoader;

public interface Quoter {
	String quote(String text);

	static Quoter newInstance() {
		ServiceLoader<Quoter> serviceLoader = ServiceLoader.load(Quoter.class);
		for (Quoter service : serviceLoader) {
			return service;
		}
		return null;
	}
}
