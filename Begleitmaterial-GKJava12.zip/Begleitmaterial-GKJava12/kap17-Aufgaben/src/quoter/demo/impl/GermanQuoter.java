package quoter.demo.impl;

import quoter.demo.api.Quoter;

public class GermanQuoter implements Quoter {
    @Override
    public String quote(String text) {
        return '\u201E' + text + '\u201D';
    }
}
