import service.demo.api.MyService;

import java.util.ServiceLoader;

public class ServiceTest {
    public static void main(String[] args) {
        ServiceLoader<MyService> serviceLoader = ServiceLoader.load(MyService.class);
        for (MyService service : serviceLoader) {
            System.out.println("Service-Implementierung: "
                    + service.getClass().getName()
                    + ", getName(): "
                    + service.getName());
        }
    }
}
