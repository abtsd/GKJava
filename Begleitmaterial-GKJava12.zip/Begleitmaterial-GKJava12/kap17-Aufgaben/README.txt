java -cp out/production/kap17-Aufgaben factory.Test factory.ServiceImpl1
java -cp out/production/kap17-Aufgaben factory.Test factory.ServiceImpl2

jar --create --file quoter.jar -C out/production/kap17-Aufgaben quoter \
-C out/production/kap17-Aufgaben META-INF/services/quoter.demo.api.Quoter
java -cp out/production/kap17-Aufgaben:quoter.jar QuoterTest

jar --create --file service.jar -C out/production/kap17-Aufgaben service \
-C out/production/kap17-Aufgaben META-INF/services/service.demo.api.MyService
java -cp out/production/kap17-Aufgaben:service.jar ServiceTest
